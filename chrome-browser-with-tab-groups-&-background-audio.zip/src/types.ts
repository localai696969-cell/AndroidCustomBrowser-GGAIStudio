export type TabGroupColor = 'grey' | 'blue' | 'red' | 'yellow' | 'green' | 'pink' | 'purple' | 'cyan';

export interface TabGroup {
  id: string;
  name: string;
  color: TabGroupColor;
  collapsed: boolean;
}

export interface Tab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  groupId?: string;
  pinned?: boolean;
  active?: boolean;
  type?: 'web' | 'youtube' | 'techdocs' | 'newtab';
  isPlayingAudio?: boolean;
}

export interface Bookmark {
  id: string;
  title: string;
  url: string;
  icon?: string;
}

export interface HistoryItem {
  id: string;
  title: string;
  url: string;
  visitedAt: Date;
}

export interface AudioTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  youtubeId: string;
  coverUrl: string;
  durationSeconds: number;
}

export interface SniffedMediaItem {
  id: string;
  title: string;
  url: string;
  format: 'MP4' | 'MP3' | 'M3U8' | 'WEBM' | 'FLV';
  quality: '4K 2160p' | '1080p FHD' | '720p HD' | '480p SD' | '320kbps MP3';
  fileSize: string;
  thumbnail?: string;
  sourceUrl: string;
}

export interface DownloadTask {
  id: string;
  filename: string;
  url: string;
  size: string;
  progress: number;
  speed: string;
  status: 'downloading' | 'paused' | 'completed' | 'failed';
  type: 'video' | 'audio' | 'playlist' | 'webpage';
  addedAt: Date;
}

export interface PlaylistItem {
  id: string;
  youtubeId: string;
  title: string;
  duration: string;
  author: string;
  thumbnail: string;
  selected: boolean;
}

export type PageDownloadFormat = 'html' | 'mhtml' | 'pdf' | 'txt';

export type BrowserEngineType = 'chromium' | 'geckoview';

export interface EngineConfig {
  type: BrowserEngineType;
  version: string;
  keepAliveInBackground: boolean;
  blockAdsAndTrackers: boolean;
  userAgent: string;
}
