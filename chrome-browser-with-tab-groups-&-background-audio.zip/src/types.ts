export type TabGroupColor = 'blue' | 'red' | 'yellow' | 'green' | 'pink' | 'purple' | 'cyan' | 'orange';

export interface TabGroup {
  id: string;
  title: string;
  color: TabGroupColor;
  collapsed: boolean;
}

export interface Tab {
  id: string;
  title: string;
  url: string;
  favicon?: string;
  type: 'newtab' | 'youtube' | 'techdocs' | 'google' | 'bookmark' | 'external' | 'settings' | 'history';
  groupId?: string; // ID of the TabGroup it belongs to
  youtubeVideoId?: string;
  pinned?: boolean;
}

export interface Bookmark {
  id: string;
  title: string;
  url: string;
  icon: string;
  category?: string;
}

export interface HistoryItem {
  id: string;
  title: string;
  url: string;
  visitedAt: Date;
  favicon?: string;
}

export interface AudioTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  coverUrl: string;
  youtubeId: string;
  duration: number; // in seconds
  genre: string;
}

export interface TechnicalDocSection {
  id: string;
  title: string;
  titleVi: string;
  summary: string;
  contentMarkdown: string;
  codeSnippet?: string;
  keyTakeaways: string[];
}

export interface BackgroundAudioState {
  isPlaying: boolean;
  currentTrack: AudioTrack | null;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isPipActive: boolean;
  
  // Technical background features status
  visibilityOverrideEnabled: boolean;
  audioContextKeepAliveEnabled: boolean;
  mediaSessionEnabled: boolean;
  wakeLockActive: boolean;
  backgroundLogs: string[];
}

export interface SniffedMediaItem {
  id: string;
  title: string;
  url: string;
  format: 'MP4' | 'MP3' | 'M3U8' | 'WEBM' | 'FLV';
  quality: '4K 2160p' | '1080p FHD' | '720p HD' | '480p SD' | '320kbps MP3';
  fileSize: string;
  thumbnail?: string;
  sourceUrl: string;
}

export interface DownloadTask {
  id: string;
  filename: string;
  url: string;
  size: string;
  progress: number; // 0 to 100
  speed: string; // e.g. "8.5 MB/s"
  status: 'downloading' | 'paused' | 'completed' | 'failed';
  type: 'video' | 'audio' | 'playlist' | 'webpage';
  addedAt: Date;
}

export interface PlaylistItem {
  id: string;
  youtubeId: string;
  title: string;
  duration: string;
  author: string;
  thumbnail: string;
  selected: boolean;
}

export type PageDownloadFormat = 'html' | 'mhtml' | 'pdf' | 'txt' | 'zip_archive';

export type BrowserEngineType = 'chromium' | 'geckoview';

export interface EngineConfig {
  type: BrowserEngineType;
  version: string;
  keepAliveInBackground: boolean;
  blockAdsAndTrackers: boolean;
  userAgent: string;
}

