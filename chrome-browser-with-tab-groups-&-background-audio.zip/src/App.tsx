import React, { useState, useEffect } from 'react';
import {
  Tab,
  TabGroup,
  Bookmark,
  HistoryItem,
  AudioTrack,
  TabGroupColor,
  DownloadTask,
  SniffedMediaItem,
  PlaylistItem,
  PageDownloadFormat,
  EngineConfig,
} from './types';
import { INITIAL_TAB_GROUPS, INITIAL_TABS, INITIAL_BOOKMARKS, YOUTUBE_TRACKS } from './data/initialData';
import { backgroundAudioService } from './services/backgroundAudio';
import { ChromeTopBar } from './components/ChromeTopBar';
import { ChromeNavBar } from './components/ChromeNavBar';
import { BookmarksBar } from './components/BookmarksBar';
import { WebPageContainer } from './components/WebPageContainer';
import { BackgroundAudioMiniPlayer } from './components/BackgroundAudioMiniPlayer';
import { TabGroupsModal } from './components/TabGroupsModal';
import { ExtensionsModal } from './components/ExtensionsModal';
import { HistoryBookmarksModal } from './components/HistoryBookmarksModal';
import { SettingsModal } from './components/SettingsModal';
import { IDMSnifferModal, SAMPLE_SNIFFED_MEDIA } from './components/IDMSnifferModal';
import { PlaylistDownloaderModal } from './components/PlaylistDownloaderModal';
import { PageDownloaderModal } from './components/PageDownloaderModal';

export function App() {
  // State
  const [tabs, setTabs] = useState<Tab[]>(INITIAL_TABS);
  const [groups, setGroups] = useState<TabGroup[]>(INITIAL_TAB_GROUPS);
  const [activeTabId, setActiveTabId] = useState<string>('tab-yt-player');

  const [bookmarks, setBookmarks] = useState<Bookmark[]>(INITIAL_BOOKMARKS);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showBookmarksBar, setShowBookmarksBar] = useState<boolean>(true);

  // Engine Configuration State
  const [engineConfig, setEngineConfig] = useState<EngineConfig>({
    type: 'chromium',
    version: 'Chromium 128.0.6613.120',
    keepAliveInBackground: true,
    blockAdsAndTrackers: true,
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36',
  });

  // Downloads & IDM Sniffer State
  const [downloadTasks, setDownloadTasks] = useState<DownloadTask[]>([
    {
      id: 'task-1',
      filename: 'Lofi_Hip_Hop_Radio_1080p_Stream.m3u8',
      url: 'https://stream.youtube.com/hls/live_stream_1080p.m3u8',
      size: '250.4 MB',
      progress: 68,
      speed: '12.4 MB/s',
      status: 'downloading',
      type: 'video',
      addedAt: new Date(),
    },
  ]);

  // Background Audio State
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(true);
  const [currentTrack, setCurrentTrack] = useState<AudioTrack>(YOUTUBE_TRACKS[0]);

  // UI Theme & Modals
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [modalType, setModalType] = useState<
    'none' | 'groups' | 'extensions' | 'history' | 'bookmarks' | 'settings' | 'idm' | 'playlist' | 'pageSaver'
  >('none');

  const activeTab = tabs.find((t) => t.id === activeTabId);

  // Toggle Browser Engine (Chromium vs GeckoView Firefox Engine)
  const handleToggleEngine = () => {
    setEngineConfig((prev) =>
      prev.type === 'chromium'
        ? {
            type: 'geckoview',
            version: 'GeckoView Firefox 125.0',
            keepAliveInBackground: true,
            blockAdsAndTrackers: true,
            userAgent: 'Mozilla/5.0 (Android 14; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0',
          }
        : {
            type: 'chromium',
            version: 'Chromium 128.0.6613.120',
            keepAliveInBackground: true,
            blockAdsAndTrackers: true,
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36',
          }
    );
  };

  // Download Task Handlers
  const handleStartDownloadFromSniffer = (item: SniffedMediaItem) => {
    const newTask: DownloadTask = {
      id: 'dl-' + Date.now(),
      filename: item.title.replace(/[^a-zA-Z0-9_\- ]/g, '_') + '.' + item.format.toLowerCase(),
      url: item.url,
      size: item.fileSize,
      progress: 5,
      speed: '14.2 MB/s',
      status: 'downloading',
      type: item.format === 'MP3' ? 'audio' : 'video',
      addedAt: new Date(),
    };
    setDownloadTasks((prev) => [newTask, ...prev]);
  };

  const handleStartPlaylistDownload = (items: PlaylistItem[], format: 'MP4' | 'MP3' | 'WEBM', quality: string) => {
    const newTasks: DownloadTask[] = items.map((it) => ({
      id: 'pl-dl-' + it.id + '-' + Date.now(),
      filename: `[YouTube_${quality}]_${it.title.replace(/[^a-zA-Z0-9_\- ]/g, '_')}.${format.toLowerCase()}`,
      url: `https://youtube.com/watch?v=${it.youtubeId}`,
      size: format === 'MP3' ? '12.5 MB' : '145.8 MB',
      progress: 10,
      speed: '18.5 MB/s',
      status: 'downloading',
      type: 'playlist',
      addedAt: new Date(),
    }));
    setDownloadTasks((prev) => [...newTasks, ...prev]);
  };

  const handleDownloadPageFormat = (format: PageDownloadFormat, filename: string) => {
    const pageTask: DownloadTask = {
      id: 'page-' + Date.now(),
      filename: `${filename}.${format}`,
      url: activeTab?.url || 'chrome://newtab',
      size: '4.2 MB',
      progress: 100,
      speed: 'Completed',
      status: 'completed',
      type: 'webpage',
      addedAt: new Date(),
    };
    setDownloadTasks((prev) => [pageTask, ...prev]);
    alert(`Đã xuất và lưu trang web dưới dạng file .${format.toUpperCase()} thành công!`);
  };

  const handleToggleTaskPause = (taskId: string) => {
    setDownloadTasks((prev) =>
      prev.map((t) =>
        t.id === taskId
          ? {
              ...t,
              status: t.status === 'downloading' ? 'paused' : 'downloading',
              speed: t.status === 'downloading' ? '0 MB/s' : '10.5 MB/s',
            }
          : t
      )
    );
  };

  const handleRemoveTask = (taskId: string) => {
    setDownloadTasks((prev) => prev.filter((t) => t.id !== taskId));
  };


  // Initialize Background Audio Engine on mount
  useEffect(() => {
    if (isPlayingAudio) {
      backgroundAudioService.enableAudioContextKeepAlive();
      backgroundAudioService.updateMediaSession(currentTrack, {
        onPlay: () => setIsPlayingAudio(true),
        onPause: () => setIsPlayingAudio(false),
        onNext: handleNextTrack,
        onPrev: handlePrevTrack,
      });
      backgroundAudioService.requestWakeLock();
    }
  }, []);

  // Update Media Session when track or play state changes
  useEffect(() => {
    if (isPlayingAudio) {
      backgroundAudioService.updateMediaSession(currentTrack, {
        onPlay: () => setIsPlayingAudio(true),
        onPause: () => setIsPlayingAudio(false),
        onNext: handleNextTrack,
        onPrev: handlePrevTrack,
      });
      backgroundAudioService.setMediaSessionPlaybackState('playing');
    } else {
      backgroundAudioService.setMediaSessionPlaybackState('paused');
    }
  }, [currentTrack, isPlayingAudio]);

  // Log history item when tab changes
  useEffect(() => {
    if (activeTab) {
      const newHistoryItem: HistoryItem = {
        id: 'hist-' + Date.now(),
        title: activeTab.title,
        url: activeTab.url,
        visitedAt: new Date(),
      };
      setHistory((prev) => [newHistoryItem, ...prev.slice(0, 49)]);
    }
  }, [activeTabId]);

  // Audio Handlers
  const handleTogglePlayPause = () => {
    if (isPlayingAudio) {
      setIsPlayingAudio(false);
      backgroundAudioService.setMediaSessionPlaybackState('paused');
    } else {
      setIsPlayingAudio(true);
      backgroundAudioService.enableAudioContextKeepAlive();
      backgroundAudioService.setMediaSessionPlaybackState('playing');
    }
  };

  const handleSelectTrack = (track: AudioTrack) => {
    setCurrentTrack(track);
    setIsPlayingAudio(true);
  };

  const handleNextTrack = () => {
    const currentIndex = YOUTUBE_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const nextIndex = (currentIndex + 1) % YOUTUBE_TRACKS.length;
    setCurrentTrack(YOUTUBE_TRACKS[nextIndex]);
    setIsPlayingAudio(true);
  };

  const handlePrevTrack = () => {
    const currentIndex = YOUTUBE_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const prevIndex = (currentIndex - 1 + YOUTUBE_TRACKS.length) % YOUTUBE_TRACKS.length;
    setCurrentTrack(YOUTUBE_TRACKS[prevIndex]);
    setIsPlayingAudio(true);
  };

  // Tab Management Handlers
  const handleSelectTab = (tabId: string) => {
    setActiveTabId(tabId);
  };

  const handleCloseTab = (tabId: string) => {
    const remaining = tabs.filter((t) => t.id !== tabId);
    if (remaining.length === 0) {
      // Create a default New Tab if all tabs closed
      const newTabObj: Tab = {
        id: 'tab-' + Date.now(),
        title: 'New Tab',
        url: 'chrome://newtab',
        type: 'newtab',
      };
      setTabs([newTabObj]);
      setActiveTabId(newTabObj.id);
    } else {
      setTabs(remaining);
      if (activeTabId === tabId) {
        setActiveTabId(remaining[remaining.length - 1].id);
      }
    }
  };

  const handleNewTab = (customUrl?: string, customTitle?: string, type?: Tab['type']) => {
    const newId = 'tab-' + Date.now();
    const newTabObj: Tab = {
      id: newId,
      title: customTitle || 'New Tab',
      url: customUrl || 'chrome://newtab',
      type: type || (customUrl ? 'google' : 'newtab'),
    };
    setTabs((prev) => [...prev, newTabObj]);
    setActiveTabId(newId);
  };

  const handleNavigateUrl = (inputUrl: string) => {
    if (!activeTab) return;

    let updatedType: Tab['type'] = 'google';
    let updatedTitle = inputUrl;

    if (inputUrl.startsWith('chrome://tech-docs')) {
      updatedType = 'techdocs';
      updatedTitle = 'Tài Liệu Kỹ Thuật Background Audio';
    } else if (inputUrl.startsWith('chrome://newtab')) {
      updatedType = 'newtab';
      updatedTitle = 'New Tab';
    } else if (inputUrl.includes('youtube.com')) {
      updatedType = 'youtube';
      updatedTitle = 'YouTube Background Player';
    } else if (inputUrl.includes('google.com')) {
      updatedType = 'google';
      updatedTitle = `Google Search - ${inputUrl}`;
    }

    setTabs((prev) =>
      prev.map((t) =>
        t.id === activeTab.id ? { ...t, url: inputUrl, title: updatedTitle, type: updatedType } : t
      )
    );
  };

  // Tab Group Handlers
  const handleToggleGroupCollapse = (groupId: string) => {
    setGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, collapsed: !g.collapsed } : g))
    );
  };

  const handleUpdateGroup = (updatedGroup: TabGroup) => {
    setGroups((prev) => prev.map((g) => (g.id === updatedGroup.id) ? updatedGroup : g));
  };

  const handleDeleteGroup = (groupId: string) => {
    setGroups((prev) => prev.filter((g) => g.id !== groupId));
    // Remove group binding from tabs
    setTabs((prev) => prev.map((t) => (t.groupId === groupId ? { ...t, groupId: undefined } : t)));
  };

  const handleCreateGroup = (title: string, color: TabGroupColor) => {
    const newGroup: TabGroup = {
      id: 'group-' + Date.now(),
      title,
      color,
      collapsed: false,
    };
    setGroups((prev) => [...prev, newGroup]);
  };

  const handleAddTabToGroup = (groupId: string) => {
    const newTabId = 'tab-' + Date.now();
    const newTabObj: Tab = {
      id: newTabId,
      title: 'Nhóm Tab Mới',
      url: 'chrome://newtab',
      type: 'newtab',
      groupId,
    };
    setTabs((prev) => [...prev, newTabObj]);
    setActiveTabId(newTabId);
  };

  const handleAssignTabToGroup = (tabId: string, groupId: string | undefined) => {
    setTabs((prev) => prev.map((t) => (t.id === tabId ? { ...t, groupId } : t)));
  };

  // Bookmark Handlers
  const isCurrentBookmarked = activeTab
    ? bookmarks.some((bm) => bm.url === activeTab.url)
    : false;

  const handleToggleBookmarkCurrent = () => {
    if (!activeTab) return;
    if (isCurrentBookmarked) {
      setBookmarks((prev) => prev.filter((bm) => bm.url !== activeTab.url));
    } else {
      const newBm: Bookmark = {
        id: 'bm-' + Date.now(),
        title: activeTab.title,
        url: activeTab.url,
        icon: activeTab.type === 'youtube' ? 'Youtube' : 'Globe',
      };
      setBookmarks((prev) => [...prev, newBm]);
    }
  };

  return (
    <div className={`h-screen w-screen flex flex-col font-sans overflow-hidden ${isDarkMode ? 'dark bg-[#1E2022]' : 'bg-gray-200'}`}>
      {/* 1. Chrome Window Top Tab Strip & Tab Group Manager */}
      <ChromeTopBar
        tabs={tabs}
        groups={groups}
        activeTabId={activeTabId}
        onSelectTab={handleSelectTab}
        onCloseTab={handleCloseTab}
        onNewTab={() => handleNewTab()}
        onToggleGroupCollapse={handleToggleGroupCollapse}
        onUpdateGroup={handleUpdateGroup}
        onDeleteGroup={handleDeleteGroup}
        onAddTabToGroup={handleAddTabToGroup}
        onCreateGroupModal={() => setModalType('groups')}
        isPlayingAudio={isPlayingAudio}
      />

      {/* 2. Chrome Navigation Bar & Omnibox Address Bar */}
      <ChromeNavBar
        activeTab={activeTab}
        onNavigateUrl={handleNavigateUrl}
        onOpenHistory={() => setModalType('history')}
        onOpenBookmarks={() => setModalType('bookmarks')}
        onOpenSettings={() => setModalType('settings')}
        onOpenExtensions={() => setModalType('extensions')}
        onOpenTechDocs={() => handleNewTab('chrome://tech-docs', 'Tài Liệu Kỹ Thuật', 'techdocs')}
        onOpenIDMSniffer={() => setModalType('idm')}
        onOpenPlaylistDownloader={() => setModalType('playlist')}
        onOpenPageDownloader={() => setModalType('pageSaver')}
        engineConfig={engineConfig}
        onToggleEngine={handleToggleEngine}
        isPlayingAudio={isPlayingAudio}
        onToggleBookmarksBar={() => setShowBookmarksBar(!showBookmarksBar)}
        showBookmarksBar={showBookmarksBar}
        isBookmarked={isCurrentBookmarked}
        onToggleBookmarkCurrent={handleToggleBookmarkCurrent}
        detectedMediaCount={SAMPLE_SNIFFED_MEDIA.length}
      />

      {/* 3. Bookmarks Quick Bar */}
      {showBookmarksBar && (
        <BookmarksBar
          bookmarks={bookmarks}
          onOpenBookmark={(url, title) => handleNewTab(url, title, url.includes('youtube') ? 'youtube' : 'google')}
        />
      )}

      {/* 4. Active Web Page Render Frame */}
      <div className="flex-1 overflow-hidden relative">
        <WebPageContainer
          activeTab={activeTab}
          currentTrack={currentTrack}
          isPlayingAudio={isPlayingAudio}
          onPlayPauseAudio={handleTogglePlayPause}
          onSelectTrack={handleSelectTrack}
          onNextTrack={handleNextTrack}
          onPrevTrack={handlePrevTrack}
          onOpenTechDocs={() => handleNewTab('chrome://tech-docs', 'Tài Liệu Kỹ Thuật', 'techdocs')}
          onOpenYouTube={() => handleNewTab('https://youtube.com', 'YouTube Lofi Player', 'youtube')}
          onNavigateSearch={(query) =>
            handleNewTab(`https://google.com/search?q=${encodeURIComponent(query)}`, `Search: ${query}`, 'google')
          }
          tabGroups={groups}
        />
      </div>

      {/* 5. Floating Background Audio Mini Player (Persists Across All Tabs) */}
      <BackgroundAudioMiniPlayer
        currentTrack={currentTrack}
        isPlaying={isPlayingAudio}
        onPlayPause={handleTogglePlayPause}
        onNextTrack={handleNextTrack}
        onPrevTrack={handlePrevTrack}
        onOpenPlayerTab={() => handleNewTab('https://youtube.com', 'YouTube Lofi Player', 'youtube')}
      />

      {/* 6. Modals */}
      {modalType === 'groups' && (
        <TabGroupsModal
          groups={groups}
          tabs={tabs}
          onClose={() => setModalType('none')}
          onCreateGroup={handleCreateGroup}
          onDeleteGroup={handleDeleteGroup}
          onAssignTabToGroup={handleAssignTabToGroup}
        />
      )}

      {modalType === 'extensions' && (
        <ExtensionsModal
          onClose={() => setModalType('none')}
          isPlayingAudio={isPlayingAudio}
        />
      )}

      {(modalType === 'history' || modalType === 'bookmarks') && (
        <HistoryBookmarksModal
          initialMode={modalType}
          historyList={history}
          bookmarksList={bookmarks}
          onClose={() => setModalType('none')}
          onOpenUrl={(url, title) => handleNewTab(url, title, url.includes('youtube') ? 'youtube' : 'google')}
          onClearHistory={() => setHistory([])}
          onDeleteBookmark={(id) => setBookmarks((prev) => prev.filter((b) => b.id !== id))}
        />
      )}

      {modalType === 'settings' && (
        <SettingsModal
          onClose={() => setModalType('none')}
          isDarkMode={isDarkMode}
          onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          onClearData={() => {
            setHistory([]);
            setGroups(INITIAL_TAB_GROUPS);
            setModalType('none');
          }}
        />
      )}

      {modalType === 'idm' && (
        <IDMSnifferModal
          onClose={() => setModalType('none')}
          downloadTasks={downloadTasks}
          onStartDownload={handleStartDownloadFromSniffer}
          onToggleTaskPause={handleToggleTaskPause}
          onRemoveTask={handleRemoveTask}
        />
      )}

      {modalType === 'playlist' && (
        <PlaylistDownloaderModal
          onClose={() => setModalType('none')}
          onStartPlaylistDownload={handleStartPlaylistDownload}
        />
      )}

      {modalType === 'pageSaver' && (
        <PageDownloaderModal
          activeTab={activeTab}
          onClose={() => setModalType('none')}
          onDownloadPageFormat={handleDownloadPageFormat}
        />
      )}
    </div>
  );
}
