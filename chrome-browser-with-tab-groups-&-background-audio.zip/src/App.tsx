import React, { useState, useEffect } from 'react';
import {
  Tab,
  TabGroup,
  Bookmark,
  HistoryItem,
  AudioTrack,
  DownloadTask,
  SniffedMediaItem,
  PlaylistItem,
  PageDownloadFormat,
  EngineConfig,
} from './types';
import { INITIAL_TAB_GROUPS, INITIAL_TABS, INITIAL_BOOKMARKS, YOUTUBE_TRACKS } from './data/initialData';
import { backgroundAudioService } from './services/backgroundAudio';
import { ChromeTopBar } from './components/ChromeTopBar';
import { ChromeNavBar } from './components/ChromeNavBar';
import { BookmarksBar } from './components/BookmarksBar';
import { WebPageContainer } from './components/WebPageContainer';
import { TabGroupsModal } from './components/TabGroupsModal';
import { ExtensionsModal } from './components/ExtensionsModal';
import { HistoryBookmarksModal } from './components/HistoryBookmarksModal';
import { SettingsModal } from './components/SettingsModal';
import { IDMSnifferModal, SAMPLE_SNIFFED_MEDIA } from './components/IDMSnifferModal';
import { PlaylistDownloaderModal } from './components/PlaylistDownloaderModal';
import { PageDownloaderModal } from './components/PageDownloaderModal';

export function App() {
  // State
  const [tabs, setTabs] = useState<Tab[]>(INITIAL_TABS);
  const [tabGroups, setTabGroups] = useState<TabGroup[]>(INITIAL_TAB_GROUPS);
  const [activeTabId, setActiveTabId] = useState<string>('tab-1');
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(INITIAL_BOOKMARKS);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showBookmarksBar, setShowBookmarksBar] = useState<boolean>(true);

  // Engine Configuration State
  const [engineConfig, setEngineConfig] = useState<EngineConfig>({
    type: 'chromium',
    version: 'Chromium 128.0.6613.120',
    keepAliveInBackground: true,
    blockAdsAndTrackers: true,
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36',
  });

  // Downloads & IDM Sniffer State
  const [downloadTasks, setDownloadTasks] = useState<DownloadTask[]>([
    {
      id: 'task-1',
      filename: 'Lofi_Hip_Hop_Radio_1080p_Stream.m3u8',
      url: 'https://stream.youtube.com/hls/live_stream_1080p.m3u8',
      size: '250.4 MB',
      progress: 68,
      speed: '12.4 MB/s',
      status: 'downloading',
      type: 'video',
      addedAt: new Date(),
    },
  ]);

  // Background Audio State
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(true);
  const [currentTrack, setCurrentTrack] = useState<AudioTrack>(YOUTUBE_TRACKS[0]);

  // UI Theme & Modals
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [modalType, setModalType] = useState<
    'none' | 'groups' | 'extensions' | 'history' | 'bookmarks' | 'settings' | 'idm' | 'playlist' | 'pageSaver'
  >('none');

  const activeTab = tabs.find((t) => t.id === activeTabId);

  // Toggle Browser Engine (Chromium vs GeckoView Firefox Engine)
  const handleToggleEngine = () => {
    setEngineConfig((prev) =>
      prev.type === 'chromium'
        ? {
            type: 'geckoview',
            version: 'GeckoView Firefox 125.0',
            keepAliveInBackground: true,
            blockAdsAndTrackers: true,
            userAgent: 'Mozilla/5.0 (Android 14; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0',
          }
        : {
            type: 'chromium',
            version: 'Chromium 128.0.6613.120',
            keepAliveInBackground: true,
            blockAdsAndTrackers: true,
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36',
          }
    );
  };

  // Download Task Handlers
  const handleStartDownloadFromSniffer = (item: SniffedMediaItem) => {
    const newTask: DownloadTask = {
      id: 'dl-' + Date.now(),
      filename: item.title.replace(/[^a-zA-Z0-9_\- ]/g, '_') + '.' + item.format.toLowerCase(),
      url: item.url,
      size: item.fileSize,
      progress: 5,
      speed: '14.2 MB/s',
      status: 'downloading',
      type: item.format === 'MP3' ? 'audio' : 'video',
      addedAt: new Date(),
    };
    setDownloadTasks((prev) => [newTask, ...prev]);
  };

  const handleStartPlaylistDownload = (items: PlaylistItem[], format: 'MP4' | 'MP3' | 'WEBM', quality: string) => {
    const newTasks: DownloadTask[] = items.map((it) => ({
      id: 'pl-dl-' + it.id + '-' + Date.now(),
      filename: `[YouTube_${quality}]_${it.title.replace(/[^a-zA-Z0-9_\- ]/g, '_')}.${format.toLowerCase()}`,
      url: `https://youtube.com/watch?v=${it.youtubeId}`,
      size: format === 'MP3' ? '12.5 MB' : '145.8 MB',
      progress: 10,
      speed: '18.5 MB/s',
      status: 'downloading',
      type: 'playlist',
      addedAt: new Date(),
    }));
    setDownloadTasks((prev) => [...newTasks, ...prev]);
  };

  const handleDownloadPageFormat = (format: PageDownloadFormat, filename: string) => {
    const pageTask: DownloadTask = {
      id: 'page-' + Date.now(),
      filename: `${filename}.${format}`,
      url: activeTab?.url || 'chrome://newtab',
      size: '4.2 MB',
      progress: 100,
      speed: 'Completed',
      status: 'completed',
      type: 'webpage',
      addedAt: new Date(),
    };
    setDownloadTasks((prev) => [pageTask, ...prev]);
  };

  const handleToggleTaskPause = (taskId: string) => {
    setDownloadTasks((prev) =>
      prev.map((t) =>
        t.id === taskId
          ? {
              ...t,
              status: t.status === 'downloading' ? 'paused' : 'downloading',
              speed: t.status === 'downloading' ? '0 MB/s' : '10.5 MB/s',
            }
          : t
      )
    );
  };

  const handleRemoveTask = (taskId: string) => {
    setDownloadTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  // Initialize Background Audio Engine on mount
  useEffect(() => {
    if (isPlayingAudio) {
      backgroundAudioService.setTrack(currentTrack);
      backgroundAudioService.play();
    }
  }, []);

  const handleToggleAudio = () => {
    backgroundAudioService.togglePlay();
    setIsPlayingAudio(backgroundAudioService.getIsPlaying());
  };

  const handleSelectTrack = (track: AudioTrack) => {
    setCurrentTrack(track);
    backgroundAudioService.setTrack(track);
    backgroundAudioService.play();
    setIsPlayingAudio(true);
  };

  // Tab Handlers
  const handleSelectTab = (tabId: string) => {
    setActiveTabId(tabId);
    setTabs((prev) => prev.map((t) => ({ ...t, active: t.id === tabId })));
  };

  const handleCloseTab = (tabId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const newTabs = tabs.filter((t) => t.id !== tabId);
    if (newTabs.length === 0) {
      handleNewTab('chrome://newtab', 'New Tab', 'newtab');
    } else if (activeTabId === tabId) {
      const remainingTab = newTabs[newTabs.length - 1];
      setActiveTabId(remainingTab.id);
      setTabs(newTabs.map((t) => ({ ...t, active: t.id === remainingTab.id })));
    } else {
      setTabs(newTabs);
    }
  };

  const handleNewTab = (
    url = 'chrome://newtab',
    title = 'New Tab',
    type: 'web' | 'youtube' | 'techdocs' | 'newtab' = 'newtab',
    groupId?: string
  ) => {
    const newTabId = 'tab-' + Date.now();
    const newTab: Tab = {
      id: newTabId,
      url,
      title,
      type,
      groupId,
      active: true,
    };
    setTabs((prev) => [...prev.map((t) => ({ ...t, active: false })), newTab]);
    setActiveTabId(newTabId);

    // Record History
    setHistory((prev) => [
      { id: 'hist-' + Date.now(), title, url, visitedAt: new Date() },
      ...prev,
    ]);
  };

  const handleNavigate = (newUrl: string) => {
    if (!activeTabId) return;

    let formattedUrl = newUrl.trim();
    let type: 'web' | 'youtube' | 'techdocs' | 'newtab' = 'web';
    let title = formattedUrl;

    if (formattedUrl.startsWith('chrome://newtab')) {
      type = 'newtab';
      title = 'New Tab';
    } else if (formattedUrl.startsWith('chrome://tech-docs')) {
      type = 'techdocs';
      title = 'Tech Specs Doc';
    } else if (formattedUrl.includes('youtube.com') || formattedUrl.includes('youtu.be')) {
      type = 'youtube';
      title = 'YouTube Lofi';
    } else if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
      formattedUrl = 'https://www.google.com/search?q=' + encodeURIComponent(formattedUrl);
      title = `Google Search: ${newUrl}`;
    }

    setTabs((prev) =>
      prev.map((t) =>
        t.id === activeTabId
          ? { ...t, url: formattedUrl, title, type }
          : t
      )
    );

    setHistory((prev) => [
      { id: 'hist-' + Date.now(), title, url: formattedUrl, visitedAt: new Date() },
      ...prev,
    ]);
  };

  // Group Handlers
  const handleToggleGroupCollapse = (groupId: string) => {
    setTabGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, collapsed: !g.collapsed } : g))
    );
  };

  const handleCreateGroup = (name: string, color: TabGroup['color'], tabIds: string[]) => {
    const newGroupId = 'group-' + Date.now();
    const newGroup: TabGroup = {
      id: newGroupId,
      name,
      color,
      collapsed: false,
    };
    setTabGroups((prev) => [...prev, newGroup]);
    setTabs((prev) =>
      prev.map((t) => (tabIds.includes(t.id) ? { ...t, groupId: newGroupId } : t))
    );
  };

  const handleToggleBookmarkCurrent = () => {
    if (!activeTab) return;
    const isBookmarked = bookmarks.some((b) => b.url === activeTab.url);
    if (isBookmarked) {
      setBookmarks((prev) => prev.filter((b) => b.url !== activeTab.url));
    } else {
      setBookmarks((prev) => [
        ...prev,
        {
          id: 'bm-' + Date.now(),
          title: activeTab.title,
          url: activeTab.url,
          icon: activeTab.type === 'youtube' ? 'youtube' : 'globe',
        },
      ]);
    }
  };

  return (
    <div className={`flex flex-col h-screen w-screen overflow-hidden ${isDarkMode ? 'dark bg-[#1A1C1E] text-gray-100' : 'bg-gray-100 text-gray-900'}`}>
      {/* 1. Chrome Window Top Bar (Tabs + Tab Groups) */}
      <ChromeTopBar
        tabs={tabs}
        tabGroups={tabGroups}
        activeTabId={activeTabId}
        onSelectTab={handleSelectTab}
        onCloseTab={handleCloseTab}
        onNewTab={() => handleNewTab()}
        onToggleGroupCollapse={handleToggleGroupCollapse}
        onOpenGroupManager={() => setModalType('groups')}
        isPlayingAudio={isPlayingAudio}
      />

      {/* 2. Chrome Navigation Bar & Extension Controls */}
      <ChromeNavBar
        activeTab={activeTab}
        onNavigate={handleNavigate}
        onOpenSettings={() => setModalType('settings')}
        onOpenExtensions={() => setModalType('extensions')}
        onOpenTechDocs={() => handleNewTab('chrome://tech-docs', 'Tài Liệu Kỹ Thuật', 'techdocs')}
        onOpenIDMSniffer={() => setModalType('idm')}
        onOpenPlaylistDownloader={() => setModalType('playlist')}
        onOpenPageDownloader={() => setModalType('pageSaver')}
        engineConfig={engineConfig}
        onToggleEngine={handleToggleEngine}
        isPlayingAudio={isPlayingAudio}
        onToggleBookmarksBar={() => setShowBookmarksBar(!showBookmarksBar)}
        showBookmarksBar={showBookmarksBar}
        onToggleBookmarkCurrent={handleToggleBookmarkCurrent}
        detectedMediaCount={SAMPLE_SNIFFED_MEDIA.length}
      />

      {/* 3. Bookmarks Quick Bar */}
      {showBookmarksBar && (
        <BookmarksBar
          bookmarks={bookmarks}
          onNavigate={(url) => handleNavigate(url)}
          onOpenHistoryModal={() => setModalType('history')}
        />
      )}

      {/* 4. Active Tab Content Area */}
      <div className="flex-1 overflow-hidden relative">
        <WebPageContainer
          activeTab={activeTab}
          isPlayingAudio={isPlayingAudio}
          onToggleAudio={handleToggleAudio}
          currentTrack={currentTrack}
          onSelectTrack={handleSelectTrack}
          onOpenTechDocs={() => handleNewTab('chrome://tech-docs', 'Tài Liệu Kỹ Thuật', 'techdocs')}
        />
      </div>

      {/* Modals & Popups */}
      {modalType === 'groups' && (
        <TabGroupsModal
          tabs={tabs}
          tabGroups={tabGroups}
          onClose={() => setModalType('none')}
          onCreateGroup={handleCreateGroup}
        />
      )}

      {modalType === 'extensions' && (
        <ExtensionsModal
          isPlayingAudio={isPlayingAudio}
          onToggleAudio={handleToggleAudio}
          currentTrack={currentTrack}
          onSelectTrack={handleSelectTrack}
          onClose={() => setModalType('none')}
        />
      )}

      {modalType === 'history' && (
        <HistoryBookmarksModal
          history={history}
          bookmarks={bookmarks}
          onClose={() => setModalType('none')}
          onNavigate={(url) => {
            handleNavigate(url);
            setModalType('none');
          }}
        />
      )}

      {modalType === 'settings' && (
        <SettingsModal
          isDarkMode={isDarkMode}
          onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          showBookmarksBar={showBookmarksBar}
          onToggleBookmarksBar={() => setShowBookmarksBar(!showBookmarksBar)}
          onClose={() => setModalType('none')}
          engineConfig={engineConfig}
          onToggleEngine={handleToggleEngine}
        />
      )}

      {modalType === 'idm' && (
        <IDMSnifferModal
          onClose={() => setModalType('none')}
          downloadTasks={downloadTasks}
          onStartDownload={handleStartDownloadFromSniffer}
          onToggleTaskPause={handleToggleTaskPause}
          onRemoveTask={handleRemoveTask}
        />
      )}

      {modalType === 'playlist' && (
        <PlaylistDownloaderModal
          onClose={() => setModalType('none')}
          onStartPlaylistDownload={handleStartPlaylistDownload}
        />
      )}

      {modalType === 'pageSaver' && (
        <PageDownloaderModal
          activeTab={activeTab}
          onClose={() => setModalType('none')}
          onDownloadPageFormat={handleDownloadPageFormat}
        />
      )}
    </div>
  );
}
