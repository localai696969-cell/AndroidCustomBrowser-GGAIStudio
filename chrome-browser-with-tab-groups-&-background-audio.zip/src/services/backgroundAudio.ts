import { AudioTrack } from '../types';

class BackgroundAudioService {
  private audioContext: AudioContext | null = null;
  private silentOscillator: OscillatorNode | null = null;
  private silentGain: GainNode | null = null;
  private wakeLock: any = null;
  private logs: string[] = [];
  private onLogCallback: ((logs: string[]) => void) | null = null;

  private isVisibilityOverrideActive = true;
  private isAudioContextActive = false;
  private isMediaSessionActive = false;
  private isWakeLockActive = false;

  constructor() {
    this.initVisibilityOverride();
  }

  public setLogCallback(cb: (logs: string[]) => void) {
    this.onLogCallback = cb;
  }

  public log(msg: string) {
    const timestamp = new Date().toLocaleTimeString('vi-VN');
    const entry = `[${timestamp}] ${msg}`;
    this.logs = [entry, ...this.logs.slice(0, 49)];
    if (this.onLogCallback) {
      this.onLogCallback([...this.logs]);
    }
  }

  public getLogs(): string[] {
    return this.logs;
  }

  // 1. Page Visibility Override Strategy
  private initVisibilityOverride() {
    try {
      // Intercept visibilitychange event to prevent YouTube/media from pausing on tab blur
      window.addEventListener('visibilitychange', (e) => {
        if (this.isVisibilityOverrideActive) {
          this.log(`Visibility state changed to: ${document.visibilityState} (Override active: prevented pause)`);
          e.stopImmediatePropagation();
        }
      }, true);

      this.log('Page Visibility API override initialized.');
    } catch (err) {
      console.warn('Visibility override warning:', err);
    }
  }

  // 2. Audio Context Keep-Alive (Continuous silent frequency to prevent OS hardware sleep)
  public enableAudioContextKeepAlive(): boolean {
    try {
      if (!this.audioContext) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtx) {
          this.log('Web Audio API not supported in this environment.');
          return false;
        }
        this.audioContext = new AudioCtx();
      }

      if (this.audioContext.state === 'suspended') {
        this.audioContext.resume();
      }

      if (!this.silentOscillator) {
        this.silentOscillator = this.audioContext.createOscillator();
        this.silentGain = this.audioContext.createGain();

        // Sub-audible frequency with near-zero amplitude keeps audio thread alive
        this.silentOscillator.type = 'sine';
        this.silentOscillator.frequency.setValueAtTime(15, this.audioContext.currentTime); // 15 Hz sub-bass
        this.silentGain.gain.setValueAtTime(0.00001, this.audioContext.currentTime); // Inaudible

        this.silentOscillator.connect(this.silentGain);
        this.silentGain.connect(this.audioContext.destination);
        this.silentOscillator.start();
      }

      this.isAudioContextActive = true;
      this.log('WebAudio AudioContext keep-alive loop STARTED (Hardware audio context active).');
      return true;
    } catch (err: any) {
      this.log(`Failed to start AudioContext keep-alive: ${err.message}`);
      return false;
    }
  }

  public disableAudioContextKeepAlive() {
    try {
      if (this.silentOscillator) {
        this.silentOscillator.stop();
        this.silentOscillator.disconnect();
        this.silentOscillator = null;
      }
      this.isAudioContextActive = false;
      this.log('WebAudio AudioContext keep-alive loop STOPPED.');
    } catch (err: any) {
      this.log(`Error stopping AudioContext: ${err.message}`);
    }
  }

  // 3. MediaSession API (Lockscreen & OS System Media Control Integration)
  public updateMediaSession(
    track: AudioTrack,
    callbacks: {
      onPlay?: () => void;
      onPause?: () => void;
      onSeek?: (details: any) => void;
      onNext?: () => void;
      onPrev?: () => void;
    }
  ) {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: track.title,
          artist: track.artist,
          album: track.album || 'Chrome Background Audio',
          artwork: [
            { src: track.coverUrl, sizes: '96x96', type: 'image/jpeg' },
            { src: track.coverUrl, sizes: '256x256', type: 'image/jpeg' },
            { src: track.coverUrl, sizes: '512x512', type: 'image/jpeg' },
          ]
        });

        if (callbacks.onPlay) navigator.mediaSession.setActionHandler('play', callbacks.onPlay);
        if (callbacks.onPause) navigator.mediaSession.setActionHandler('pause', callbacks.onPause);
        if (callbacks.onNext) navigator.mediaSession.setActionHandler('nexttrack', callbacks.onNext);
        if (callbacks.onPrev) navigator.mediaSession.setActionHandler('previoustrack', callbacks.onPrev);

        navigator.mediaSession.playbackState = 'playing';
        this.isMediaSessionActive = true;
        this.log(`MediaSession registered for track: "${track.title}" by ${track.artist}`);
      } catch (err: any) {
        this.log(`MediaSession error: ${err.message}`);
      }
    } else {
      this.log('MediaSession API not supported by browser.');
    }
  }

  public setMediaSessionPlaybackState(state: 'playing' | 'paused' | 'none') {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = state;
      this.log(`MediaSession state set to: ${state}`);
    }
  }

  // 4. Wake Lock API
  public async requestWakeLock(): Promise<boolean> {
    if ('wakeLock' in navigator) {
      try {
        this.wakeLock = await (navigator as any).wakeLock.request('screen');
        this.isWakeLockActive = true;
        this.log('Screen Wake Lock acquired successfully (Display/Audio process priority boosted).');
        
        this.wakeLock.addEventListener('release', () => {
          this.isWakeLockActive = false;
          this.log('Screen Wake Lock was released.');
        });
        return true;
      } catch (err: any) {
        this.log(`Wake Lock request failed: ${err.message}`);
        return false;
      }
    } else {
      this.log('Wake Lock API not supported in this environment.');
      return false;
    }
  }

  public releaseWakeLock() {
    if (this.wakeLock) {
      this.wakeLock.release();
      this.wakeLock = null;
      this.isWakeLockActive = false;
      this.log('Screen Wake Lock released manually.');
    }
  }

  // Status Checkers
  public getStatus() {
    return {
      visibilityOverride: this.isVisibilityOverrideActive,
      audioContextActive: this.isAudioContextActive,
      mediaSessionActive: this.isMediaSessionActive,
      wakeLockActive: this.isWakeLockActive,
    };
  }

  public toggleVisibilityOverride(enable: boolean) {
    this.isVisibilityOverrideActive = enable;
    this.log(`Visibility override set to: ${enable}`);
  }
}

export const backgroundAudioService = new BackgroundAudioService();
