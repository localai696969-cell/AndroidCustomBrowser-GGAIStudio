import { AudioTrack } from '../types';

class BackgroundAudioService {
  private audioElement: HTMLAudioElement | null = null;
  private isPlaying: boolean = false;
  private currentTrack: AudioTrack | null = null;
  private listeners: Array<() => void> = [];

  constructor() {
    this.initAudio();
  }

  private initAudio() {
    if (typeof window === 'undefined') return;
    this.audioElement = new Audio();
    this.audioElement.loop = true;

    // Standard Relaxing Lofi stream loop
    this.audioElement.src = 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3';

    if ('mediaSession' in navigator) {
      navigator.mediaSession.setActionHandler('play', () => this.play());
      navigator.mediaSession.setActionHandler('pause', () => this.pause());
      navigator.mediaSession.setActionHandler('stop', () => this.pause());
    }
  }

  public setTrack(track: AudioTrack) {
    this.currentTrack = track;
    if ('mediaSession' in navigator && track) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.title,
        artist: track.artist,
        album: track.album,
        artwork: [
          { src: track.coverUrl, sizes: '512x512', type: 'image/png' },
        ],
      });
    }
    this.notify();
  }

  public play() {
    if (this.audioElement) {
      this.audioElement.play().then(() => {
        this.isPlaying = true;
        if ('mediaSession' in navigator) {
          navigator.mediaSession.playbackState = 'playing';
        }
        this.notify();
      }).catch(() => {
        this.isPlaying = false;
        this.notify();
      });
    }
  }

  public pause() {
    if (this.audioElement) {
      this.audioElement.pause();
      this.isPlaying = false;
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'paused';
      }
      this.notify();
    }
  }

  public togglePlay() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }
}

export const backgroundAudioService = new BackgroundAudioService();
