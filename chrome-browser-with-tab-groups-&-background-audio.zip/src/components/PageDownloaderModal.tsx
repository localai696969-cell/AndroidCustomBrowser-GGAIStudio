import React, { useState } from 'react';
import { FileText, Download, Globe, Code, FileCheck, ShieldCheck } from 'lucide-react';
import { PageDownloadFormat, Tab } from '../types';

interface PageDownloaderModalProps {
  activeTab: Tab | undefined;
  onClose: () => void;
  onDownloadPageFormat: (format: PageDownloadFormat, filename: string) => void;
}

export function PageDownloaderModal({
  activeTab,
  onClose,
  onDownloadPageFormat,
}: PageDownloaderModalProps) {
  const [selectedFormat, setSelectedFormat] = useState<PageDownloadFormat>('html');
  const [filename, setFilename] = useState(
    (activeTab?.title || 'page').toLowerCase().replace(/[^a-z0-9]/g, '_')
  );
  const [includeAssets, setIncludeAssets] = useState(true);

  const handleSave = () => {
    onDownloadPageFormat(selectedFormat, filename);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#242629] text-gray-100 rounded-xl w-full max-w-lg border border-gray-700 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-[#1A1C1E] px-6 py-4 border-b border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Lưu & Download Trang Web</h2>
              <p className="text-xs text-gray-400">
                Xuất file trang web ngoại tuyến theo các định dạng tùy chọn
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white px-3 py-1 rounded-lg hover:bg-gray-800 text-sm font-medium transition-colors"
          >
            Đóng ✕
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4 text-xs">
          <div>
            <label className="text-gray-300 font-semibold mb-1 block">Trang web hiện tại:</label>
            <div className="bg-[#1A1C1E] p-2.5 rounded-lg border border-gray-800 text-gray-300 truncate">
              {activeTab?.title || 'New Tab'} ({activeTab?.url || 'chrome://newtab'})
            </div>
          </div>

          <div>
            <label className="text-gray-300 font-semibold mb-1 block">Tên tập tin xuất:</label>
            <input
              type="text"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              className="w-full bg-[#1A1C1E] border border-gray-700 rounded-lg px-3 py-2 text-xs text-gray-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-gray-300 font-semibold mb-2 block">Chọn định dạng trang web:</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSelectedFormat('html')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  selectedFormat === 'html'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                    : 'bg-[#1A1C1E] border-gray-800 text-gray-400'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-xs text-gray-200">
                  <Code className="w-4 h-4 text-emerald-400" />
                  Single HTML (.html)
                </div>
                <p className="text-[10px] text-gray-400">Trang HTML hoàn chỉnh nhúng CSS/JS</p>
              </button>

              <button
                onClick={() => setSelectedFormat('mhtml')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  selectedFormat === 'mhtml'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                    : 'bg-[#1A1C1E] border-gray-800 text-gray-400'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-xs text-gray-200">
                  <FileCheck className="w-4 h-4 text-blue-400" />
                  Web Archive (.mhtml)
                </div>
                <p className="text-[10px] text-gray-400">Đóng gói lưu trữ toàn bộ hình ảnh</p>
              </button>

              <button
                onClick={() => setSelectedFormat('pdf')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  selectedFormat === 'pdf'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                    : 'bg-[#1A1C1E] border-gray-800 text-gray-400'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-xs text-gray-200">
                  <FileText className="w-4 h-4 text-red-400" />
                  Tài Liệu PDF (.pdf)
                </div>
                <p className="text-[10px] text-gray-400">In tài liệu chuẩn trang A4/Letter</p>
              </button>

              <button
                onClick={() => setSelectedFormat('txt')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  selectedFormat === 'txt'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                    : 'bg-[#1A1C1E] border-gray-800 text-gray-400'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-xs text-gray-200">
                  <FileText className="w-4 h-4 text-amber-400" />
                  Văn Bản Thuần (.txt)
                </div>
                <p className="text-[10px] text-gray-400">Chỉ trích xuất nội dung chữ</p>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2 border-t border-gray-800">
            <input
              type="checkbox"
              id="includeAssets"
              checked={includeAssets}
              onChange={(e) => setIncludeAssets(e.target.checked)}
              className="rounded bg-gray-800 border-gray-700 text-emerald-500 focus:ring-emerald-500"
            />
            <label htmlFor="includeAssets" className="text-gray-300 text-xs">
              Tự động tối ưu hình ảnh và stylesheet offline
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#1A1C1E] px-6 py-4 border-t border-gray-800 flex items-center justify-between">
          <span className="text-[11px] text-gray-500 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Tự động quét an toàn
          </span>
          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition-all"
          >
            <Download className="w-4 h-4" />
            Tải Trang Web (.{(selectedFormat).toUpperCase()})
          </button>
        </div>
      </div>
    </div>
  );
}
