import React, { useState } from 'react';
import { Tab, PageDownloadFormat } from '../types';
import { X, Globe, Download, FileCode, FileText, CheckCircle2 } from 'lucide-react';

interface PageDownloaderModalProps {
  activeTab: Tab | undefined;
  onClose: () => void;
  onDownloadPageFormat: (format: PageDownloadFormat, filename: string) => void;
}

export function PageDownloaderModal({
  activeTab,
  onClose,
  onDownloadPageFormat,
}: PageDownloaderModalProps) {
  const [selectedFormat, setSelectedFormat] = useState<PageDownloadFormat>('mhtml');
  const [filename, setFilename] = useState(
    (activeTab?.title || 'WebPage_Capture').replace(/[^a-zA-Z0-9_\- ]/g, '_')
  );

  const handleDownload = () => {
    if (filename.trim()) {
      onDownloadPageFormat(selectedFormat, filename.trim());
      onClose();
    }
  };

  const formats: Array<{ id: PageDownloadFormat; label: string; desc: string; icon: React.ReactNode }> = [
    {
      id: 'mhtml',
      label: 'File Lưu Web Đầy Đủ (.MHTML)',
      desc: 'Đóng gói toàn bộ hình ảnh, CSS và JS của trang vào duy nhất 1 tệp.',
      icon: <Globe className="w-5 h-5 text-emerald-400" />,
    },
    {
      id: 'html',
      label: 'Trang HTML Đơn Lẻ (.HTML)',
      desc: 'Lưu cấu trúc mã nguồn HTML để mở bằng bất kỳ trình duyệt nào.',
      icon: <FileCode className="w-5 h-5 text-blue-400" />,
    },
    {
      id: 'pdf',
      label: 'Tệp Tài Liệu PDF (.PDF)',
      desc: 'Xuất giao diện trang web thành tệp PDF chất lượng cao để in ấn.',
      icon: <FileText className="w-5 h-5 text-red-400" />,
    },
    {
      id: 'txt',
      label: 'Văn Bản Thuần (.TXT)',
      desc: 'Trích xuất nội dung văn bản thuần túy không chứa thẻ mã HTML.',
      icon: <FileText className="w-5 h-5 text-gray-400" />,
    },
  ];

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242629] border border-gray-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl text-gray-100">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800 bg-[#1E2022]">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-600 text-white">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Lưu Trang Web Ngoại Tuyến (Offline)</h2>
              <p className="text-[11px] text-gray-400">Xuất toàn bộ trang web theo nhiều định dạng tệp</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-gray-400 mb-1">Tên Tệp Xuất Ra:</label>
            <input
              type="text"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              className="w-full bg-[#1A1C1E] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500 font-semibold"
            />
          </div>

          <div>
            <label className="block font-semibold text-gray-400 mb-2">Chọn Định Dạng Lưu:</label>
            <div className="space-y-2">
              {formats.map((fmt) => (
                <div
                  key={fmt.id}
                  onClick={() => setSelectedFormat(fmt.id)}
                  className={`p-3 rounded-xl border cursor-pointer flex items-start gap-3 transition-all ${
                    selectedFormat === fmt.id
                      ? 'bg-emerald-600/10 border-emerald-500/50 text-white'
                      : 'bg-[#1A1C1E] border-gray-800 text-gray-400 hover:border-gray-700'
                  }`}
                >
                  <div className="mt-0.5">{fmt.icon}</div>
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-xs flex items-center justify-between">
                      <span>{fmt.label}</span>
                      {selectedFormat === fmt.id && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                    </p>
                    <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">{fmt.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-800">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold"
            >
              Hủy
            </button>
            <button
              onClick={handleDownload}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              Lưu Trang Web ngay
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
