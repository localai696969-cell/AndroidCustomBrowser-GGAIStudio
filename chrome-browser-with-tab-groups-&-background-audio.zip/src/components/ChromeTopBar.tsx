import React, { useState } from 'react';
import { Tab, TabGroup } from '../types';
import { COLOR_MAP } from '../data/initialData';
import { TabGroupHeader } from './TabGroupHeader';
import { Plus, X, Search, Layers, ShieldCheck, Sparkles, Youtube, FileText, Globe } from 'lucide-react';

interface ChromeTopBarProps {
  tabs: Tab[];
  groups: TabGroup[];
  activeTabId: string;
  onSelectTab: (tabId: string) => void;
  onCloseTab: (tabId: string) => void;
  onNewTab: () => void;
  onToggleGroupCollapse: (groupId: string) => void;
  onUpdateGroup: (group: TabGroup) => void;
  onDeleteGroup: (groupId: string) => void;
  onAddTabToGroup: (groupId: string) => void;
  onCreateGroupModal: () => void;
  isPlayingAudio: boolean;
}

export const ChromeTopBar: React.FC<ChromeTopBarProps> = ({
  tabs,
  groups,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
  onToggleGroupCollapse,
  onUpdateGroup,
  onDeleteGroup,
  onAddTabToGroup,
  onCreateGroupModal,
  isPlayingAudio,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const getTabIcon = (type: Tab['type']) => {
    switch (type) {
      case 'youtube':
        return <Youtube className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />;
      case 'techdocs':
        return <FileText className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />;
      case 'google':
        return <Globe className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />;
      default:
        return <Globe className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />;
    }
  };

  const filteredTabs = searchQuery
    ? tabs.filter((t) => t.title.toLowerCase().includes(searchQuery.toLowerCase()))
    : tabs;

  return (
    <div className="bg-[#DEE1E6] dark:bg-[#1E2022] border-b border-gray-300 dark:border-gray-800 select-none pt-2 px-3 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
      {/* Left: Window Dots & Tab Strip */}
      <div className="flex items-center gap-2 flex-1 min-w-0">
        {/* macOS Style Window Controls */}
        <div className="flex items-center gap-1.5 mr-2 flex-shrink-0">
          <div className="w-3 h-3 rounded-full bg-red-500 hover:brightness-90 transition-all cursor-pointer" title="Đóng cửa sổ" />
          <div className="w-3 h-3 rounded-full bg-yellow-500 hover:brightness-90 transition-all cursor-pointer" title="Thu nhỏ" />
          <div className="w-3 h-3 rounded-full bg-green-500 hover:brightness-90 transition-all cursor-pointer" title="Phóng to" />
        </div>

        {/* Tab Strip Container */}
        <div className="flex items-center gap-1.5 flex-1 overflow-x-auto no-scrollbar py-0.5">
          {/* Render Tab Groups and Un-grouped Tabs */}
          {groups.map((group) => {
            const groupTabs = tabs.filter((t) => t.groupId === group.id);
            const style = COLOR_MAP[group.color] || COLOR_MAP.blue;

            return (
              <div
                key={group.id}
                className={`flex items-center gap-1 p-1 rounded-lg transition-all ${
                  group.collapsed ? 'bg-gray-200/50 dark:bg-gray-800/50' : style.badge + ' bg-opacity-10'
                }`}
              >
                <TabGroupHeader
                  group={group}
                  tabCount={groupTabs.length}
                  onToggleCollapse={onToggleGroupCollapse}
                  onUpdateGroup={onUpdateGroup}
                  onDeleteGroup={onDeleteGroup}
                  onAddTabToGroup={onAddTabToGroup}
                />

                {/* Tabs inside group */}
                {!group.collapsed &&
                  groupTabs.map((tab) => {
                    const isActive = tab.id === activeTabId;
                    return (
                      <div
                        key={tab.id}
                        onClick={() => onSelectTab(tab.id)}
                        className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-t-lg max-w-[180px] min-w-[120px] text-xs cursor-pointer transition-all ${
                          isActive
                            ? 'bg-white dark:bg-[#2B2D30] text-gray-900 dark:text-white font-medium shadow-sm border-t-2 ' +
                              style.border
                            : 'bg-white/40 dark:bg-gray-800/40 text-gray-700 dark:text-gray-300 hover:bg-white/70 dark:hover:bg-gray-800'
                        }`}
                      >
                        {getTabIcon(tab.type)}
                        <span className="truncate flex-1 text-left">{tab.title}</span>

                        {/* Audio equalizer indicator if playing */}
                        {tab.type === 'youtube' && isPlayingAudio && (
                          <span className="flex items-end gap-0.5 h-3 flex-shrink-0" title="Đang phát âm thanh">
                            <span className="w-0.5 h-2.5 bg-red-500 animate-pulse" />
                            <span className="w-0.5 h-3 bg-red-500 animate-pulse delay-75" />
                            <span className="w-0.5 h-1.5 bg-red-500 animate-pulse delay-150" />
                          </span>
                        )}

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onCloseTab(tab.id);
                          }}
                          className="p-0.5 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full opacity-60 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    );
                  })}
              </div>
            );
          })}

          {/* Un-grouped Tabs */}
          {tabs
            .filter((t) => !t.groupId)
            .map((tab) => {
              const isActive = tab.id === activeTabId;
              return (
                <div
                  key={tab.id}
                  onClick={() => onSelectTab(tab.id)}
                  className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-t-lg max-w-[200px] min-w-[130px] text-xs cursor-pointer transition-all ${
                    isActive
                      ? 'bg-white dark:bg-[#2B2D30] text-gray-900 dark:text-white font-medium shadow-sm border-t-2 border-blue-500'
                      : 'bg-white/40 dark:bg-gray-800/40 text-gray-700 dark:text-gray-300 hover:bg-white/70 dark:hover:bg-gray-800'
                  }`}
                >
                  {getTabIcon(tab.type)}
                  <span className="truncate flex-1 text-left">{tab.title}</span>

                  {tab.type === 'youtube' && isPlayingAudio && (
                    <span className="flex items-end gap-0.5 h-3 flex-shrink-0" title="Đang phát âm thanh">
                      <span className="w-0.5 h-2.5 bg-red-500 animate-pulse" />
                      <span className="w-0.5 h-3 bg-red-500 animate-pulse delay-75" />
                    </span>
                  )}

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseTab(tab.id);
                    }}
                    className="p-0.5 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full opacity-60 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}

          {/* New Tab Button */}
          <button
            onClick={onNewTab}
            className="p-1.5 hover:bg-black/10 dark:hover:bg-white/10 rounded-full transition-colors text-gray-700 dark:text-gray-300 flex-shrink-0"
            title="Thẻ mới (Ctrl+T)"
          >
            <Plus className="w-4 h-4" />
          </button>

          {/* Create Group Button */}
          <button
            onClick={onCreateGroupModal}
            className="flex items-center gap-1 text-[11px] font-medium px-2 py-1 rounded-md bg-white/60 dark:bg-gray-800/60 hover:bg-white dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 transition-all flex-shrink-0 shadow-xs"
            title="Tạo Nhóm Tab Mới"
          >
            <Layers className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
            <span>Tạo Nhóm</span>
          </button>
        </div>
      </div>

      {/* Right Controls: Search Tabs & Status */}
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <div className="relative">
          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className="p-1.5 hover:bg-black/10 dark:hover:bg-white/10 rounded-full transition-colors text-gray-700 dark:text-gray-300"
            title="Tìm kiếm các tab"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Search Tabs Dropdown */}
          {isSearchOpen && (
            <div className="absolute right-0 top-full mt-1 w-72 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 p-2 z-50">
              <input
                type="text"
                placeholder="Tìm tab..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
                className="w-full px-2.5 py-1.5 text-xs bg-gray-100 dark:bg-gray-900 rounded border border-gray-300 dark:border-gray-700 outline-none focus:border-blue-500 mb-2 text-gray-900 dark:text-white"
              />
              <div className="max-h-48 overflow-y-auto divide-y divide-gray-100 dark:divide-gray-700">
                {filteredTabs.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => {
                      onSelectTab(t.id);
                      setIsSearchOpen(false);
                    }}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer text-xs flex items-center justify-between"
                  >
                    <div className="truncate font-medium text-gray-800 dark:text-gray-200">{t.title}</div>
                    <span className="text-[10px] text-gray-400 capitalize">{t.type}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Badge */}
        <div className="flex items-center gap-1 bg-white/50 dark:bg-gray-800/50 px-2 py-0.5 rounded-full text-xs font-medium text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700">
          <div className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold">
            G
          </div>
          <span className="hidden md:inline">Chrome Pro</span>
        </div>
      </div>
    </div>
  );
};
