import React from 'react';
import { Tab, TabGroup } from '../types';
import { TabGroupHeader } from './TabGroupHeader';
import { Plus, X, Volume2, Globe, Youtube, FileCode, Layers } from 'lucide-react';

interface ChromeTopBarProps {
  tabs: Tab[];
  tabGroups: TabGroup[];
  activeTabId: string;
  onSelectTab: (tabId: string) => void;
  onCloseTab: (tabId: string, e?: React.MouseEvent) => void;
  onNewTab: () => void;
  onToggleGroupCollapse: (groupId: string) => void;
  onOpenGroupManager: () => void;
  isPlayingAudio: boolean;
}

export function ChromeTopBar({
  tabs,
  tabGroups,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
  onToggleGroupCollapse,
  onOpenGroupManager,
  isPlayingAudio,
}: ChromeTopBarProps) {
  // Group tabs by groupId or unassigned
  const groupsMap = new Map<string, Tab[]>();
  const unassignedTabs: Tab[] = [];

  tabs.forEach((tab) => {
    if (tab.groupId) {
      if (!groupsMap.has(tab.groupId)) {
        groupsMap.set(tab.groupId, []);
      }
      groupsMap.get(tab.groupId)!.push(tab);
    } else {
      unassignedTabs.push(tab);
    }
  });

  const getTabIcon = (tab: Tab) => {
    if (tab.type === 'youtube') return <Youtube className="w-3.5 h-3.5 text-red-500" />;
    if (tab.type === 'techdocs') return <FileCode className="w-3.5 h-3.5 text-blue-400" />;
    return <Globe className="w-3.5 h-3.5 text-gray-400" />;
  };

  return (
    <div className="bg-[#1E2022] border-b border-gray-800 flex items-center px-2 pt-2 gap-1 overflow-x-auto select-none">
      {/* Group Manager Button */}
      <button
        onClick={onOpenGroupManager}
        className="p-1.5 rounded-lg text-gray-400 hover:text-gray-200 hover:bg-gray-800 transition-colors flex items-center gap-1 text-xs font-medium mr-1"
        title="Quản Lý Nhóm Tab (Tab Groups)"
      >
        <Layers className="w-4 h-4 text-purple-400" />
        <span className="hidden sm:inline">Nhóm Tab</span>
      </button>

      {/* Render Groups and their Tabs */}
      {tabGroups.map((group) => {
        const groupTabs = groupsMap.get(group.id) || [];
        if (groupTabs.length === 0) return null;

        return (
          <div key={group.id} className="flex items-center gap-1 border-r border-gray-800 pr-2 mr-1">
            <TabGroupHeader group={group} onToggleCollapse={onToggleGroupCollapse} />

            {!group.collapsed &&
              groupTabs.map((tab) => {
                const isActive = tab.id === activeTabId;
                return (
                  <div
                    key={tab.id}
                    onClick={() => onSelectTab(tab.id)}
                    className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs font-medium cursor-pointer transition-all min-w-[120px] max-w-[180px] border-t border-x ${
                      isActive
                        ? 'bg-[#2B2D30] text-white border-gray-700 shadow-sm'
                        : 'bg-transparent text-gray-400 border-transparent hover:bg-gray-800/60 hover:text-gray-200'
                    }`}
                  >
                    {getTabIcon(tab)}
                    <span className="truncate flex-1">{tab.title}</span>

                    {tab.isPlayingAudio && isPlayingAudio && (
                      <Volume2 className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
                    )}

                    <button
                      onClick={(e) => onCloseTab(tab.id, e)}
                      className="opacity-0 group-hover:opacity-100 p-0.5 rounded-full hover:bg-gray-700 text-gray-400 hover:text-white transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}
          </div>
        );
      })}

      {/* Unassigned Tabs */}
      {unassignedTabs.map((tab) => {
        const isActive = tab.id === activeTabId;
        return (
          <div
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs font-medium cursor-pointer transition-all min-w-[120px] max-w-[180px] border-t border-x ${
              isActive
                ? 'bg-[#2B2D30] text-white border-gray-700 shadow-sm'
                : 'bg-transparent text-gray-400 border-transparent hover:bg-gray-800/60 hover:text-gray-200'
            }`}
          >
            {getTabIcon(tab)}
            <span className="truncate flex-1">{tab.title}</span>

            {tab.isPlayingAudio && isPlayingAudio && (
              <Volume2 className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
            )}

            <button
              onClick={(e) => onCloseTab(tab.id, e)}
              className="opacity-0 group-hover:opacity-100 p-0.5 rounded-full hover:bg-gray-700 text-gray-400 hover:text-white transition-opacity"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        );
      })}

      {/* New Tab Button */}
      <button
        onClick={onNewTab}
        className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors ml-1"
        title="Thẻ Mới (Ctrl + T)"
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
}
