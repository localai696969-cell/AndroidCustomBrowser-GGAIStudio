import React, { useState } from 'react';
import { TabGroup, TabGroupColor, Tab } from '../types';
import { COLOR_MAP } from '../data/initialData';
import { X, Layers, Plus, Trash2, Check } from 'lucide-react';

interface TabGroupsModalProps {
  groups: TabGroup[];
  tabs: Tab[];
  onClose: () => void;
  onCreateGroup: (title: string, color: TabGroupColor) => void;
  onDeleteGroup: (groupId: string) => void;
  onAssignTabToGroup: (tabId: string, groupId: string | undefined) => void;
}

const COLORS: TabGroupColor[] = ['blue', 'red', 'yellow', 'green', 'pink', 'purple', 'cyan', 'orange'];

export const TabGroupsModal: React.FC<TabGroupsModalProps> = ({
  groups,
  tabs,
  onClose,
  onCreateGroup,
  onDeleteGroup,
  onAssignTabToGroup,
}) => {
  const [newTitle, setNewTitle] = useState('');
  const [selectedColor, setSelectedColor] = useState<TabGroupColor>('purple');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTitle.trim()) {
      onCreateGroup(newTitle.trim(), selectedColor);
      setNewTitle('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#2B2D30] rounded-2xl max-w-lg w-full border border-gray-200 dark:border-gray-700 shadow-2xl p-6 text-gray-900 dark:text-gray-100 space-y-6">
        <div className="flex items-center justify-between border-b border-gray-200 dark:border-gray-700 pb-3">
          <div className="flex items-center gap-2 font-bold text-base">
            <Layers className="w-5 h-5 text-purple-600" />
            <span>Quản Lý Nhóm Tab (Tab Groups)</span>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Create New Group Form */}
        <form onSubmit={handleCreate} className="space-y-3 bg-gray-50 dark:bg-gray-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700">
          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Tạo Nhóm Tab Mới</div>

          <div className="flex gap-2">
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Nhập tên nhóm tab (ví dụ: Học tập, Nhạc Lofi)..."
              className="flex-1 px-3 py-1.5 text-xs bg-white dark:bg-gray-900 rounded-lg border border-gray-300 dark:border-gray-700 outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={!newTitle.trim()}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Tạo Nhóm
            </button>
          </div>

          {/* Color selector */}
          <div className="flex items-center gap-2 pt-1">
            <span className="text-xs text-gray-500">Màu sắc:</span>
            <div className="flex items-center gap-2">
              {COLORS.map((c) => {
                const style = COLOR_MAP[c];
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setSelectedColor(c)}
                    className={`w-6 h-6 rounded-full ${style.bg} flex items-center justify-center transition-transform ${
                      selectedColor === c ? 'ring-2 ring-offset-2 ring-blue-500 scale-110' : 'hover:scale-105'
                    }`}
                  />
                );
              })}
            </div>
          </div>
        </form>

        {/* Existing Groups List & Tab Assignment */}
        <div className="space-y-3">
          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Danh Sách Nhóm Đang Có</div>

          <div className="max-h-60 overflow-y-auto space-y-3 pr-1">
            {groups.map((group) => {
              const style = COLOR_MAP[group.color] || COLOR_MAP.blue;
              const groupTabs = tabs.filter((t) => t.groupId === group.id);

              return (
                <div key={group.id} className={`p-3 rounded-xl border ${style.badge} bg-opacity-20 border-black/10 dark:border-white/10 space-y-2`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${style.bg}`} />
                      <span className="font-bold text-xs">{group.title}</span>
                      <span className="text-[10px] opacity-75 font-mono">({groupTabs.length} tabs)</span>
                    </div>

                    <button
                      onClick={() => onDeleteGroup(group.id)}
                      className="p-1 hover:bg-red-100 dark:hover:bg-red-900/50 text-red-600 rounded transition-colors"
                      title="Xóa nhóm"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Move tabs into group */}
                  <div className="text-[11px] text-gray-600 dark:text-gray-400">Các tab thuộc nhóm:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {tabs.map((tab) => {
                      const inThisGroup = tab.groupId === group.id;
                      return (
                        <button
                          key={tab.id}
                          onClick={() => onAssignTabToGroup(tab.id, inThisGroup ? undefined : group.id)}
                          className={`px-2 py-0.5 rounded text-[10px] border flex items-center gap-1 transition-all ${
                            inThisGroup
                              ? 'bg-blue-600 text-white border-blue-600 font-bold'
                              : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-700 hover:bg-gray-100'
                          }`}
                        >
                          <span>{tab.title}</span>
                          {inThisGroup && <Check className="w-3 h-3" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
