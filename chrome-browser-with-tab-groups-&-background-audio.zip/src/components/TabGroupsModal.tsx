import React, { useState } from 'react';
import { Tab, TabGroup, TabGroupColor } from '../types';
import { X, Layers, Plus, Check } from 'lucide-react';

interface TabGroupsModalProps {
  tabs: Tab[];
  tabGroups: TabGroup[];
  onClose: () => void;
  onCreateGroup: (name: string, color: TabGroupColor, tabIds: string[]) => void;
}

const COLORS: TabGroupColor[] = ['grey', 'blue', 'red', 'yellow', 'green', 'pink', 'purple', 'cyan'];

export function TabGroupsModal({ tabs, tabGroups, onClose, onCreateGroup }: TabGroupsModalProps) {
  const [groupName, setGroupName] = useState('');
  const [selectedColor, setSelectedColor] = useState<TabGroupColor>('blue');
  const [selectedTabIds, setSelectedTabIds] = useState<string[]>([]);

  const handleToggleTabSelect = (id: string) => {
    setSelectedTabIds((prev) =>
      prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]
    );
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (groupName.trim() && selectedTabIds.length > 0) {
      onCreateGroup(groupName.trim(), selectedColor, selectedTabIds);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242629] border border-gray-700 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl text-gray-100">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-purple-400" />
            <h2 className="text-base font-bold">Quản Lý Nhóm Tab (Tab Groups)</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleCreate} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-400 mb-1">Tên Nhóm Mới</label>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="Ví dụ: Công Việc, Giải Trí, Lofi Study..."
              className="w-full bg-[#1A1C1E] border border-gray-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-400 mb-1">Màu Sắc Nhóm</label>
            <div className="flex items-center gap-2">
              {COLORS.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setSelectedColor(color)}
                  className={`w-6 h-6 rounded-full flex items-center justify-center transition-transform ${
                    color === 'blue'
                      ? 'bg-blue-500'
                      : color === 'red'
                      ? 'bg-red-500'
                      : color === 'green'
                      ? 'bg-emerald-500'
                      : color === 'purple'
                      ? 'bg-purple-500'
                      : color === 'pink'
                      ? 'bg-pink-500'
                      : color === 'yellow'
                      ? 'bg-yellow-500'
                      : color === 'cyan'
                      ? 'bg-cyan-500'
                      : 'bg-gray-500'
                  } ${selectedColor === color ? 'scale-125 ring-2 ring-white' : 'opacity-70 hover:opacity-100'}`}
                >
                  {selectedColor === color && <Check className="w-3 h-3 text-white" />}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-400 mb-1">Chọn Các Thẻ (Tabs) Đưa Vào Nhóm</label>
            <div className="max-h-40 overflow-y-auto space-y-1 bg-[#1A1C1E] border border-gray-800 p-2 rounded-lg">
              {tabs.map((tab) => (
                <label
                  key={tab.id}
                  className="flex items-center gap-2 p-1.5 rounded hover:bg-gray-800 cursor-pointer text-xs"
                >
                  <input
                    type="checkbox"
                    checked={selectedTabIds.includes(tab.id)}
                    onChange={() => handleToggleTabSelect(tab.id)}
                    className="rounded bg-gray-700 border-gray-600 text-purple-600 focus:ring-0"
                  />
                  <span className="truncate flex-1">{tab.title}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-xs font-semibold text-gray-300"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Tạo Nhóm Tab
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
