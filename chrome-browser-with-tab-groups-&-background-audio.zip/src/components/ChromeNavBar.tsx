import React, { useState, useEffect } from 'react';
import { Tab, EngineConfig } from '../types';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Lock,
  Star,
  Copy,
  Check,
  Puzzle,
  MoreVertical,
  Volume2,
  Bookmark as BookmarkIcon,
  History as HistoryIcon,
  Settings as SettingsIcon,
  FileText,
  Download,
  Youtube,
  Globe,
  Cpu,
} from 'lucide-react';

interface ChromeNavBarProps {
  activeTab: Tab | undefined;
  onNavigateUrl: (url: string) => void;
  onOpenHistory: () => void;
  onOpenBookmarks: () => void;
  onOpenSettings: () => void;
  onOpenExtensions: () => void;
  onOpenTechDocs: () => void;
  onOpenIDMSniffer: () => void;
  onOpenPlaylistDownloader: () => void;
  onOpenPageDownloader: () => void;
  engineConfig: EngineConfig;
  onToggleEngine: () => void;
  isPlayingAudio: boolean;
  onToggleBookmarksBar: () => void;
  showBookmarksBar: boolean;
  isBookmarked: boolean;
  onToggleBookmarkCurrent: () => void;
  detectedMediaCount: number;
}

export const ChromeNavBar: React.FC<ChromeNavBarProps> = ({
  activeTab,
  onNavigateUrl,
  onOpenHistory,
  onOpenBookmarks,
  onOpenSettings,
  onOpenExtensions,
  onOpenTechDocs,
  onOpenIDMSniffer,
  onOpenPlaylistDownloader,
  onOpenPageDownloader,
  engineConfig,
  onToggleEngine,
  isPlayingAudio,
  onToggleBookmarksBar,
  showBookmarksBar,
  isBookmarked,
  onToggleBookmarkCurrent,
  detectedMediaCount,
}) => {

  const [urlInput, setUrlInput] = useState(activeTab?.url || 'chrome://newtab');
  const [isCopied, setIsCopied] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    if (activeTab) {
      setUrlInput(activeTab.url);
    }
  }, [activeTab]);

  const handleSubmitUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (urlInput.trim()) {
      onNavigateUrl(urlInput.trim());
    }
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(urlInput);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="bg-white dark:bg-[#2B2D30] border-b border-gray-200 dark:border-gray-800 px-3 py-1.5 flex items-center gap-2 select-none">
      {/* Back, Forward, Refresh, Home */}
      <div className="flex items-center gap-1 text-gray-600 dark:text-gray-300">
        <button
          className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors disabled:opacity-40"
          title="Quay lại"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button
          className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors disabled:opacity-40"
          title="Tiến lên"
        >
          <ArrowRight className="w-4 h-4" />
        </button>
        <button
          onClick={() => activeTab && onNavigateUrl(activeTab.url)}
          className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
          title="Tải lại trang"
        >
          <RotateCw className="w-4 h-4" />
        </button>
        <button
          onClick={() => onNavigateUrl('chrome://newtab')}
          className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
          title="Trang chủ (New Tab)"
        >
          <Home className="w-4 h-4" />
        </button>
      </div>

      {/* Chrome Omnibox Address Bar */}
      <form onSubmit={handleSubmitUrl} className="flex-1 max-w-4xl">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-[#F1F3F4] dark:bg-[#1E2022] hover:bg-gray-200/80 dark:hover:bg-gray-900 rounded-full border border-transparent focus-within:border-blue-500 focus-within:bg-white dark:focus-within:bg-gray-900 focus-within:shadow-md transition-all text-xs">
          <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />

          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="Tìm kiếm bằng Google hoặc nhập URL"
            className="w-full bg-transparent border-none outline-none text-gray-900 dark:text-gray-100 font-normal"
          />

          <div className="flex items-center gap-1 text-gray-400">
            <button
              type="button"
              onClick={handleCopyUrl}
              className="p-1 hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
              title="Sao chép địa chỉ URL"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>

            <button
              type="button"
              onClick={onToggleBookmarkCurrent}
              className="p-1 hover:text-yellow-500 transition-colors"
              title={isBookmarked ? 'Đã thêm vào dấu trang' : 'Thêm dấu trang'}
            >
              <Star className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-yellow-400 text-yellow-400' : ''}`} />
            </button>
          </div>
        </div>
      </form>

      {/* Extensions & Tools Bar */}
      <div className="flex items-center gap-1.5 text-gray-600 dark:text-gray-300">
        {/* Engine Config Badge / Toggle */}
        <button
          onClick={onToggleEngine}
          className="p-1.5 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg text-[10px] font-bold text-blue-600 dark:text-blue-400 border border-gray-200 dark:border-gray-700 flex items-center gap-1 transition-all"
          title={`Engine: ${engineConfig.type === 'chromium' ? 'Chromium V128 Engine' : 'Firefox GeckoView Engine'}. Click to toggle.`}
        >
          <Cpu className="w-3.5 h-3.5 text-purple-400" />
          <span className="uppercase">{engineConfig.type}</span>
        </button>

        {/* IDM Sniffer Launcher Button */}
        <button
          onClick={onOpenIDMSniffer}
          className="relative p-1.5 bg-blue-50 dark:bg-blue-900/30 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-lg transition-all border border-blue-500/30 flex items-center gap-1 text-xs font-semibold"
          title="IDM Multimedia Sniffer - Bắt link video/audio trên trang"
        >
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline">IDM</span>
          {detectedMediaCount > 0 && (
            <span className="bg-blue-600 text-white text-[9px] font-extrabold px-1.5 py-0.2 rounded-full animate-pulse">
              {detectedMediaCount}
            </span>
          )}
        </button>

        {/* YouTube & Playlist Downloader */}
        <button
          onClick={onOpenPlaylistDownloader}
          className="p-1.5 bg-red-50 dark:bg-red-900/30 hover:bg-red-100 dark:hover:bg-red-900/50 text-red-600 dark:text-red-400 rounded-lg transition-all border border-red-500/30 flex items-center gap-1 text-xs font-semibold"
          title="Tải Video & Playlist YouTube"
        >
          <Youtube className="w-4 h-4" />
          <span className="hidden md:inline">Tải Playlist</span>
        </button>

        {/* Save Page Button */}
        <button
          onClick={onOpenPageDownloader}
          className="p-1.5 bg-emerald-50 dark:bg-emerald-900/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 rounded-lg transition-all border border-emerald-500/30 flex items-center gap-1 text-xs font-semibold"
          title="Lưu trang web (HTML, MHTML, PDF, TXT)"
        >
          <Globe className="w-4 h-4" />
          <span className="hidden lg:inline">Lưu Trang</span>
        </button>

        {/* Background Audio Extension Indicator */}
        <button
          onClick={onOpenExtensions}
          className={`relative p-1.5 rounded-full transition-all flex items-center gap-1 ${
            isPlayingAudio
              ? 'bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 ring-2 ring-red-400/50'
              : 'hover:bg-gray-100 dark:hover:bg-gray-700'
          }`}
          title="YouTube Background Audio Keeper Extension"
        >
          <Volume2 className={`w-4 h-4 ${isPlayingAudio ? 'animate-bounce' : ''}`} />
          {isPlayingAudio && <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />}
        </button>

        <button
          onClick={onOpenExtensions}
          className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
          title="Tiện ích mở rộng (Extensions)"
        >
          <Puzzle className="w-4 h-4" />
        </button>

        {/* Chrome Settings Menu Dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
            title="Tùy chỉnh và điều khiển Google Chrome"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {isMenuOpen && (
            <div
              className="absolute right-0 top-full mt-1 w-64 bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 py-2 z-50 text-xs text-gray-800 dark:text-gray-200"
              onClick={() => setIsMenuOpen(false)}
            >
              <div className="px-3 py-1 font-semibold text-gray-400 dark:text-gray-500 uppercase text-[10px] tracking-wider">
                Google Chrome Menu
              </div>

              <button
                onClick={onOpenIDMSniffer}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-blue-50 dark:hover:bg-gray-700 text-blue-600 dark:text-blue-400 font-medium"
              >
                <Download className="w-4 h-4" />
                <span>⚡ IDM Multimedia Sniffer ({detectedMediaCount} link)</span>
              </button>

              <button
                onClick={onOpenPlaylistDownloader}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-red-50 dark:hover:bg-gray-700 text-red-600 dark:text-red-400 font-medium"
              >
                <Youtube className="w-4 h-4" />
                <span>🎬 Tải Video & Playlist YouTube</span>
              </button>

              <button
                onClick={onOpenPageDownloader}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-emerald-50 dark:hover:bg-gray-700 text-emerald-600 dark:text-emerald-400 font-medium"
              >
                <Globe className="w-4 h-4" />
                <span>🌐 Lưu trang web (HTML/MHTML/PDF)</span>
              </button>

              <div className="my-1 border-t border-gray-100 dark:border-gray-700" />

              <button
                onClick={onOpenTechDocs}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-blue-50 dark:hover:bg-gray-700 text-blue-600 dark:text-blue-400 font-medium"
              >
                <FileText className="w-4 h-4" />
                <span>📘 Tài Liệu Kỹ Thuật (Tech Specs)</span>
              </button>

              <button
                onClick={onOpenHistory}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <HistoryIcon className="w-4 h-4 text-gray-500" />
                <span>Lịch sử truy cập (History)</span>
              </button>

              <button
                onClick={onOpenBookmarks}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <BookmarkIcon className="w-4 h-4 text-yellow-500" />
                <span>Dấu trang (Bookmarks)</span>
              </button>

              <button
                onClick={onToggleBookmarksBar}
                className="w-full px-3 py-2 text-left flex items-center justify-between hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <span className="flex items-center gap-3">
                  <Star className="w-4 h-4 text-amber-500" />
                  <span>Hiển thị thanh Dấu trang</span>
                </span>
                <span className="text-[10px] bg-gray-200 dark:bg-gray-700 px-1.5 py-0.5 rounded">
                  {showBookmarksBar ? 'Bật' : 'Tắt'}
                </span>
              </button>

              <div className="my-1 border-t border-gray-100 dark:border-gray-700" />

              <button
                onClick={onOpenSettings}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <SettingsIcon className="w-4 h-4 text-gray-500" />
                <span>Cài đặt trình duyệt (Settings)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
