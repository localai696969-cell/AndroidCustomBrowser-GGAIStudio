import React, { useState, useEffect } from 'react';
import { Tab, EngineConfig } from '../types';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Star,
  Shield,
  MoreVertical,
  Volume2,
  VolumeX,
  History as HistoryIcon,
  Settings as SettingsIcon,
  FileText,
  Download,
  Youtube,
  Globe,
  Cpu,
} from 'lucide-react';

interface ChromeNavBarProps {
  activeTab: Tab | undefined;
  onNavigate: (url: string) => void;
  onOpenSettings: () => void;
  onOpenExtensions: () => void;
  onOpenTechDocs: () => void;
  onOpenIDMSniffer: () => void;
  onOpenPlaylistDownloader: () => void;
  onOpenPageDownloader: () => void;
  engineConfig: EngineConfig;
  onToggleEngine: () => void;
  isPlayingAudio: boolean;
  onToggleBookmarksBar: () => void;
  showBookmarksBar: boolean;
  onToggleBookmarkCurrent: () => void;
  detectedMediaCount: number;
}

export const ChromeNavBar: React.FC<ChromeNavBarProps> = ({
  activeTab,
  onNavigate,
  onOpenSettings,
  onOpenExtensions,
  onOpenTechDocs,
  onOpenIDMSniffer,
  onOpenPlaylistDownloader,
  onOpenPageDownloader,
  engineConfig,
  onToggleEngine,
  isPlayingAudio,
  onToggleBookmarksBar,
  showBookmarksBar,
  onToggleBookmarkCurrent,
  detectedMediaCount,
}) => {
  const [urlInput, setUrlInput] = useState(activeTab?.url || 'chrome://newtab');
  const [isCopied, setIsCopied] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    if (activeTab) {
      setUrlInput(activeTab.url);
    }
  }, [activeTab]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (urlInput.trim()) {
      onNavigate(urlInput);
    }
  };

  return (
    <div className="bg-[#2B2D30] border-b border-gray-800 px-3 py-2 flex items-center gap-2 relative">
      {/* Navigation History Buttons */}
      <div className="flex items-center gap-1 text-gray-400">
        <button
          className="p-1.5 hover:bg-gray-700/60 rounded-full transition-colors disabled:opacity-40"
          title="Back"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button
          className="p-1.5 hover:bg-gray-700/60 rounded-full transition-colors disabled:opacity-40"
          title="Forward"
        >
          <ArrowRight className="w-4 h-4" />
        </button>
        <button
          onClick={() => activeTab && onNavigate(activeTab.url)}
          className="p-1.5 hover:bg-gray-700/60 rounded-full transition-colors"
          title="Reload"
        >
          <RotateCw className="w-4 h-4" />
        </button>
        <button
          onClick={() => onNavigate('chrome://newtab')}
          className="p-1.5 hover:bg-gray-700/60 rounded-full transition-colors"
          title="Home"
        >
          <Home className="w-4 h-4" />
        </button>
      </div>

      {/* URL Address Bar */}
      <form onSubmit={handleSubmit} className="flex-1 flex items-center">
        <div className="w-full bg-[#1E2022] hover:bg-[#1A1C1E] focus-within:bg-[#1A1C1E] border border-gray-700 focus-within:border-blue-500 rounded-full px-3.5 py-1.5 flex items-center gap-2 transition-all shadow-inner">
          <span title="Kết Nối An Toàn SSL (HTTPS)"><Shield className="w-4 h-4 text-emerald-400 flex-shrink-0" /></span>

          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="Search Google or type a URL"
            className="w-full bg-transparent text-xs text-gray-100 placeholder-gray-500 focus:outline-none"
          />

          <button
            type="button"
            onClick={onToggleBookmarkCurrent}
            className="text-gray-400 hover:text-yellow-400 transition-colors p-0.5"
            title="Bookmark tab này"
          >
            <Star className="w-4 h-4" />
          </button>
        </div>
      </form>

      {/* Extensions & Tools Bar */}
      <div className="flex items-center gap-1.5 text-gray-300">
        {/* Engine Config Badge / Toggle */}
        <button
          onClick={onToggleEngine}
          className="p-1.5 bg-gray-800 hover:bg-gray-700 rounded-lg text-[10px] font-bold text-blue-400 border border-gray-700 flex items-center gap-1 transition-all"
          title={`Engine: ${engineConfig.type === 'chromium' ? 'Chromium V128 Engine' : 'Firefox GeckoView Engine'}. Bấm để chuyển đổi.`}
        >
          <Cpu className="w-3.5 h-3.5 text-purple-400" />
          <span className="uppercase">{engineConfig.type}</span>
        </button>

        {/* IDM Sniffer Launcher Button */}
        <button
          onClick={onOpenIDMSniffer}
          className="relative p-1.5 bg-blue-900/30 hover:bg-blue-900/50 text-blue-400 rounded-lg transition-all border border-blue-500/30 flex items-center gap-1 text-xs font-semibold"
          title="IDM Multimedia Sniffer - Bắt link video/audio trên trang"
        >
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline">IDM</span>
          {detectedMediaCount > 0 && (
            <span className="bg-blue-600 text-white text-[9px] font-extrabold px-1.5 py-0.2 rounded-full animate-pulse">
              {detectedMediaCount}
            </span>
          )}
        </button>

        {/* YouTube & Playlist Downloader */}
        <button
          onClick={onOpenPlaylistDownloader}
          className="p-1.5 bg-red-900/30 hover:bg-red-900/50 text-red-400 rounded-lg transition-all border border-red-500/30 flex items-center gap-1 text-xs font-semibold"
          title="Tải Video & Playlist YouTube"
        >
          <Youtube className="w-4 h-4" />
          <span className="hidden md:inline">Tải Playlist</span>
        </button>

        {/* Save Page Button */}
        <button
          onClick={onOpenPageDownloader}
          className="p-1.5 bg-emerald-900/30 hover:bg-emerald-900/50 text-emerald-400 rounded-lg transition-all border border-emerald-500/30 flex items-center gap-1 text-xs font-semibold"
          title="Lưu trang web (HTML, MHTML, PDF, TXT)"
        >
          <Globe className="w-4 h-4" />
          <span className="hidden lg:inline">Lưu Trang</span>
        </button>

        {/* Background Audio Extension Indicator */}
        <button
          onClick={onOpenExtensions}
          className={`p-1.5 rounded-lg transition-all border flex items-center gap-1 ${
            isPlayingAudio
              ? 'bg-blue-500/20 text-blue-400 border-blue-500/40 shadow-sm'
              : 'bg-gray-800 text-gray-400 border-gray-700 hover:text-gray-200'
          }`}
          title="Chrome Audio Background Keep-Alive Extension"
        >
          {isPlayingAudio ? <Volume2 className="w-4 h-4 animate-bounce" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Chrome Menu Drawer */}
        <div className="relative">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-1.5 hover:bg-gray-700/60 rounded-full transition-colors text-gray-300"
            title="Chrome Menu"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-64 bg-[#242629] border border-gray-700 rounded-xl shadow-2xl py-2 z-50 text-xs">
              <button
                onClick={() => {
                  onOpenExtensions();
                  setIsMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-700 text-gray-200 font-medium"
              >
                <Volume2 className="w-4 h-4 text-blue-400" />
                <span>🔊 Tiện ích Phát Âm Thanh Nền</span>
              </button>

              <button
                onClick={() => {
                  onOpenIDMSniffer();
                  setIsMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-700 text-blue-400 font-medium"
              >
                <Download className="w-4 h-4" />
                <span>⚡ IDM Multimedia Sniffer ({detectedMediaCount} link)</span>
              </button>

              <button
                onClick={() => {
                  onOpenPlaylistDownloader();
                  setIsMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-700 text-red-400 font-medium"
              >
                <Youtube className="w-4 h-4" />
                <span>🎬 Tải Video & Playlist YouTube</span>
              </button>

              <button
                onClick={() => {
                  onOpenPageDownloader();
                  setIsMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-700 text-emerald-400 font-medium"
              >
                <Globe className="w-4 h-4" />
                <span>🌐 Lưu trang web (HTML/MHTML/PDF)</span>
              </button>

              <div className="my-1 border-t border-gray-700" />

              <button
                onClick={() => {
                  onOpenTechDocs();
                  setIsMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-700 text-blue-400 font-medium"
              >
                <FileText className="w-4 h-4" />
                <span>📄 Tài Liệu Kỹ Thuật System</span>
              </button>

              <button
                onClick={() => {
                  onOpenSettings();
                  setIsMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-700 text-gray-200 font-medium"
              >
                <SettingsIcon className="w-4 h-4 text-gray-400" />
                <span>Cài Đặt Trình Duyệt</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
