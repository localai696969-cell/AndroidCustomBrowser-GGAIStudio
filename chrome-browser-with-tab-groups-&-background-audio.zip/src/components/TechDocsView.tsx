import React from 'react';
import { FileText, Cpu, CheckCircle2, ShieldCheck, Zap, Layers, Sparkles } from 'lucide-react';

export function TechDocsView() {
  return (
    <div className="h-full overflow-y-auto p-6 md:p-10 max-w-4xl mx-auto space-y-8 bg-[#1A1C1E] text-gray-200">
      <div className="border-b border-gray-800 pb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          Technical Documentation & Architecture Specification
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-white">
          Kiến Trúc Multi-Engine Keep-Alive Browser & IDM Sniffer
        </h1>
        <p className="text-sm text-gray-400 mt-2">
          Chi tiết kỹ thuật về GeckoView Firefox vs Chromium Core, cơ chế chạy nhạc nền không tắt màn hình và module tải file đa luồng tốc độ cao.
        </p>
      </div>

      {/* 1. Comparison section */}
      <section className="space-y-4">
        <h2 className="text-lg font-bold text-gray-100 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-purple-400" />
          1. Tại Sao Chọn GeckoView Cho Mobile Chạy Nền vs Chromium?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-[#242629] border border-purple-500/30 space-y-2">
            <h3 className="font-bold text-purple-400 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" /> Mozilla GeckoView Engine
            </h3>
            <p className="text-gray-300 leading-relaxed">
              GeckoView là engine render độc lập từ Mozilla dành cho Android. Cho phép kiểm soát sâu luồng WebAudio, duy trì WebSocket/HLS Stream liên tục khi ẩn ứng dụng hoặc khóa màn hình mà không bị Android OS ngắt kết nối.
            </p>
            <ul className="list-disc pl-4 text-gray-400 space-y-1">
              <li>Hỗ trợ đầy đủ WebExtension API (uBlock, IDM Sniffer)</li>
              <li>Tự do tùy biến AudioContext Keep-Alive pipeline</li>
              <li>Chạy nhẹ nhàng trên GitHub Actions build APK (~50MB AAR)</li>
            </ul>
          </div>

          <div className="p-4 rounded-xl bg-[#242629] border border-gray-800 space-y-2 opacity-80">
            <h3 className="font-bold text-gray-300 text-sm">Standard Chromium WebView</h3>
            <p className="text-gray-400 leading-relaxed">
              Chromium WebView bị Google thắt chặt chính sách background playback. Tự động tạm dừng JavaScript timer và ngắt AudioContext sau 30 giây khi tab chìm hoặc khóa màn hình để tiết kiệm pin.
            </p>
            <ul className="list-disc pl-4 text-gray-500 space-y-1">
              <li>Không hỗ trợ cài đặt Extension trên mobile</li>
              <li>Bị giới hạn bởi Android Battery Optimization</li>
            </ul>
          </div>
        </div>
      </section>

      {/* 2. Audio Background */}
      <section className="space-y-4">
        <h2 className="text-lg font-bold text-gray-100 flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-400" />
          2. Cơ Chế Keep-Alive Audio & MediaSession API
        </h2>
        <div className="p-4 rounded-xl bg-[#242629] border border-gray-800 text-xs space-y-3">
          <p className="text-gray-300 leading-relaxed">
            Ứng dụng sử dụng MediaSession API kết hợp HTML5 AudioElement Synth Loop. Khi chuyển tab hoặc khóa màn hình, hệ thống phát luồng âm thanh nền giữ mức ưu tiên cao (Foreground Service Priority).
          </p>
          <div className="p-3 rounded bg-[#1A1C1E] border border-gray-800 font-mono text-[11px] text-emerald-400">
            navigator.mediaSession.setActionHandler('play', () =&gt; service.play());<br />
            navigator.mediaSession.setActionHandler('pause', () =&gt; service.pause());
          </div>
        </div>
      </section>

      {/* 3. GitHub Build */}
      <section className="space-y-4">
        <h2 className="text-lg font-bold text-gray-100 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          3. Đóng Gói Tự Động Trên GitHub Actions (.github/workflows/android.yml)
        </h2>
        <div className="p-4 rounded-xl bg-[#242629] border border-gray-800 text-xs space-y-2">
          <p className="text-gray-300">
            Mã nguồn dự án tích hợp sẵn file cấu hình GitHub Actions CI/CD. Khi đẩy mã nguồn lên GitHub, hệ thống sẽ tự động đóng gói ứng dụng React thành bundle Web và liên kết AAR GeckoView để tạo file Android APK sẵn sàng cài đặt.
          </p>
        </div>
      </section>
    </div>
  );
}
