import React, { useState, useEffect } from 'react';
import { TECHNICAL_DOCS } from '../data/initialData';
import { backgroundAudioService } from '../services/backgroundAudio';
import {
  FileText,
  CheckCircle,
  Copy,
  Check,
  Terminal,
  Activity,
  Layers,
  Cpu,
  Volume2,
  Lock,
  EyeOff,
  Radio,
  Play,
  Pause,
} from 'lucide-react';

interface TechDocsViewProps {
  onTestAudioToggle: () => void;
  isPlayingAudio: boolean;
}

export const TechDocsView: React.FC<TechDocsViewProps> = ({ onTestAudioToggle, isPlayingAudio }) => {
  const [activeSectionId, setActiveSectionId] = useState(TECHNICAL_DOCS[0].id);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [status, setStatus] = useState(backgroundAudioService.getStatus());

  useEffect(() => {
    backgroundAudioService.setLogCallback((updatedLogs) => {
      setLogs(updatedLogs);
      setStatus(backgroundAudioService.getStatus());
    });
    setLogs(backgroundAudioService.getLogs());
  }, []);

  const activeDoc = TECHNICAL_DOCS.find((d) => d.id === activeSectionId) || TECHNICAL_DOCS[0];

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div className="h-full w-full bg-gray-50 dark:bg-[#181A1B] text-gray-900 dark:text-gray-100 overflow-y-auto p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Banner Header */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur rounded-full text-xs font-semibold uppercase tracking-wider mb-2">
              <FileText className="w-3.5 h-3.5" />
              Tài Liệu Kỹ Thuật Chính Thức
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              Cơ Chế Phát Nhạc Nền YouTube & Quản Lý Tab Group
            </h1>
            <p className="text-xs md:text-sm text-blue-100 mt-1 max-w-2xl">
              Phân tích chi tiết nguyên nhân phát nhạc nền thành công khi chuyển tab/tắt màn hình, cùng kiến trúc giao diện Chrome Tab Group.
            </p>
          </div>

          <button
            onClick={onTestAudioToggle}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shadow-lg transition-all ${
              isPlayingAudio
                ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
                : 'bg-white text-blue-900 hover:bg-blue-50'
            }`}
          >
            {isPlayingAudio ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{isPlayingAudio ? 'Dừng Nhạc Thử Nghiệm' : 'Bật Nhạc Nền Thử Nghiệm'}</span>
          </button>
        </div>

        {/* Technical Sections Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-gray-200 dark:border-gray-800 pb-2 overflow-x-auto no-scrollbar">
          {TECHNICAL_DOCS.map((doc) => {
            const isActive = doc.id === activeSectionId;
            return (
              <button
                key={doc.id}
                onClick={() => setActiveSectionId(doc.id)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap flex items-center gap-2 ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700'
                }`}
              >
                <span>{doc.titleVi}</span>
              </button>
            );
          })}
        </div>

        {/* Active Section Content & Code */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Column */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 shadow-xs space-y-4">
              <h2 className="text-xl font-bold text-blue-600 dark:text-blue-400">{activeDoc.titleVi}</h2>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-300 bg-blue-50 dark:bg-blue-950/40 p-3 rounded-xl border border-blue-100 dark:border-blue-900">
                {activeDoc.summary}
              </p>

              {/* Key Takeaways Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {activeDoc.keyTakeaways.map((point, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-gray-50 dark:bg-gray-900/60 rounded-xl border border-gray-200 dark:border-gray-700 flex items-start gap-2 text-xs"
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">{point}</span>
                  </div>
                ))}
              </div>

              {/* Markdown Content Output */}
              <div className="prose dark:prose-invert max-w-none text-xs leading-relaxed space-y-3 whitespace-pre-wrap pt-2">
                {activeDoc.contentMarkdown}
              </div>

              {/* Code Snippet Box */}
              {activeDoc.codeSnippet && (
                <div className="mt-4 rounded-xl overflow-hidden border border-gray-800 bg-[#1E1E1E] text-gray-200 text-xs">
                  <div className="bg-[#2D2D2D] px-4 py-2 flex items-center justify-between text-gray-400 font-mono text-[11px]">
                    <span className="flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-blue-400" />
                      background_audio_engine.ts
                    </span>
                    <button
                      onClick={() => handleCopyCode(activeDoc.codeSnippet!)}
                      className="flex items-center gap-1 px-2 py-1 bg-white/10 hover:bg-white/20 rounded text-gray-200 transition-colors"
                    >
                      {copiedSnippet ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>Đã chép</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Sao chép</span>
                        </>
                      )}
                    </button>
                  </div>
                  <pre className="p-4 overflow-x-auto font-mono text-[11px] leading-relaxed text-emerald-400">
                    {activeDoc.codeSnippet}
                  </pre>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Live Diagnostic Status & Console Log */}
          <div className="space-y-6">
            {/* Realtime Engine Status */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-gray-800 dark:text-gray-200 uppercase tracking-wider flex items-center gap-2">
                <Activity className="w-4 h-4 text-red-500 animate-pulse" />
                Trạng Thái Trình Điều Khiển Nền
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                  <span className="flex items-center gap-2">
                    <EyeOff className="w-4 h-4 text-blue-500" />
                    <span>Visibility Override</span>
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      status.visibilityOverride ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {status.visibilityOverride ? 'BẬT' : 'TẮT'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                  <span className="flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-purple-500" />
                    <span>WebAudio AudioContext</span>
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      status.audioContextActive ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {status.audioContextActive ? 'HOẠT ĐỘNG' : 'TẮT'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                  <span className="flex items-center gap-2">
                    <Radio className="w-4 h-4 text-amber-500" />
                    <span>MediaSession API</span>
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      status.mediaSessionActive ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {status.mediaSessionActive ? 'ĐÃ ĐĂNG KÝ' : 'CHỜ'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                  <span className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-emerald-500" />
                    <span>Screen WakeLock</span>
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      status.wakeLockActive ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {status.wakeLockActive ? 'BẬT' : 'TẮT'}
                  </span>
                </div>
              </div>
            </div>

            {/* Diagnostic Logs Stream */}
            <div className="bg-[#121314] rounded-2xl p-4 border border-gray-800 shadow-xl space-y-2 font-mono text-[11px]">
              <div className="flex items-center justify-between text-gray-400 pb-2 border-b border-gray-800">
                <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                  <Terminal className="w-3.5 h-3.5" />
                  Real-time Diagnostic Logs
                </span>
                <span className="text-[10px] text-gray-500">{logs.length} sự kiện</span>
              </div>

              <div className="max-h-64 overflow-y-auto space-y-1.5 text-gray-300 pr-1">
                {logs.length === 0 ? (
                  <div className="text-gray-600 italic">Đang chờ sự kiện hệ thống...</div>
                ) : (
                  logs.map((log, i) => (
                    <div key={i} className="leading-tight break-all border-l-2 border-blue-500 pl-2 py-0.5">
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
