import React, { useState } from 'react';
import { HistoryItem, Bookmark } from '../types';
import { X, History, Bookmark as BookmarkIcon, Trash2, ExternalLink, Search } from 'lucide-react';

interface HistoryBookmarksModalProps {
  initialMode: 'history' | 'bookmarks';
  historyList: HistoryItem[];
  bookmarksList: Bookmark[];
  onClose: () => void;
  onOpenUrl: (url: string, title: string) => void;
  onClearHistory: () => void;
  onDeleteBookmark: (id: string) => void;
}

export const HistoryBookmarksModal: React.FC<HistoryBookmarksModalProps> = ({
  initialMode,
  historyList,
  bookmarksList,
  onClose,
  onOpenUrl,
  onClearHistory,
  onDeleteBookmark,
}) => {
  const [mode, setMode] = useState<'history' | 'bookmarks'>(initialMode);
  const [filterQuery, setFilterQuery] = useState('');

  const filteredHistory = historyList.filter((h) =>
    h.title.toLowerCase().includes(filterQuery.toLowerCase()) || h.url.toLowerCase().includes(filterQuery.toLowerCase())
  );

  const filteredBookmarks = bookmarksList.filter((b) =>
    b.title.toLowerCase().includes(filterQuery.toLowerCase()) || b.url.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#2B2D30] rounded-2xl max-w-xl w-full border border-gray-200 dark:border-gray-700 shadow-2xl p-6 text-gray-900 dark:text-gray-100 space-y-4">
        {/* Modal Header & Tabs */}
        <div className="flex items-center justify-between border-b border-gray-200 dark:border-gray-700 pb-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMode('history')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                mode === 'history'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Lịch Sử (History)</span>
            </button>

            <button
              onClick={() => setMode('bookmarks')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                mode === 'bookmarks'
                  ? 'bg-amber-500 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
              }`}
            >
              <BookmarkIcon className="w-4 h-4" />
              <span>Dấu Trang (Bookmarks)</span>
            </button>
          </div>

          <button onClick={onClose} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Actions */}
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 py-1.5 bg-gray-100 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 text-xs">
            <Search className="w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="Tìm kiếm..."
              className="w-full bg-transparent outline-none"
            />
          </div>

          {mode === 'history' && historyList.length > 0 && (
            <button
              onClick={onClearHistory}
              className="px-3 py-1.5 bg-red-100 dark:bg-red-900/40 text-red-600 text-xs font-semibold rounded-lg hover:bg-red-200 transition-colors"
            >
              Xóa Lịch Sử
            </button>
          )}
        </div>

        {/* Content List */}
        <div className="max-h-80 overflow-y-auto space-y-2 pr-1">
          {mode === 'history' ? (
            filteredHistory.length === 0 ? (
              <div className="text-center py-8 text-xs text-gray-400">Không có lịch sử truy cập nào.</div>
            ) : (
              filteredHistory.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    onOpenUrl(item.url, item.title);
                    onClose();
                  }}
                  className="p-3 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl border border-gray-200 dark:border-gray-700 cursor-pointer flex items-center justify-between text-xs transition-colors"
                >
                  <div className="min-w-0 flex-1 pr-2">
                    <div className="font-semibold text-gray-800 dark:text-gray-200 truncate">{item.title}</div>
                    <div className="text-[10px] text-gray-400 truncate">{item.url}</div>
                  </div>
                  <span className="text-[10px] text-gray-400 flex-shrink-0 font-mono">
                    {new Date(item.visitedAt).toLocaleTimeString('vi-VN')}
                  </span>
                </div>
              ))
            )
          ) : filteredBookmarks.length === 0 ? (
            <div className="text-center py-8 text-xs text-gray-400">Chưa có dấu trang nào được thêm.</div>
          ) : (
            filteredBookmarks.map((bm) => (
              <div
                key={bm.id}
                className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between text-xs"
              >
                <div
                  onClick={() => {
                    onOpenUrl(bm.url, bm.title);
                    onClose();
                  }}
                  className="min-w-0 flex-1 cursor-pointer pr-2"
                >
                  <div className="font-semibold text-gray-800 dark:text-gray-200 truncate flex items-center gap-1.5">
                    <BookmarkIcon className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                    <span>{bm.title}</span>
                  </div>
                  <div className="text-[10px] text-gray-400 truncate">{bm.url}</div>
                </div>

                <button
                  onClick={() => onDeleteBookmark(bm.id)}
                  className="p-1 hover:bg-red-100 dark:hover:bg-red-900/50 text-red-600 rounded transition-colors"
                  title="Xóa dấu trang"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
