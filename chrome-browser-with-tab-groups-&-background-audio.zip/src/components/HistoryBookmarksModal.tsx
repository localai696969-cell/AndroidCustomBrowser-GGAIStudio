import React, { useState } from 'react';
import { HistoryItem, Bookmark } from '../types';
import { X, History, Star, ExternalLink, Globe } from 'lucide-react';

interface HistoryBookmarksModalProps {
  history: HistoryItem[];
  bookmarks: Bookmark[];
  onClose: () => void;
  onNavigate: (url: string) => void;
}

export function HistoryBookmarksModal({
  history,
  bookmarks,
  onClose,
  onNavigate,
}: HistoryBookmarksModalProps) {
  const [activeTab, setActiveTab] = useState<'history' | 'bookmarks'>('history');

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242629] border border-gray-700 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl text-gray-100 flex flex-col max-h-[80vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'history' ? 'bg-purple-600/30 text-purple-400 border border-purple-500/30' : 'text-gray-400 hover:text-white'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Lịch Sử Duyệt Web ({history.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('bookmarks')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'bookmarks' ? 'bg-yellow-600/30 text-yellow-400 border border-yellow-500/30' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Star className="w-4 h-4" />
              <span>Dấu Trang Bookmarks ({bookmarks.length})</span>
            </button>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto flex-1 space-y-2 text-xs">
          {activeTab === 'history' ? (
            history.length === 0 ? (
              <p className="text-center text-gray-500 py-8">Chưa có lịch sử duyệt web trong phiên làm việc này.</p>
            ) : (
              history.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onNavigate(item.url)}
                  className="p-3 rounded-xl bg-[#1A1C1E] hover:bg-gray-800 border border-gray-800 cursor-pointer flex items-center justify-between gap-3 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-white truncate">{item.title}</p>
                    <p className="text-[11px] text-gray-400 truncate">{item.url}</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-gray-500 flex-shrink-0" />
                </div>
              ))
            )
          ) : bookmarks.length === 0 ? (
            <p className="text-center text-gray-500 py-8">Chưa lưu dấu trang nào.</p>
          ) : (
            bookmarks.map((bm) => (
              <div
                key={bm.id}
                onClick={() => onNavigate(bm.url)}
                className="p-3 rounded-xl bg-[#1A1C1E] hover:bg-gray-800 border border-gray-800 cursor-pointer flex items-center justify-between gap-3 transition-colors"
              >
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  <Globe className="w-4 h-4 text-blue-400 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-white truncate">{bm.title}</p>
                    <p className="text-[11px] text-gray-400 truncate">{bm.url}</p>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-500 flex-shrink-0" />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
