import React, { useState } from 'react';
import { Search, Youtube, FileText, Layers, Volume2, Sparkles, Shield, ArrowUpRight, CloudSun } from 'lucide-react';
import { TabGroup } from '../types';

interface NewTabPageProps {
  onSearch: (query: string) => void;
  onOpenTechDocs: () => void;
  onOpenYouTube: () => void;
  tabGroups: TabGroup[];
  isPlayingAudio: boolean;
}

export const NewTabPage: React.FC<NewTabPageProps> = ({
  onSearch,
  onOpenTechDocs,
  onOpenYouTube,
  tabGroups,
  isPlayingAudio,
}) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim());
    }
  };

  return (
    <div className="h-full w-full overflow-y-auto bg-gradient-to-b from-gray-50 to-gray-100 dark:from-[#1E2022] dark:to-[#121314] text-gray-900 dark:text-gray-100 p-6 flex flex-col items-center justify-between">
      {/* Top Bar: Weather & Chrome Badge */}
      <div className="w-full max-w-4xl flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
        <div className="flex items-center gap-2 bg-white/80 dark:bg-gray-800/80 backdrop-blur px-3 py-1.5 rounded-full border border-gray-200 dark:border-gray-700 shadow-xs">
          <CloudSun className="w-4 h-4 text-amber-500" />
          <span>Hà Nội: 28°C Nắng Nhẹ</span>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 px-2.5 py-1 rounded-full font-medium">
            <Shield className="w-3.5 h-3.5" />
            Background Audio Engine: ACTIVE
          </span>
        </div>
      </div>

      {/* Main Center Content: Google Brand & Search Bar */}
      <div className="w-full max-w-2xl my-auto flex flex-col items-center text-center">
        {/* Google / Chrome Logo */}
        <div className="mb-8 flex items-center gap-3">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-blue-500 flex items-center justify-center text-white shadow-xl ring-4 ring-white dark:ring-gray-800">
              <span className="text-3xl font-bold tracking-wider">G</span>
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-bold border-2 border-white dark:border-gray-800">
              ▶
            </div>
          </div>
          <div className="text-left">
            <h1 className="text-3xl font-extrabold tracking-tight bg-gradient-to-r from-blue-600 via-red-500 to-amber-500 bg-clip-text text-transparent">
              Google Chrome
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              With Tab Groups & YouTube Background Playback Engine
            </p>
          </div>
        </div>

        {/* Big Search Bar */}
        <form onSubmit={handleSearchSubmit} className="w-full mb-8">
          <div className="flex items-center gap-3 px-5 py-3.5 bg-white dark:bg-[#2B2D30] rounded-full border border-gray-200 dark:border-gray-700 shadow-lg hover:shadow-xl focus-within:shadow-xl focus-within:border-blue-500 transition-all">
            <Search className="w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Tìm kiếm bằng Google hoặc nhập địa chỉ trang web"
              className="w-full bg-transparent border-none outline-none text-sm text-gray-900 dark:text-white"
            />
            <button
              type="submit"
              className="p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full transition-colors"
            >
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        {/* Shortcut Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full">
          <button
            onClick={onOpenYouTube}
            className="group flex flex-col items-center gap-2 p-4 bg-white dark:bg-[#2B2D30] hover:bg-red-50 dark:hover:bg-red-950/30 rounded-2xl border border-gray-200/80 dark:border-gray-700/80 shadow-xs hover:shadow-md transition-all text-center"
          >
            <div className="w-12 h-12 rounded-xl bg-red-100 dark:bg-red-900/50 flex items-center justify-center text-red-600 dark:text-red-400 group-hover:scale-110 transition-transform">
              <Youtube className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-gray-800 dark:text-gray-200">YouTube Lofi</span>
            <span className="text-[10px] text-gray-400">Phát nhạc nền 24/7</span>
          </button>

          <button
            onClick={onOpenTechDocs}
            className="group flex flex-col items-center gap-2 p-4 bg-white dark:bg-[#2B2D30] hover:bg-blue-50 dark:hover:bg-blue-950/30 rounded-2xl border border-gray-200/80 dark:border-gray-700/80 shadow-xs hover:shadow-md transition-all text-center"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-gray-800 dark:text-gray-200">Tài Liệu Kỹ Thuật</span>
            <span className="text-[10px] text-gray-400">Cơ chế phát nhạc ngầm</span>
          </button>

          <button
            onClick={() => onSearch('Lofi hip hop beats study')}
            className="group flex flex-col items-center gap-2 p-4 bg-white dark:bg-[#2B2D30] hover:bg-purple-50 dark:hover:bg-purple-950/30 rounded-2xl border border-gray-200/80 dark:border-gray-700/80 shadow-xs hover:shadow-md transition-all text-center"
          >
            <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center text-purple-600 dark:text-purple-400 group-hover:scale-110 transition-transform">
              <Sparkles className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-gray-800 dark:text-gray-200">Chill Beats</span>
            <span className="text-[10px] text-gray-400">Google Search</span>
          </button>

          <button
            onClick={() => onSearch('Google Chrome Tab Grouping Docs')}
            className="group flex flex-col items-center gap-2 p-4 bg-white dark:bg-[#2B2D30] hover:bg-emerald-50 dark:hover:bg-emerald-950/30 rounded-2xl border border-gray-200/80 dark:border-gray-700/80 shadow-xs hover:shadow-md transition-all text-center"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform">
              <Layers className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-gray-800 dark:text-gray-200">Group Tabs</span>
            <span className="text-[10px] text-gray-400">{tabGroups.length} Nhóm đang mở</span>
          </button>
        </div>
      </div>

      {/* Bottom Status Banner: Background Audio Active Status */}
      <div className="w-full max-w-4xl bg-white dark:bg-[#2B2D30] rounded-xl p-4 border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 rounded-lg">
            <Volume2 className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              Trạng Thái Phát Âm Thanh Nền: {isPlayingAudio ? 'ĐANG PHÁT' : 'SẴN SÀNG'}
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-[11px]">
              Trình duyệt đang bảo vệ luồng audio. Bạn có thể chuyển tab hoặc làm việc khác mà nhạc không bị dừng.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenTechDocs}
          className="px-3 py-1.5 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg font-medium text-blue-600 dark:text-blue-400 transition-colors whitespace-nowrap"
        >
          Xem Đồ Thị Kỹ Thuật →
        </button>
      </div>
    </div>
  );
};
