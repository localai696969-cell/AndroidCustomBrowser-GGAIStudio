import React from 'react';
import { Search, Globe, Youtube, Github, FileText, Layers, Download, Sparkles } from 'lucide-react';

interface NewTabPageProps {
  onNavigate: (url: string) => void;
  onOpenTechDocs: () => void;
}

export function NewTabPage({ onNavigate, onOpenTechDocs }: NewTabPageProps) {
  const [searchInput, setSearchInput] = React.useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onNavigate(searchInput);
    }
  };

  const shortcuts = [
    { title: 'YouTube Lofi', url: 'https://youtube.com/watch?v=jfKfPfyJRdk', icon: <Youtube className="w-6 h-6 text-red-500" /> },
    { title: 'Tài Liệu Kỹ Thuật System', url: 'chrome://tech-docs', icon: <FileText className="w-6 h-6 text-blue-400" /> },
    { title: 'Google Search', url: 'https://google.com', icon: <Globe className="w-6 h-6 text-emerald-400" /> },
    { title: 'GitHub GeckoView', url: 'https://github.com/mozilla/geckoview', icon: <Github className="w-6 h-6 text-purple-400" /> },
  ];

  return (
    <div className="h-full overflow-y-auto bg-[#1A1C1E] text-gray-100 flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-2xl text-center space-y-8">
        {/* Chrome Logo Heading */}
        <div className="space-y-2">
          <div className="inline-flex p-4 rounded-full bg-blue-600/10 border border-blue-500/20 mb-2">
            <Globe className="w-12 h-12 text-blue-400 animate-spin-slow" />
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Chrome Multi-Engine Browser</h1>
          <p className="text-xs text-gray-400">
            Hỗ trợ Tab Groups, Phát Ngầm YouTube Lofi, IDM Multimedia Sniffer &amp; GeckoView Firefox Core
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="relative max-w-xl mx-auto">
          <div className="relative flex items-center">
            <Search className="w-5 h-5 text-gray-400 absolute left-4" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Tìm kiếm trên Google hoặc nhập địa chỉ URL..."
              className="w-full bg-[#242629] border border-gray-700 hover:border-gray-600 focus:border-blue-500 rounded-full py-3.5 pl-12 pr-4 text-sm text-gray-100 placeholder-gray-500 focus:outline-none shadow-xl transition-all"
            />
          </div>
        </form>

        {/* Quick Speed Dial Shortcuts */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-lg mx-auto pt-2">
          {shortcuts.map((sc, i) => (
            <button
              key={i}
              onClick={() => onNavigate(sc.url)}
              className="p-4 rounded-2xl bg-[#242629] hover:bg-[#2B2D30] border border-gray-800 hover:border-gray-700 flex flex-col items-center gap-2 transition-all group"
            >
              <div className="p-3 rounded-xl bg-[#1A1C1E] group-hover:scale-110 transition-transform">
                {sc.icon}
              </div>
              <span className="text-xs font-medium text-gray-300 group-hover:text-white line-clamp-1">{sc.title}</span>
            </button>
          ))}
        </div>

        {/* Technical Callout */}
        <div className="pt-6">
          <button
            onClick={onOpenTechDocs}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            Xem Chi Tiết Kỹ Thuật Khác Biệt GeckoView vs Chromium
          </button>
        </div>
      </div>
    </div>
  );
}
