import React from 'react';
import { Tab, AudioTrack } from '../types';
import { YouTubePlayerView } from './YouTubePlayerView';
import { TechDocsView } from './TechDocsView';
import { NewTabPage } from './NewTabPage';
import { BackgroundAudioMiniPlayer } from './BackgroundAudioMiniPlayer';
import { Globe, AlertCircle } from 'lucide-react';

interface WebPageContainerProps {
  activeTab: Tab | undefined;
  isPlayingAudio: boolean;
  onToggleAudio: () => void;
  currentTrack: AudioTrack;
  onSelectTrack: (track: AudioTrack) => void;
  onOpenTechDocs: () => void;
}

export function WebPageContainer({
  activeTab,
  isPlayingAudio,
  onToggleAudio,
  currentTrack,
  onSelectTrack,
  onOpenTechDocs,
}: WebPageContainerProps) {
  if (!activeTab || activeTab.type === 'newtab' || activeTab.url === 'chrome://newtab') {
    return <NewTabPage onNavigate={() => {}} onOpenTechDocs={onOpenTechDocs} />;
  }

  if (activeTab.type === 'techdocs' || activeTab.url === 'chrome://tech-docs') {
    return <TechDocsView />;
  }

  if (activeTab.type === 'youtube' || activeTab.url.includes('youtube.com')) {
    return (
      <div className="h-full w-full relative">
        <YouTubePlayerView
          isPlayingAudio={isPlayingAudio}
          onToggleAudio={onToggleAudio}
          currentTrack={currentTrack}
          onSelectTrack={onSelectTrack}
          onOpenTechDocs={onOpenTechDocs}
        />
        <BackgroundAudioMiniPlayer
          isPlayingAudio={isPlayingAudio}
          onToggleAudio={onToggleAudio}
          currentTrack={currentTrack}
        />
      </div>
    );
  }

  // Generic External Web Viewer
  return (
    <div className="h-full w-full relative bg-white dark:bg-[#1A1C1E] flex flex-col items-center justify-center p-6">
      <div className="max-w-md text-center space-y-4 p-6 rounded-2xl bg-[#242629] border border-gray-800 text-gray-200">
        <div className="inline-flex p-3 rounded-full bg-blue-500/10 text-blue-400">
          <Globe className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-white line-clamp-1">{activeTab.title}</h2>
        <p className="text-xs text-gray-400 break-all">{activeTab.url}</p>

        <div className="p-3 rounded-lg bg-[#1A1C1E] border border-gray-800 text-xs text-left text-gray-300 space-y-1">
          <p className="font-semibold text-blue-400 flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5" /> Mô Phỏng Frame Website External
          </p>
          <p className="text-gray-400">
            Trang web đang được tải thông qua bộ giả lập trình duyệt Chrome/GeckoView Sandbox.
          </p>
        </div>
      </div>

      <BackgroundAudioMiniPlayer
        isPlayingAudio={isPlayingAudio}
        onToggleAudio={onToggleAudio}
        currentTrack={currentTrack}
      />
    </div>
  );
}
