import React from 'react';
import { Tab, AudioTrack } from '../types';
import { NewTabPage } from './NewTabPage';
import { YouTubePlayerView } from './YouTubePlayerView';
import { TechDocsView } from './TechDocsView';
import { Search, Globe, ExternalLink, ShieldCheck, ArrowRight } from 'lucide-react';
import { TabGroup } from '../types';

interface WebPageContainerProps {
  activeTab: Tab | undefined;
  currentTrack: AudioTrack;
  isPlayingAudio: boolean;
  onPlayPauseAudio: () => void;
  onSelectTrack: (track: AudioTrack) => void;
  onNextTrack: () => void;
  onPrevTrack: () => void;
  onOpenTechDocs: () => void;
  onOpenYouTube: () => void;
  onNavigateSearch: (query: string) => void;
  tabGroups: TabGroup[];
}

export const WebPageContainer: React.FC<WebPageContainerProps> = ({
  activeTab,
  currentTrack,
  isPlayingAudio,
  onPlayPauseAudio,
  onSelectTrack,
  onNextTrack,
  onPrevTrack,
  onOpenTechDocs,
  onOpenYouTube,
  onNavigateSearch,
  tabGroups,
}) => {
  if (!activeTab) {
    return (
      <div className="h-full w-full flex items-center justify-center bg-gray-100 dark:bg-gray-900 text-gray-500 text-sm">
        Không có tab nào đang mở. Nhấn (+) để mở tab mới.
      </div>
    );
  }

  switch (activeTab.type) {
    case 'newtab':
      return (
        <NewTabPage
          onSearch={onNavigateSearch}
          onOpenTechDocs={onOpenTechDocs}
          onOpenYouTube={onOpenYouTube}
          tabGroups={tabGroups}
          isPlayingAudio={isPlayingAudio}
        />
      );

    case 'youtube':
      return (
        <YouTubePlayerView
          currentTrack={currentTrack}
          isPlaying={isPlayingAudio}
          onPlayPause={onPlayPauseAudio}
          onSelectTrack={onSelectTrack}
          onNextTrack={onNextTrack}
          onPrevTrack={onPrevTrack}
          onOpenTechDocs={onOpenTechDocs}
        />
      );

    case 'techdocs':
      return (
        <TechDocsView
          onTestAudioToggle={onPlayPauseAudio}
          isPlayingAudio={isPlayingAudio}
        />
      );

    case 'google':
      return (
        <div className="h-full w-full bg-white dark:bg-[#121314] text-gray-900 dark:text-gray-100 overflow-y-auto p-6 md:p-10 space-y-6">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center gap-3 border-b border-gray-200 dark:border-gray-800 pb-4">
              <span className="text-2xl font-black text-blue-600">G</span>
              <div className="flex-1 bg-gray-100 dark:bg-gray-800 px-4 py-2 rounded-full border border-gray-300 dark:border-gray-700 text-sm font-medium">
                {activeTab.url.split('q=')[1] ? decodeURIComponent(activeTab.url.split('q=')[1]) : 'Google Search'}
              </div>
            </div>

            <div className="space-y-6 text-xs">
              <div className="p-4 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-900 space-y-2">
                <div className="text-blue-600 dark:text-blue-400 font-bold text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Google Search AI Overview - Background Media & Tab Groups</span>
                </div>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  Trình duyệt Chrome hỗ trợ phát nhạc YouTube ngầm bằng cách bỏ qua ngắt kết nối visibilitychange, đăng ký MediaSession API và khởi chạy luồng WebAudio giữ nhịp phần cứng.
                </p>
              </div>

              {/* Search Result 1 */}
              <div className="space-y-1">
                <div className="text-[10px] text-gray-400 flex items-center gap-1">
                  <Globe className="w-3 h-3 text-emerald-500" />
                  <span>https://developer.chrome.com › docs › web-audio</span>
                </div>
                <h3
                  onClick={onOpenTechDocs}
                  className="text-base font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                >
                  Tài Liệu Kỹ Thuật Phát Nhạc YouTube Ngầm Không Bị Ngắt - Chrome Developers
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-xs">
                  Hướng dẫn chi tiết cách triển khai MediaSession API, AudioContext keep-alive loop và override Page Visibility API cho PWA và trình duyệt di động.
                </p>
              </div>

              {/* Search Result 2 */}
              <div className="space-y-1">
                <div className="text-[10px] text-gray-400 flex items-center gap-1">
                  <Globe className="w-3 h-3 text-red-500" />
                  <span>https://youtube.com › lofi-beats-radio</span>
                </div>
                <h3
                  onClick={onOpenYouTube}
                  className="text-base font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                >
                  YouTube Chill Lofi Beats 24/7 - Background Media Player
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-xs">
                  Trải nghiệm nghe nhạc Lofi Hip Hop thả ga không bị gián đoạn ngay cả khi khóa màn hình hoặc ứng dụng chạy ẩn.
                </p>
              </div>
            </div>
          </div>
        </div>
      );

    default:
      return (
        <div className="h-full w-full bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 flex flex-col items-center justify-center p-6 text-center space-y-4">
          <Globe className="w-12 h-12 text-blue-500 animate-pulse" />
          <h2 className="text-lg font-bold">Trang Web Mới: {activeTab.title}</h2>
          <p className="text-xs text-gray-500 max-w-md">{activeTab.url}</p>
          <div className="flex gap-2">
            <button
              onClick={onOpenYouTube}
              className="px-4 py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition-colors"
            >
              Mở YouTube Background Player
            </button>
            <button
              onClick={onOpenTechDocs}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors"
            >
              Mở Tài Liệu Kỹ Thuật
            </button>
          </div>
        </div>
      );
  }
};
