import React from 'react';
import { TabGroup } from '../types';
import { ChevronRight, ChevronDown } from 'lucide-react';

interface TabGroupHeaderProps {
  group: TabGroup;
  onToggleCollapse: (groupId: string) => void;
}

const COLOR_MAP: Record<TabGroup['color'], { bg: string; text: string; border: string }> = {
  grey: { bg: 'bg-gray-700/50', text: 'text-gray-300', border: 'border-gray-500' },
  blue: { bg: 'bg-blue-600/30', text: 'text-blue-400', border: 'border-blue-500' },
  red: { bg: 'bg-red-600/30', text: 'text-red-400', border: 'border-red-500' },
  yellow: { bg: 'bg-yellow-600/30', text: 'text-yellow-400', border: 'border-yellow-500' },
  green: { bg: 'bg-emerald-600/30', text: 'text-emerald-400', border: 'border-emerald-500' },
  pink: { bg: 'bg-pink-600/30', text: 'text-pink-400', border: 'border-pink-500' },
  purple: { bg: 'bg-purple-600/30', text: 'text-purple-400', border: 'border-purple-500' },
  cyan: { bg: 'bg-cyan-600/30', text: 'text-cyan-400', border: 'border-cyan-500' },
};

export function TabGroupHeader({ group, onToggleCollapse }: TabGroupHeaderProps) {
  const colors = COLOR_MAP[group.color] || COLOR_MAP.blue;

  return (
    <button
      onClick={() => onToggleCollapse(group.id)}
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-semibold transition-all ${colors.bg} ${colors.text} ${colors.border} hover:opacity-90`}
    >
      {group.collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
      <span className="truncate max-w-[100px]">{group.name}</span>
    </button>
  );
}
