import React, { useState } from 'react';
import { TabGroup, TabGroupColor } from '../types';
import { COLOR_MAP } from '../data/initialData';
import { ChevronRight, ChevronDown, MoreHorizontal, Edit3, Trash2, Plus, Palette } from 'lucide-react';

interface TabGroupHeaderProps {
  group: TabGroup;
  tabCount: number;
  onToggleCollapse: (groupId: string) => void;
  onUpdateGroup: (group: TabGroup) => void;
  onDeleteGroup: (groupId: string) => void;
  onAddTabToGroup: (groupId: string) => void;
}

const COLORS: TabGroupColor[] = ['blue', 'red', 'yellow', 'green', 'pink', 'purple', 'cyan', 'orange'];

export const TabGroupHeader: React.FC<TabGroupHeaderProps> = ({
  group,
  tabCount,
  onToggleCollapse,
  onUpdateGroup,
  onDeleteGroup,
  onAddTabToGroup,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [titleInput, setTitleInput] = useState(group.title);

  const style = COLOR_MAP[group.color] || COLOR_MAP.blue;

  const handleSaveTitle = (e: React.FormEvent) => {
    e.preventDefault();
    if (titleInput.trim()) {
      onUpdateGroup({ ...group, title: titleInput.trim() });
    }
    setIsEditing(false);
  };

  return (
    <div className="relative flex items-center group/header">
      {/* Group Pill Header */}
      <div
        className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md cursor-pointer transition-all ${style.badge} border border-black/10 dark:border-white/10 shadow-sm hover:brightness-105`}
        onClick={() => onToggleCollapse(group.id)}
      >
        <span className={`w-2.5 h-2.5 rounded-full ${style.bg} ring-2 ring-white dark:ring-gray-900`} />
        
        {isEditing ? (
          <form onSubmit={handleSaveTitle} onClick={(e) => e.stopPropagation()}>
            <input
              type="text"
              value={titleInput}
              onChange={(e) => setTitleInput(e.target.value)}
              onBlur={handleSaveTitle}
              autoFocus
              className="bg-white/80 dark:bg-gray-800 px-1 py-0.5 rounded text-xs outline-none border border-blue-400 text-gray-900 dark:text-white"
            />
          </form>
        ) : (
          <span className="truncate max-w-[120px] font-medium">{group.title}</span>
        )}

        <span className="text-[10px] opacity-75 px-1 bg-black/10 dark:bg-white/10 rounded-full font-mono">
          {tabCount}
        </span>

        {group.collapsed ? (
          <ChevronRight className="w-3.5 h-3.5 opacity-70" />
        ) : (
          <ChevronDown className="w-3.5 h-3.5 opacity-70" />
        )}

        {/* Options trigger */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsMenuOpen(!isMenuOpen);
          }}
          className="p-0.5 hover:bg-black/10 dark:hover:bg-white/20 rounded transition-colors"
          title="Tùy chọn nhóm tab"
        >
          <MoreHorizontal className="w-3 h-3" />
        </button>
      </div>

      {/* Group Dropdown Menu */}
      {isMenuOpen && (
        <div
          className="absolute top-full left-0 mt-1 w-56 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 py-1.5 z-50 text-gray-800 dark:text-gray-200 text-xs"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-3 py-1 font-semibold text-gray-400 dark:text-gray-500 uppercase text-[10px] tracking-wider">
            Tùy chọn Nhóm Tab
          </div>

          <button
            onClick={() => {
              setIsEditing(true);
              setIsMenuOpen(false);
            }}
            className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <Edit3 className="w-3.5 h-3.5 text-gray-500" />
            <span>Đổi tên nhóm</span>
          </button>

          <button
            onClick={() => {
              onAddTabToGroup(group.id);
              setIsMenuOpen(false);
            }}
            className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <Plus className="w-3.5 h-3.5 text-blue-500" />
            <span>Thêm Tab Mới Vào Nhóm</span>
          </button>

          <div className="my-1 border-t border-gray-100 dark:border-gray-700" />

          {/* Color Selector */}
          <div className="px-3 py-1.5">
            <div className="flex items-center gap-1.5 mb-1.5 text-gray-500">
              <Palette className="w-3.5 h-3.5" />
              <span>Màu sắc nhóm:</span>
            </div>
            <div className="grid grid-cols-4 gap-1.5 pt-1">
              {COLORS.map((color) => {
                const cStyle = COLOR_MAP[color];
                return (
                  <button
                    key={color}
                    onClick={() => {
                      onUpdateGroup({ ...group, color });
                      setIsMenuOpen(false);
                    }}
                    className={`w-6 h-6 rounded-full ${cStyle.bg} flex items-center justify-center transition-transform hover:scale-110 ${
                      group.color === color ? 'ring-2 ring-offset-1 ring-gray-900 dark:ring-white' : ''
                    }`}
                  />
                );
              })}
            </div>
          </div>

          <div className="my-1 border-t border-gray-100 dark:border-gray-700" />

          <button
            onClick={() => {
              onDeleteGroup(group.id);
              setIsMenuOpen(false);
            }}
            className="w-full px-3 py-1.5 text-left flex items-center gap-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Xóa nhóm & Đóng tab</span>
          </button>
        </div>
      )}
    </div>
  );
};
