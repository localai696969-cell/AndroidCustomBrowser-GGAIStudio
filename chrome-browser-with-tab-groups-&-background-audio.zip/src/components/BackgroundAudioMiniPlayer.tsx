import React from 'react';
import { AudioTrack } from '../types';
import { Play, Pause, Volume2, Radio } from 'lucide-react';

interface BackgroundAudioMiniPlayerProps {
  isPlayingAudio: boolean;
  onToggleAudio: () => void;
  currentTrack: AudioTrack;
}

export function BackgroundAudioMiniPlayer({
  isPlayingAudio,
  onToggleAudio,
  currentTrack,
}: BackgroundAudioMiniPlayerProps) {
  return (
    <div className="fixed bottom-4 right-4 z-40 bg-[#242629] border border-gray-700 p-3 rounded-2xl shadow-2xl flex items-center gap-3 text-xs text-white max-w-xs">
      <img
        src={currentTrack.coverUrl}
        alt={currentTrack.title}
        className="w-10 h-10 rounded-lg object-cover border border-gray-700 flex-shrink-0"
      />
      <div className="min-w-0 flex-1">
        <p className="font-bold text-gray-100 truncate">{currentTrack.title}</p>
        <p className="text-[10px] text-gray-400 flex items-center gap-1 mt-0.5">
          <Radio className="w-3 h-3 text-red-500 animate-ping" />
          Background Audio Active
        </p>
      </div>
      <button
        onClick={onToggleAudio}
        className="p-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white shadow transition-transform hover:scale-105"
      >
        {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
      </button>
    </div>
  );
}
