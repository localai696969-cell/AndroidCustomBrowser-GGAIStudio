import React, { useState } from 'react';
import { AudioTrack } from '../types';
import { Play, Pause, SkipForward, SkipBack, Volume2, X, Maximize2, Radio } from 'lucide-react';

interface BackgroundAudioMiniPlayerProps {
  currentTrack: AudioTrack;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNextTrack: () => void;
  onPrevTrack: () => void;
  onOpenPlayerTab: () => void;
}

export const BackgroundAudioMiniPlayer: React.FC<BackgroundAudioMiniPlayerProps> = ({
  currentTrack,
  isPlaying,
  onPlayPause,
  onNextTrack,
  onPrevTrack,
  onOpenPlayerTab,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);

  if (isMinimized) {
    return (
      <button
        onClick={() => setIsMinimized(false)}
        className="fixed bottom-4 right-4 z-40 bg-red-600 hover:bg-red-500 text-white p-3 rounded-full shadow-2xl flex items-center gap-2 text-xs font-bold transition-all hover:scale-105 ring-4 ring-black/20"
        title="Mở trình phát nhạc chạy nền"
      >
        <Radio className="w-4 h-4 animate-pulse" />
        <span className="max-w-[100px] truncate">{currentTrack.title}</span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-40 w-80 bg-white dark:bg-[#2B2D30] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden text-gray-900 dark:text-gray-100 transition-all select-none">
      {/* Mini Player Header */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 px-3 py-1.5 text-white flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 font-semibold">
          <span className="w-2 h-2 rounded-full bg-white animate-ping" />
          <span>YouTube Audio Background</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={onOpenPlayerTab}
            className="p-1 hover:bg-white/20 rounded transition-colors"
            title="Mở toàn màn hình"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 hover:bg-white/20 rounded transition-colors"
            title="Thu nhỏ"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Mini Player Body */}
      <div className="p-3 flex items-center gap-3">
        <img
          src={currentTrack.coverUrl}
          alt={currentTrack.title}
          className={`w-12 h-12 rounded-xl object-cover shadow-md flex-shrink-0 ${
            isPlaying ? 'ring-2 ring-red-500' : ''
          }`}
        />

        <div className="min-w-0 flex-1">
          <div className="font-bold text-xs truncate">{currentTrack.title}</div>
          <div className="text-[10px] text-gray-500 dark:text-gray-400 truncate">{currentTrack.artist}</div>

          {/* Controls */}
          <div className="flex items-center justify-between gap-2 mt-2">
            <div className="flex items-center gap-1">
              <button
                onClick={onPrevTrack}
                className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-gray-600 dark:text-gray-300"
              >
                <SkipBack className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onPlayPause}
                className="p-1.5 bg-red-600 hover:bg-red-500 text-white rounded-full transition-transform hover:scale-105"
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current ml-0.5" />}
              </button>

              <button
                onClick={onNextTrack}
                className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-gray-600 dark:text-gray-300"
              >
                <SkipForward className="w-3.5 h-3.5" />
              </button>
            </div>

            <span className="text-[10px] px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded-full font-medium">
              Chạy Ngầm
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
