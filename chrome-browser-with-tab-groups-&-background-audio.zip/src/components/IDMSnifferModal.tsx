import React from 'react';
import { DownloadTask, SniffedMediaItem } from '../types';
import { X, Download, Play, Pause, Trash2, Zap, CheckCircle2, Film } from 'lucide-react';

export const SAMPLE_SNIFFED_MEDIA: SniffedMediaItem[] = [
  {
    id: 'sniff-1',
    title: 'Lofi_Hip_Hop_Radio_Live_Stream_1080p',
    url: 'https://stream.youtube.com/hls/live_stream_1080p.m3u8',
    format: 'M3U8',
    quality: '1080p FHD',
    fileSize: '250.4 MB',
    sourceUrl: 'https://youtube.com/watch?v=jfKfPfyJRdk',
  },
  {
    id: 'sniff-2',
    title: 'Lofi_Study_Relax_Beats_HQ_Audio',
    url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3',
    format: 'MP3',
    quality: '320kbps MP3',
    fileSize: '18.2 MB',
    sourceUrl: 'https://youtube.com/watch?v=jfKfPfyJRdk',
  },
  {
    id: 'sniff-3',
    title: 'GeckoView_Firefox_Architecture_Demo_4K',
    url: 'https://cdn.pixabay.com/download/video/2021/04/13/video_4k_sample.mp4',
    format: 'MP4',
    quality: '4K 2160p',
    fileSize: '680.5 MB',
    sourceUrl: 'chrome://tech-docs',
  },
];

interface IDMSnifferModalProps {
  onClose: () => void;
  downloadTasks: DownloadTask[];
  onStartDownload: (item: SniffedMediaItem) => void;
  onToggleTaskPause: (taskId: string) => void;
  onRemoveTask: (taskId: string) => void;
}

export function IDMSnifferModal({
  onClose,
  downloadTasks,
  onStartDownload,
  onToggleTaskPause,
  onRemoveTask,
}: IDMSnifferModalProps) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242629] border border-gray-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl text-gray-100 flex flex-col max-h-[85vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800 bg-[#1E2022]">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600 text-white">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">IDM Multimedia Sniffer &amp; Downloader</h2>
              <p className="text-[11px] text-gray-400">Tự động bắt link video/audio HLS/MP4 đa luồng tốc độ cao</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-6 text-xs flex-1">
          {/* Sniffed Media Items */}
          <div className="space-y-2">
            <h3 className="font-bold text-blue-400 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
              <Zap className="w-4 h-4 text-amber-400" /> Link Multimedia Bắt Được Trên Trang ({SAMPLE_SNIFFED_MEDIA.length})
            </h3>
            <div className="space-y-2">
              {SAMPLE_SNIFFED_MEDIA.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-xl bg-[#1A1C1E] border border-gray-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                >
                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.5 rounded bg-blue-600/20 text-blue-400 border border-blue-500/30 font-bold text-[10px]">
                        {item.format}
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-purple-600/20 text-purple-400 border border-purple-500/30 font-bold text-[10px]">
                        {item.quality}
                      </span>
                      <span className="text-gray-400 text-[11px] font-semibold">{item.fileSize}</span>
                    </div>
                    <p className="font-bold text-white truncate">{item.title}</p>
                  </div>

                  <button
                    onClick={() => onStartDownload(item)}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold flex items-center gap-1.5 whitespace-nowrap self-end sm:self-auto"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Tải Về Ngay (IDM)
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Active Download Tasks */}
          <div className="space-y-2 pt-2 border-t border-gray-800">
            <h3 className="font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
              <Film className="w-4 h-4" /> Tiến Trình Tải Tệp
            </h3>
            {downloadTasks.length === 0 ? (
              <p className="text-gray-500 text-center py-4">Chưa có tệp nào đang tải.</p>
            ) : (
              <div className="space-y-2">
                {downloadTasks.map((task) => (
                  <div key={task.id} className="p-3 rounded-xl bg-[#1A1C1E] border border-gray-800 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-bold text-white truncate text-xs">{task.filename}</p>
                      <span className="text-gray-400 text-[11px] font-semibold">{task.speed}</span>
                    </div>

                    <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-blue-500 h-full transition-all duration-300"
                        style={{ width: `${task.progress}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-gray-400">
                      <span>Dung lượng: {task.size} ({task.progress}%)</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onToggleTaskPause(task.id)}
                          className="p-1 hover:bg-gray-700 rounded text-gray-300"
                        >
                          {task.status === 'downloading' ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          onClick={() => onRemoveTask(task.id)}
                          className="p-1 hover:bg-red-900/40 rounded text-red-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
