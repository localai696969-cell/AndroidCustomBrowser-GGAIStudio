import React, { useState } from 'react';
import { Download, Play, CheckCircle2, Pause, Trash2, ArrowDownCircle, HardDrive, FileVideo, Music, Layers } from 'lucide-react';
import { SniffedMediaItem, DownloadTask } from '../types';

interface IDMSnifferModalProps {
  onClose: () => void;
  downloadTasks: DownloadTask[];
  onStartDownload: (item: SniffedMediaItem) => void;
  onToggleTaskPause: (taskId: string) => void;
  onRemoveTask: (taskId: string) => void;
}

export const SAMPLE_SNIFFED_MEDIA: SniffedMediaItem[] = [
  {
    id: 'media-1',
    title: 'Lofi Hip Hop Radio - Beats to Relax/Study to (Live Stream 1080p)',
    url: 'https://stream.youtube.com/hls/live_stream_1080p.m3u8',
    format: 'M3U8',
    quality: '1080p FHD',
    fileSize: 'Stream (Live)',
    thumbnail: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=600&q=80',
    sourceUrl: 'https://youtube.com/watch?v=jfKfPfyJRdk'
  },
  {
    id: 'media-2',
    title: 'Background Audio API In-Depth Masterclass - Full Course',
    url: 'https://media.example.com/video_4k_hdr.mp4',
    format: 'MP4',
    quality: '4K 2160p',
    fileSize: '1.24 GB',
    thumbnail: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80',
    sourceUrl: 'chrome://tech-docs'
  },
  {
    id: 'media-3',
    title: 'Ambient Relaxing Rain & Thunderstorm HQ Audio Track',
    url: 'https://media.example.com/audio_320kbps.mp3',
    format: 'MP3',
    quality: '320kbps MP3',
    fileSize: '48.5 MB',
    thumbnail: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
    sourceUrl: 'https://youtube.com/watch?v=rain_thunder'
  }
];

export function IDMSnifferModal({
  onClose,
  downloadTasks,
  onStartDownload,
  onToggleTaskPause,
  onRemoveTask,
}: IDMSnifferModalProps) {
  const [activeTab, setActiveTab] = useState<'detected' | 'downloads'>('detected');

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#242629] text-gray-100 rounded-xl w-full max-w-3xl border border-gray-700 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-[#1A1C1E] px-6 py-4 border-b border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold flex items-center gap-2">
                IDM Multimedia Sniffer & Download Accelerator
                <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-medium">
                  Active
                </span>
              </h2>
              <p className="text-xs text-gray-400">
                Tự động bắt link Video/Audio, M3U8 Stream đa luồng tốc độ cao
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white px-3 py-1 rounded-lg hover:bg-gray-800 text-sm font-medium transition-colors"
          >
            Đóng ✕
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-gray-800 bg-[#1E2022]">
          <button
            onClick={() => setActiveTab('detected')}
            className={`flex-1 py-3 px-4 text-xs font-semibold flex items-center justify-center gap-2 border-b-2 transition-all ${
              activeTab === 'detected'
                ? 'border-blue-500 text-blue-400 bg-blue-500/10'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            Link Multimedia Đã Bắt Được ({SAMPLE_SNIFFED_MEDIA.length})
          </button>
          <button
            onClick={() => setActiveTab('downloads')}
            className={`flex-1 py-3 px-4 text-xs font-semibold flex items-center justify-center gap-2 border-b-2 transition-all ${
              activeTab === 'downloads'
                ? 'border-blue-500 text-blue-400 bg-blue-500/10'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <ArrowDownCircle className="w-4 h-4" />
            Tiến Trình Tải IDM ({downloadTasks.length})
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'detected' ? (
            <div className="space-y-3">
              {SAMPLE_SNIFFED_MEDIA.map((item) => {
                const isDownloading = downloadTasks.some((t) => t.url === item.url);

                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-lg bg-[#1A1C1E] border border-gray-800 hover:border-gray-700 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      {item.thumbnail ? (
                        <img
                          src={item.thumbnail}
                          alt={item.title}
                          className="w-16 h-12 object-cover rounded-md border border-gray-700 flex-shrink-0"
                        />
                      ) : (
                        <div className="w-16 h-12 rounded-md bg-gray-800 flex items-center justify-center text-gray-400 flex-shrink-0">
                          {item.format === 'MP3' ? <Music className="w-6 h-6" /> : <FileVideo className="w-6 h-6" />}
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <h4 className="text-sm font-semibold text-gray-100 truncate">{item.title}</h4>
                        <div className="flex flex-wrap items-center gap-2 mt-1">
                          <span className="text-[10px] bg-blue-500/20 text-blue-300 font-bold px-2 py-0.5 rounded border border-blue-500/30">
                            {item.format}
                          </span>
                          <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-2 py-0.5 rounded border border-purple-500/30">
                            {item.quality}
                          </span>
                          <span className="text-xs text-gray-400 flex items-center gap-1">
                            <HardDrive className="w-3 h-3" /> {item.fileSize}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-500 truncate mt-1">Nguồn: {item.sourceUrl}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end md:self-center">
                      <button
                        onClick={() => onStartDownload(item)}
                        disabled={isDownloading}
                        className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
                          isDownloading
                            ? 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                            : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/20'
                        }`}
                      >
                        {isDownloading ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            Đang Tải...
                          </>
                        ) : (
                          <>
                            <Download className="w-4 h-4" />
                            Tải Bằng IDM
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="space-y-3">
              {downloadTasks.length === 0 ? (
                <div className="py-12 text-center text-gray-500 flex flex-col items-center justify-center">
                  <ArrowDownCircle className="w-12 h-12 mb-3 text-gray-600" />
                  <p className="text-sm font-medium">Chưa có tiến trình tải IDM nào.</p>
                  <p className="text-xs text-gray-600 mt-1">
                    Hãy bấm nút "Tải Bằng IDM" ở tab bắt link để bắt đầu tải tập tin.
                  </p>
                </div>
              ) : (
                downloadTasks.map((task) => (
                  <div key={task.id} className="p-4 rounded-lg bg-[#1A1C1E] border border-gray-800 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-gray-100 truncate">{task.filename}</p>
                        <p className="text-xs text-gray-400">
                          {task.size} • {task.speed} • Status: <span className="text-blue-400 font-medium capitalize">{task.status}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onToggleTaskPause(task.id)}
                          className="p-1.5 rounded-md bg-gray-800 hover:bg-gray-700 text-gray-300"
                          title={task.status === 'downloading' ? 'Tạm dừng' : 'Tiếp tục'}
                        >
                          {task.status === 'downloading' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </button>
                        <button
                          onClick={() => onRemoveTask(task.id)}
                          className="p-1.5 rounded-md bg-red-500/10 hover:bg-red-500/20 text-red-400"
                          title="Hủy tải"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-gray-800 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          task.status === 'completed' ? 'bg-emerald-500' : 'bg-blue-500'
                        }`}
                        style={{ width: `${task.progress}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-[11px] text-gray-500">
                      <span>{task.progress}% Hoàn thành</span>
                      <span>{task.status === 'completed' ? 'Tải xong' : task.speed}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="bg-[#1A1C1E] px-6 py-3 border-t border-gray-800 text-xs text-gray-400 flex items-center justify-between">
          <span>Công nghệ IDM Multi-segment Chunking Engine Active</span>
          <span className="text-blue-400 font-medium">Băng thông: Unlimited 80MB/s</span>
        </div>
      </div>
    </div>
  );
}
