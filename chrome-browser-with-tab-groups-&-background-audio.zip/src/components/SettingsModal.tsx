import React from 'react';
import { X, Settings, Moon, Sun, Volume2, Shield, Trash2, Info } from 'lucide-react';

interface SettingsModalProps {
  onClose: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onClearData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  onClose,
  isDarkMode,
  onToggleDarkMode,
  onClearData,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#2B2D30] rounded-2xl max-w-md w-full border border-gray-200 dark:border-gray-700 shadow-2xl p-6 text-gray-900 dark:text-gray-100 space-y-5">
        <div className="flex items-center justify-between border-b border-gray-200 dark:border-gray-700 pb-3">
          <div className="flex items-center gap-2 font-bold text-base">
            <Settings className="w-5 h-5 text-gray-600 dark:text-gray-300" />
            <span>Cài Đặt Google Chrome</span>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Options */}
        <div className="space-y-4 text-xs">
          {/* Appearance / Theme */}
          <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isDarkMode ? <Moon className="w-4 h-4 text-purple-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
              <div>
                <div className="font-semibold">Giao Diện (Theme)</div>
                <div className="text-[10px] text-gray-500">{isDarkMode ? 'Chế độ Tối (Dark)' : 'Chế độ Sáng (Light)'}</div>
              </div>
            </div>

            <button
              onClick={onToggleDarkMode}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold transition-colors"
            >
              Chuyển {isDarkMode ? 'Sáng' : 'Tối'}
            </button>
          </div>

          {/* Background Audio Engine */}
          <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-red-500" />
              <div>
                <div className="font-semibold">Phát Nhạc Background Engine</div>
                <div className="text-[10px] text-gray-500">Tự động giữ âm thanh khi khóa màn hình</div>
              </div>
            </div>

            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-bold">
              BẬT
            </span>
          </div>

          {/* Clear Data */}
          <div className="p-3 bg-red-50 dark:bg-red-950/30 rounded-xl border border-red-200 dark:border-red-900/50 flex items-center justify-between">
            <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
              <Trash2 className="w-4 h-4" />
              <div>
                <div className="font-semibold">Xóa Dữ Liệu Duyệt Web</div>
                <div className="text-[10px] opacity-80">Đặt lại lịch sử & danh sách nhóm tab</div>
              </div>
            </div>

            <button
              onClick={onClearData}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold transition-colors"
            >
              Xóa Dữ Liệu
            </button>
          </div>

          {/* About Chrome */}
          <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-200 dark:border-blue-900/50 space-y-1">
            <div className="flex items-center gap-2 font-bold text-blue-700 dark:text-blue-300">
              <Info className="w-4 h-4" />
              <span>Google Chrome - Custom Build 128.0</span>
            </div>
            <p className="text-[11px] text-gray-600 dark:text-gray-300">
              Tích hợp đầy đủ Tab Grouping & YouTube Background Playback Engine dựa trên MediaSession và WebAudio API.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
