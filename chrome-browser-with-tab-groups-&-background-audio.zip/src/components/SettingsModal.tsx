import React from 'react';
import { EngineConfig } from '../types';
import { X, Settings, Moon, Sun, Bookmark, Cpu, ShieldCheck } from 'lucide-react';

interface SettingsModalProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  showBookmarksBar: boolean;
  onToggleBookmarksBar: () => void;
  onClose: () => void;
  engineConfig: EngineConfig;
  onToggleEngine: () => void;
}

export function SettingsModal({
  isDarkMode,
  onToggleDarkMode,
  showBookmarksBar,
  onToggleBookmarksBar,
  onClose,
  engineConfig,
  onToggleEngine,
}: SettingsModalProps) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242629] border border-gray-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl text-gray-100">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-gray-400" />
            <h2 className="text-base font-bold">Cài Đặt Trình Duyệt Chrome</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          {/* Core Engine Switch */}
          <div className="p-3.5 rounded-xl bg-[#1A1C1E] border border-gray-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white flex items-center gap-2">
                <Cpu className="w-4 h-4 text-purple-400" /> Engine Render Lõi Trình Duyệt
              </span>
              <button
                onClick={onToggleEngine}
                className="px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold uppercase"
              >
                {engineConfig.type}
              </button>
            </div>
            <p className="text-[11px] text-gray-400">
              {engineConfig.type === 'chromium'
                ? 'Đang dùng Chromium Engine. Tốt nhất cho các ứng dụng web desktop tiêu chuẩn.'
                : 'Đang dùng GeckoView Firefox Engine. Tối ưu cho Mobile & chạy ngầm không bị ngắt.'}
            </p>
          </div>

          {/* Theme Switch */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#1A1C1E] border border-gray-800">
            <span className="font-semibold text-gray-200 flex items-center gap-2">
              {isDarkMode ? <Moon className="w-4 h-4 text-blue-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
              Giao Diện Tối (Dark Mode)
            </span>
            <input
              type="checkbox"
              checked={isDarkMode}
              onChange={onToggleDarkMode}
              className="toggle-checkbox rounded bg-gray-700 border-gray-600"
            />
          </div>

          {/* Bookmarks Bar Switch */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#1A1C1E] border border-gray-800">
            <span className="font-semibold text-gray-200 flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-yellow-400" />
              Hiển Thị Thanh Dấu Trang (Bookmarks Bar)
            </span>
            <input
              type="checkbox"
              checked={showBookmarksBar}
              onChange={onToggleBookmarksBar}
              className="toggle-checkbox rounded bg-gray-700 border-gray-600"
            />
          </div>

          {/* Security Banner */}
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-emerald-400">
            <ShieldCheck className="w-5 h-5 flex-shrink-0" />
            <span>Bảo vệ quyền riêng tư &amp; Chặn quảng cáo mặc định đang BẬT.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
