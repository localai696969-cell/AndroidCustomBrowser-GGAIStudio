import React, { useState } from 'react';
import { PlaylistItem } from '../types';
import { X, Youtube, Download, CheckSquare, Square, Film, Music } from 'lucide-react';

interface PlaylistDownloaderModalProps {
  onClose: () => void;
  onStartPlaylistDownload: (items: PlaylistItem[], format: 'MP4' | 'MP3' | 'WEBM', quality: string) => void;
}

const SAMPLE_PLAYLIST: PlaylistItem[] = [
  { id: '1', youtubeId: 'jfKfPfyJRdk', title: 'Lofi Hip Hop Radio - Beats to Relax/Study to', duration: '3:45:00', author: 'Lofi Girl', thumbnail: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=300&q=80', selected: true },
  { id: '2', youtubeId: '5qap5aO4i9A', title: 'Synthwave Radio - Chill Retrowave Melodies', duration: '2:15:30', author: 'Lofi Girl Synthwave', thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=300&q=80', selected: true },
  { id: '3', youtubeId: 'DWcjTZqg88M', title: 'Coffee Shop Acoustic Guitar & Jazz Piano', duration: '1:50:20', author: 'Cafe Music BGM', thumbnail: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=300&q=80', selected: true },
];

export function PlaylistDownloaderModal({
  onClose,
  onStartPlaylistDownload,
}: PlaylistDownloaderModalProps) {
  const [playlistUrl, setPlaylistUrl] = useState('https://youtube.com/playlist?list=PLlofi_2026_lofi_vibes');
  const [items, setItems] = useState<PlaylistItem[]>(SAMPLE_PLAYLIST);
  const [format, setFormat] = useState<'MP4' | 'MP3' | 'WEBM'>('MP4');
  const [quality, setQuality] = useState<string>('1080p FHD');

  const handleToggleSelectAll = () => {
    const allSelected = items.every((it) => it.selected);
    setItems((prev) => prev.map((it) => ({ ...it, selected: !allSelected })));
  };

  const handleToggleSelect = (id: string) => {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, selected: !it.selected } : it)));
  };

  const handleStart = () => {
    const selectedItems = items.filter((it) => it.selected);
    if (selectedItems.length > 0) {
      onStartPlaylistDownload(selectedItems, format, quality);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242629] border border-gray-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl text-gray-100 flex flex-col max-h-[85vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800 bg-[#1E2022]">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-red-600 text-white">
              <Youtube className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">YouTube &amp; Playlist Downloader</h2>
              <p className="text-[11px] text-gray-400">Tải xuống danh sách phát hàng loạt chất lượng cao 4K/1080p/MP3 320kbps</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 text-xs flex-1">
          {/* URL Input */}
          <div>
            <label className="block font-semibold text-gray-400 mb-1">Dán URL Danh Sách Phát YouTube:</label>
            <input
              type="text"
              value={playlistUrl}
              onChange={(e) => setPlaylistUrl(e.target.value)}
              className="w-full bg-[#1A1C1E] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Config options */}
          <div className="grid grid-cols-2 gap-4 bg-[#1A1C1E] p-3 rounded-xl border border-gray-800">
            <div>
              <label className="block font-semibold text-gray-400 mb-1">Định Dạng Xuất File:</label>
              <div className="flex gap-2">
                {(['MP4', 'MP3', 'WEBM'] as const).map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFormat(f)}
                    className={`px-3 py-1 rounded-lg border font-bold transition-all ${
                      format === f ? 'bg-red-600 text-white border-red-500' : 'bg-gray-800 text-gray-300 border-gray-700'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-semibold text-gray-400 mb-1">Chất Lượng Video / Âm Thanh:</label>
              <select
                value={quality}
                onChange={(e) => setQuality(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-1 focus:outline-none"
              >
                <option value="4K 2160p">4K 2160p Ultra HD</option>
                <option value="1080p FHD">1080p Full HD</option>
                <option value="720p HD">720p HD</option>
                <option value="320kbps MP3">320kbps HQ Audio Only</option>
              </select>
            </div>
          </div>

          {/* Video list */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-gray-300">Danh Sách Video Trong Playlist ({items.length}):</span>
              <button
                onClick={handleToggleSelectAll}
                className="text-red-400 hover:underline flex items-center gap-1 font-semibold"
              >
                Chọn tất cả / Bỏ chọn
              </button>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {items.map((it) => (
                <div
                  key={it.id}
                  onClick={() => handleToggleSelect(it.id)}
                  className={`p-2.5 rounded-xl border cursor-pointer flex items-center gap-3 transition-all ${
                    it.selected ? 'bg-red-600/10 border-red-500/40 text-white' : 'bg-[#1A1C1E] border-gray-800 text-gray-400'
                  }`}
                >
                  {it.selected ? <CheckSquare className="w-4 h-4 text-red-500 flex-shrink-0" /> : <Square className="w-4 h-4 text-gray-600 flex-shrink-0" />}
                  <img src={it.thumbnail} alt={it.title} className="w-10 h-10 rounded-lg object-cover border border-gray-700 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="font-bold truncate text-xs">{it.title}</p>
                    <p className="text-[10px] text-gray-500">{it.author} • {it.duration}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-800">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold"
            >
              Hủy
            </button>
            <button
              onClick={handleStart}
              className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              Tải Tất Cả Video Đã Chọn
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
