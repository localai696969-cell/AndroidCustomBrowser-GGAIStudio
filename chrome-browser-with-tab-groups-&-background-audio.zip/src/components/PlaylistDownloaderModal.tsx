import React, { useState } from 'react';
import { Youtube, Download, CheckSquare, Square, Music, Video, ListVideo, Sparkles } from 'lucide-react';
import { PlaylistItem } from '../types';

interface PlaylistDownloaderModalProps {
  onClose: () => void;
  onStartPlaylistDownload: (items: PlaylistItem[], format: 'MP4' | 'MP3' | 'WEBM', quality: string) => void;
}

const SAMPLE_PLAYLIST_ITEMS: PlaylistItem[] = [
  {
    id: 'pl-1',
    youtubeId: 'jfKfPfyJRdk',
    title: 'Lofi Hip Hop Radio - Beats to Relax/Study to',
    duration: '3:45:00',
    author: 'Lofi Girl',
    thumbnail: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=600&q=80',
    selected: true,
  },
  {
    id: 'pl-2',
    youtubeId: '5qap5aO4i9A',
    title: 'Chillhop Radio - Jazzy & Lofi Hip Hop Beats',
    duration: '2:15:30',
    author: 'Chillhop Music',
    thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
    selected: true,
  },
  {
    id: 'pl-3',
    youtubeId: 'DWcjTZqg88M',
    title: 'Cozy Rain Ambient Study Music & Coffee Shop Ambience',
    duration: '1:30:00',
    author: 'Coffee Shop Vibes',
    thumbnail: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=600&q=80',
    selected: true,
  },
  {
    id: 'pl-4',
    youtubeId: 'rain_thunder',
    title: 'Deep Focus Chill Synthwave & Cyberpunk Ambient Loop',
    duration: '45:12',
    author: 'SynthWave Central',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80',
    selected: true,
  },
];

export function PlaylistDownloaderModal({ onClose, onStartPlaylistDownload }: PlaylistDownloaderModalProps) {
  const [playlistUrl, setPlaylistUrl] = useState('https://www.youtube.com/playlist?list=PLDloqL9m1mQ9lo');
  const [items, setItems] = useState<PlaylistItem[]>(SAMPLE_PLAYLIST_ITEMS);
  const [selectedFormat, setSelectedFormat] = useState<'MP4' | 'MP3' | 'WEBM'>('MP4');
  const [selectedQuality, setSelectedQuality] = useState<string>('1080p FHD');
  const [isProcessing, setIsProcessing] = useState(false);

  const toggleSelectAll = () => {
    const allSelected = items.every((i) => i.selected);
    setItems((prev) => prev.map((item) => ({ ...item, selected: !allSelected })));
  };

  const toggleSelectItem = (id: string) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, selected: !item.selected } : item))
    );
  };

  const selectedCount = items.filter((i) => i.selected).length;

  const handleDownload = () => {
    const selectedItems = items.filter((i) => i.selected);
    if (selectedItems.length === 0) return;
    setIsProcessing(true);
    setTimeout(() => {
      onStartPlaylistDownload(selectedItems, selectedFormat, selectedQuality);
      setIsProcessing(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#242629] text-gray-100 rounded-xl w-full max-w-3xl border border-gray-700 shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-[#1A1C1E] px-6 py-4 border-b border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-500">
              <Youtube className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold flex items-center gap-2">
                YouTube & Playlist Downloader
                <span className="text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded border border-red-500/30 font-medium">
                  HD / 4K / MP3
                </span>
              </h2>
              <p className="text-xs text-gray-400">
                Tải hàng loạt Video & Playlist YouTube độ phân giải cao nhất
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white px-3 py-1 rounded-lg hover:bg-gray-800 text-sm font-medium transition-colors"
          >
            Đóng ✕
          </button>
        </div>

        {/* Input Link Section */}
        <div className="p-6 bg-[#1E2022] border-b border-gray-800 space-y-4">
          <div>
            <label className="text-xs font-semibold text-gray-300 mb-1.5 block">
              Dán URL Video hoặc URL Danh sách phát (Playlist URL):
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={playlistUrl}
                onChange={(e) => setPlaylistUrl(e.target.value)}
                placeholder="https://www.youtube.com/playlist?list=..."
                className="flex-1 bg-[#1A1C1E] border border-gray-700 rounded-lg px-3.5 py-2 text-xs text-gray-100 focus:outline-none focus:border-red-500"
              />
              <button
                onClick={() => {}}
                className="bg-gray-800 hover:bg-gray-700 text-gray-200 px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 border border-gray-700"
              >
                <Sparkles className="w-4 h-4 text-red-400" />
                Phân Tích Link
              </button>
            </div>
          </div>

          {/* Config Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-gray-800">
            <div>
              <label className="text-xs font-semibold text-gray-400 mb-1 block">Định dạng xuất:</label>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedFormat('MP4')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1.5 ${
                    selectedFormat === 'MP4'
                      ? 'bg-red-600/20 border-red-500 text-red-400'
                      : 'bg-[#1A1C1E] border-gray-700 text-gray-400'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" /> MP4 Video
                </button>
                <button
                  onClick={() => setSelectedFormat('MP3')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1.5 ${
                    selectedFormat === 'MP3'
                      ? 'bg-red-600/20 border-red-500 text-red-400'
                      : 'bg-[#1A1C1E] border-gray-700 text-gray-400'
                  }`}
                >
                  <Music className="w-3.5 h-3.5" /> MP3 Audio Only
                </button>
                <button
                  onClick={() => setSelectedFormat('WEBM')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1.5 ${
                    selectedFormat === 'WEBM'
                      ? 'bg-red-600/20 border-red-500 text-red-400'
                      : 'bg-[#1A1C1E] border-gray-700 text-gray-400'
                  }`}
                >
                  WEBM
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-400 mb-1 block">Chất lượng tải:</label>
              <select
                value={selectedQuality}
                onChange={(e) => setSelectedQuality(e.target.value)}
                className="w-full bg-[#1A1C1E] border border-gray-700 rounded-lg px-3 py-1.5 text-xs text-gray-200 focus:outline-none focus:border-red-500"
              >
                <option value="4K 2160p">4K Ultra HD (2160p - 60fps)</option>
                <option value="1080p FHD">Full HD (1080p High Bitrate)</option>
                <option value="720p HD">HD Ready (720p)</option>
                <option value="320kbps Audio">320 kbps Lossless MP3</option>
              </select>
            </div>
          </div>
        </div>

        {/* Playlist Items List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          <div className="flex items-center justify-between text-xs text-gray-400 pb-2 border-b border-gray-800">
            <button
              onClick={toggleSelectAll}
              className="flex items-center gap-2 hover:text-white font-medium"
            >
              {items.every((i) => i.selected) ? (
                <CheckSquare className="w-4 h-4 text-red-500" />
              ) : (
                <Square className="w-4 h-4 text-gray-500" />
              )}
              Chọn tất cả ({items.length} video)
            </button>
            <span className="text-gray-400">
              Đã chọn: <strong className="text-red-400">{selectedCount}</strong> video
            </span>
          </div>

          <div className="space-y-2">
            {items.map((item) => (
              <div
                key={item.id}
                onClick={() => toggleSelectItem(item.id)}
                className={`p-3 rounded-lg border cursor-pointer transition-all flex items-center justify-between gap-3 ${
                  item.selected
                    ? 'bg-[#1A1C1E] border-red-500/40'
                    : 'bg-[#1A1C1E]/50 border-gray-800 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {item.selected ? (
                    <CheckSquare className="w-4 h-4 text-red-500 flex-shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-gray-600 flex-shrink-0" />
                  )}
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    className="w-14 h-10 object-cover rounded border border-gray-700 flex-shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-gray-200 truncate">{item.title}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">
                      Kênh: {item.author} • Thời lượng: {item.duration}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Footer */}
        <div className="bg-[#1A1C1E] px-6 py-4 border-t border-gray-800 flex items-center justify-between">
          <span className="text-xs text-gray-400 flex items-center gap-1.5">
            <ListVideo className="w-4 h-4 text-red-400" />
            Tải Playlist tốc độ cao không giới hạn
          </span>
          <button
            onClick={handleDownload}
            disabled={selectedCount === 0 || isProcessing}
            className={`px-6 py-2.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
              selectedCount === 0
                ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
                : 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-600/30'
            }`}
          >
            <Download className="w-4 h-4" />
            {isProcessing ? 'Đang Khởi Tạo...' : `Tải Ngay (${selectedCount} Video)`}
          </button>
        </div>
      </div>
    </div>
  );
}
