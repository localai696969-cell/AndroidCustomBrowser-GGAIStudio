import React from 'react';
import { Bookmark } from '../types';
import { Globe, Youtube, Github, History, Folder } from 'lucide-react';

interface BookmarksBarProps {
  bookmarks: Bookmark[];
  onNavigate: (url: string) => void;
  onOpenHistoryModal: () => void;
}

export function BookmarksBar({ bookmarks, onNavigate, onOpenHistoryModal }: BookmarksBarProps) {
  const getIcon = (iconName?: string) => {
    if (iconName === 'youtube') return <Youtube className="w-3.5 h-3.5 text-red-500" />;
    if (iconName === 'github') return <Github className="w-3.5 h-3.5 text-gray-300" />;
    return <Globe className="w-3.5 h-3.5 text-blue-400" />;
  };

  return (
    <div className="bg-[#1E2022] border-b border-gray-800 px-3 py-1 flex items-center gap-2 overflow-x-auto text-xs text-gray-300 select-none">
      <button
        onClick={onOpenHistoryModal}
        className="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-gray-800 text-gray-400 hover:text-gray-100 transition-colors"
      >
        <History className="w-3.5 h-3.5 text-purple-400" />
        <span>Lịch Sử</span>
      </button>

      <div className="h-3 w-[1px] bg-gray-700 mx-1" />

      {bookmarks.map((bm) => (
        <button
          key={bm.id}
          onClick={() => onNavigate(bm.url)}
          className="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-gray-800 transition-colors truncate max-w-[160px]"
        >
          {getIcon(bm.icon)}
          <span className="truncate">{bm.title}</span>
        </button>
      ))}
    </div>
  );
}
