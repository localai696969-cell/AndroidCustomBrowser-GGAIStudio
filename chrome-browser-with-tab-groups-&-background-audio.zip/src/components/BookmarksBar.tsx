import React from 'react';
import { Bookmark } from '../types';
import { Youtube, FileText, Search, Github, Code, Music, Globe } from 'lucide-react';

interface BookmarksBarProps {
  bookmarks: Bookmark[];
  onOpenBookmark: (url: string, title: string) => void;
}

export const BookmarksBar: React.FC<BookmarksBarProps> = ({ bookmarks, onOpenBookmark }) => {
  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Youtube':
        return <Youtube className="w-3.5 h-3.5 text-red-500" />;
      case 'FileText':
        return <FileText className="w-3.5 h-3.5 text-blue-500" />;
      case 'Search':
        return <Search className="w-3.5 h-3.5 text-emerald-500" />;
      case 'Github':
        return <Github className="w-3.5 h-3.5 text-gray-800 dark:text-gray-200" />;
      case 'Code':
        return <Code className="w-3.5 h-3.5 text-purple-500" />;
      case 'Music':
        return <Music className="w-3.5 h-3.5 text-pink-500" />;
      default:
        return <Globe className="w-3.5 h-3.5 text-gray-400" />;
    }
  };

  return (
    <div className="bg-[#F8F9FA] dark:bg-[#202124] border-b border-gray-200 dark:border-gray-800 px-3 py-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs select-none">
      {bookmarks.map((bm) => (
        <button
          key={bm.id}
          onClick={() => onOpenBookmark(bm.url, bm.title)}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-gray-200/70 dark:hover:bg-gray-700/70 text-gray-700 dark:text-gray-300 transition-colors flex-shrink-0"
        >
          {renderIcon(bm.icon)}
          <span className="truncate max-w-[120px] font-normal">{bm.title}</span>
        </button>
      ))}
    </div>
  );
};
