import React from 'react';
import { AudioTrack } from '../types';
import { YOUTUBE_TRACKS } from '../data/initialData';
import { Play, Pause, Volume2, Music, Radio, Sparkles, FileText } from 'lucide-react';

interface YouTubePlayerViewProps {
  isPlayingAudio: boolean;
  onToggleAudio: () => void;
  currentTrack: AudioTrack;
  onSelectTrack: (track: AudioTrack) => void;
  onOpenTechDocs: () => void;
}

export function YouTubePlayerView({
  isPlayingAudio,
  onToggleAudio,
  currentTrack,
  onSelectTrack,
  onOpenTechDocs,
}: YouTubePlayerViewProps) {
  return (
    <div className="h-full overflow-y-auto p-4 md:p-8 bg-[#1A1C1E] text-gray-100 flex flex-col items-center justify-center">
      <div className="w-full max-w-4xl space-y-6">
        {/* Banner Alert */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-red-600/20 via-purple-600/20 to-blue-600/20 border border-red-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-red-600/30 text-red-400">
              <Radio className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-sm font-bold flex items-center gap-2">
                YOUTUBE BACKGROUND MEDIA ENGINE ACTIVE
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-semibold">
                  Duy Trì Khi Chuyển Tab / Tắt Màn Hình
                </span>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Nền tảng âm thanh phát ngầm liên tục, sử dụng MediaSession API &amp; GeckoView Keep-Alive Core.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenTechDocs}
            className="px-3.5 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all"
          >
            <FileText className="w-3.5 h-3.5" />
            Xem Tài Liệu Kỹ Thuật Phát Ngầm
          </button>
        </div>

        {/* Main Video & Controls Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#242629] p-6 rounded-2xl border border-gray-800 shadow-2xl">
          {/* Cover Art / Video Display */}
          <div className="md:col-span-1 flex flex-col items-center justify-center space-y-3">
            <div className="relative w-full aspect-square max-w-[220px] rounded-xl overflow-hidden border border-gray-700 shadow-xl group">
              <img
                src={currentTrack.coverUrl}
                alt={currentTrack.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <button
                  onClick={onToggleAudio}
                  className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-110"
                >
                  {isPlayingAudio ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                </button>
              </div>
              <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 text-[10px] font-bold text-red-400 flex items-center gap-1">
                <Radio className="w-3 h-3 animate-ping" /> LIVE BACKGROUND AUDIO
              </div>
            </div>
            <div className="text-center">
              <h2 className="text-sm font-bold text-gray-100 line-clamp-1">{currentTrack.title}</h2>
              <p className="text-xs text-gray-400 mt-0.5">Nghệ sĩ: {currentTrack.artist} • Album: {currentTrack.album}</p>
            </div>
          </div>

          {/* Playlist Selection */}
          <div className="md:col-span-2 flex flex-col justify-between space-y-4">
            <div>
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Danh Sách Nhạc Lofi Background Có Sẵn
              </h3>
              <div className="space-y-2">
                {YOUTUBE_TRACKS.map((track) => {
                  const isSelected = track.id === currentTrack.id;
                  return (
                    <div
                      key={track.id}
                      onClick={() => onSelectTrack(track)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between gap-3 ${
                        isSelected
                          ? 'bg-red-600/10 border-red-500/40 text-white'
                          : 'bg-[#1A1C1E] border-gray-800 text-gray-300 hover:border-gray-700'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <img
                          src={track.coverUrl}
                          alt={track.title}
                          className="w-10 h-10 object-cover rounded-lg border border-gray-700 flex-shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold truncate">{track.title}</p>
                          <p className="text-[11px] text-gray-500">{track.artist}</p>
                        </div>
                      </div>
                      {isSelected && isPlayingAudio && (
                        <div className="flex items-center gap-1 text-red-400">
                          <Volume2 className="w-4 h-4 animate-pulse" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Audio Pipeline Config */}
            <div className="p-3 rounded-lg bg-[#1A1C1E] border border-gray-800 text-xs text-gray-400 flex items-center justify-between">
              <span>Bảo vệ luồng âm thanh nền:</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  Page Visibility Override Active
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
