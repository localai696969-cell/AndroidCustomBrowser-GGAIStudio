import React, { useState, useEffect, useRef } from 'react';
import { AudioTrack } from '../types';
import { YOUTUBE_TRACKS } from '../data/initialData';
import { backgroundAudioService } from '../services/backgroundAudio';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Maximize2,
  Tv,
  CheckCircle2,
  ShieldAlert,
  Activity,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';

interface YouTubePlayerViewProps {
  currentTrack: AudioTrack;
  isPlaying: boolean;
  onPlayPause: () => void;
  onSelectTrack: (track: AudioTrack) => void;
  onNextTrack: () => void;
  onPrevTrack: () => void;
  onOpenTechDocs: () => void;
}

export const YouTubePlayerView: React.FC<YouTubePlayerViewProps> = ({
  currentTrack,
  isPlaying,
  onPlayPause,
  onSelectTrack,
  onNextTrack,
  onPrevTrack,
  onOpenTechDocs,
}) => {
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [isPipActive, setIsPipActive] = useState(false);

  const [visibilityOverride, setVisibilityOverride] = useState(true);
  const [audioCtxKeepAlive, setAudioCtxKeepAlive] = useState(true);
  const [wakeLockActive, setWakeLockActive] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);

  // Sync progress timer when playing
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= currentTrack.duration ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentTrack]);

  // Picture-in-Picture Toggle
  const togglePip = async () => {
    try {
      if (videoRef.current) {
        if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
          setIsPipActive(false);
        } else {
          await videoRef.current.requestPictureInPicture();
          setIsPipActive(true);
        }
      }
    } catch (err) {
      console.warn('PiP not available:', err);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="h-full w-full bg-[#0F0F0F] text-white overflow-y-auto p-4 md:p-6 flex flex-col items-center">
      <div className="w-full max-w-5xl space-y-6">
        {/* Top Header & Status Badge */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-gray-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-red-600 text-white font-bold text-xs uppercase tracking-wider">
                YouTube Background Media
              </span>
              <span className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-800">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Duy Trì Khi Chuyển Tab / Tắt Màn Hình
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold mt-2">{currentTrack.title}</h1>
            <p className="text-xs text-gray-400">Nghệ sĩ: {currentTrack.artist} • Album: {currentTrack.album}</p>
          </div>

          <button
            onClick={onOpenTechDocs}
            className="flex items-center gap-2 px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 rounded-lg text-xs font-medium transition-all"
          >
            <Info className="w-4 h-4" />
            <span>Xem Tài Liệu Kỹ Thuật Phát Ngầm</span>
          </button>
        </div>

        {/* Video Stage & Visualizer */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Video Screen / Player Art */}
          <div className="lg:col-span-2 bg-gray-900 rounded-2xl overflow-hidden border border-gray-800 relative shadow-2xl group">
            {/* Embedded Video/Audio Canvas Frame */}
            <div className="relative aspect-video w-full bg-black flex items-center justify-center overflow-hidden">
              <img
                src={currentTrack.coverUrl}
                alt={currentTrack.title}
                className={`w-full h-full object-cover transition-transform duration-700 ${
                  isPlaying ? 'scale-105 filter brightness-90' : 'scale-100 filter brightness-50'
                }`}
              />

              {/* Fake Video element for PiP support */}
              <video
                ref={videoRef}
                src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                className="hidden"
                muted
                loop
              />

              {/* Audio Frequency Waveform Overlay */}
              {isPlaying && (
                <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black via-black/40 to-transparent p-4 flex items-end justify-center gap-1.5">
                  {[...Array(28)].map((_, i) => (
                    <div
                      key={i}
                      className="w-1.5 bg-red-500 rounded-t transition-all duration-150"
                      style={{
                        height: `${Math.max(15, Math.floor(Math.sin(i + progress) * 40 + 50))}%`,
                        opacity: 0.8 + (i % 3) * 0.1,
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Big Center Play/Pause Overlay */}
              <button
                onClick={onPlayPause}
                className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-2xl hover:scale-110 transition-transform group-hover:opacity-100 opacity-90"
              >
                {isPlaying ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
              </button>

              {/* Top Corner Live Badge */}
              <div className="absolute top-3 left-3 flex items-center gap-2 bg-black/60 backdrop-blur px-3 py-1 rounded-full text-xs font-medium border border-white/10">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                <span>LIVE BACKGROUND AUDIO</span>
              </div>
            </div>

            {/* Audio Controls Bar */}
            <div className="p-4 bg-gray-900/90 backdrop-blur space-y-3">
              {/* Scrubbing Bar */}
              <div className="space-y-1">
                <input
                  type="range"
                  min="0"
                  max={currentTrack.duration}
                  value={progress}
                  onChange={(e) => setProgress(Number(e.target.value))}
                  className="w-full accent-red-500 h-1.5 bg-gray-700 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-gray-400 font-mono">
                  <span>{formatTime(progress)}</span>
                  <span>{formatTime(currentTrack.duration)}</span>
                </div>
              </div>

              {/* Buttons Bar */}
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <button
                    onClick={onPrevTrack}
                    className="p-2 hover:bg-gray-800 rounded-full transition-colors text-gray-300 hover:text-white"
                  >
                    <SkipBack className="w-5 h-5" />
                  </button>

                  <button
                    onClick={onPlayPause}
                    className="p-3 bg-red-600 hover:bg-red-500 text-white rounded-full transition-transform hover:scale-105"
                  >
                    {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
                  </button>

                  <button
                    onClick={onNextTrack}
                    className="p-2 hover:bg-gray-800 rounded-full transition-colors text-gray-300 hover:text-white"
                  >
                    <SkipForward className="w-5 h-5" />
                  </button>
                </div>

                {/* Volume & PiP */}
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className="p-1.5 hover:bg-gray-800 rounded-full text-gray-300"
                    >
                      {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={isMuted ? 0 : volume}
                      onChange={(e) => {
                        setVolume(Number(e.target.value));
                        setIsMuted(false);
                      }}
                      className="w-20 accent-red-500 h-1 bg-gray-700 rounded cursor-pointer"
                    />
                  </div>

                  <button
                    onClick={togglePip}
                    className={`p-2 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
                      isPipActive
                        ? 'bg-red-600 text-white'
                        : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                    }`}
                    title="Bật/tắt chế độ Picture-in-Picture"
                  >
                    <Tv className="w-4 h-4" />
                    <span className="hidden sm:inline">PiP Window</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Playlist / Track Switcher */}
          <div className="bg-gray-900/60 rounded-2xl border border-gray-800 p-4 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-400" />
                Danh Sách Nhạc Lofi Background
              </h3>

              <div className="space-y-2">
                {YOUTUBE_TRACKS.map((track) => {
                  const isSelected = track.id === currentTrack.id;
                  return (
                    <div
                      key={track.id}
                      onClick={() => onSelectTrack(track)}
                      className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
                        isSelected
                          ? 'bg-red-950/40 border-red-500/60 text-white'
                          : 'bg-gray-800/40 border-gray-800 hover:bg-gray-800 text-gray-300'
                      }`}
                    >
                      <img src={track.coverUrl} alt={track.title} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <div className="font-medium text-xs truncate">{track.title}</div>
                        <div className="text-[10px] text-gray-400">{track.artist}</div>
                      </div>
                      {isSelected && isPlaying && <Activity className="w-4 h-4 text-red-500 animate-pulse flex-shrink-0" />}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Background Audio Test Controls */}
            <div className="mt-6 pt-4 border-t border-gray-800 space-y-2 text-xs">
              <div className="font-semibold text-gray-400 uppercase text-[10px] tracking-wider">
                Bảo Vệ Luồng Âm Thanh Nền
              </div>

              <div className="flex items-center justify-between p-2 bg-gray-800/60 rounded-lg">
                <span>Page Visibility Override</span>
                <input
                  type="checkbox"
                  checked={visibilityOverride}
                  onChange={(e) => {
                    setVisibilityOverride(e.target.checked);
                    backgroundAudioService.toggleVisibilityOverride(e.target.checked);
                  }}
                  className="accent-red-500 w-4 h-4 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-2 bg-gray-800/60 rounded-lg">
                <span>AudioContext Keep-Alive</span>
                <input
                  type="checkbox"
                  checked={audioCtxKeepAlive}
                  onChange={(e) => {
                    setAudioCtxKeepAlive(e.target.checked);
                    if (e.target.checked) backgroundAudioService.enableAudioContextKeepAlive();
                    else backgroundAudioService.disableAudioContextKeepAlive();
                  }}
                  className="accent-red-500 w-4 h-4 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
