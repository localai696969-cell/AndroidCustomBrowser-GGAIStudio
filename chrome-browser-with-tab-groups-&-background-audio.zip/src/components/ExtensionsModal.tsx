import React, { useState } from 'react';
import { X, Puzzle, ShieldCheck, Volume2, Moon, Sliders, Check, Zap } from 'lucide-react';
import { backgroundAudioService } from '../services/backgroundAudio';

interface ExtensionsModalProps {
  onClose: () => void;
  isPlayingAudio: boolean;
}

export const ExtensionsModal: React.FC<ExtensionsModalProps> = ({ onClose, isPlayingAudio }) => {
  const [visibilityOverride, setVisibilityOverride] = useState(true);
  const [audioCtxKeepAlive, setAudioCtxKeepAlive] = useState(true);
  const [mediaSessionEnabled, setMediaSessionEnabled] = useState(true);

  const handleToggleVisibility = (val: boolean) => {
    setVisibilityOverride(val);
    backgroundAudioService.toggleVisibilityOverride(val);
  };

  const handleToggleAudioCtx = (val: boolean) => {
    setAudioCtxKeepAlive(val);
    if (val) backgroundAudioService.enableAudioContextKeepAlive();
    else backgroundAudioService.disableAudioContextKeepAlive();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#2B2D30] rounded-2xl max-w-md w-full border border-gray-200 dark:border-gray-700 shadow-2xl p-6 text-gray-900 dark:text-gray-100 space-y-5">
        <div className="flex items-center justify-between border-b border-gray-200 dark:border-gray-700 pb-3">
          <div className="flex items-center gap-2 font-bold text-base">
            <Puzzle className="w-5 h-5 text-purple-600" />
            <span>Google Chrome Extensions</span>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Featured Extension Card */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-red-500/10 to-purple-500/10 border border-red-500/30 space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-red-600 text-white rounded-xl shadow-md">
                <Volume2 className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="font-bold text-sm">YouTube Background Audio Pro</h3>
                <span className="text-[10px] text-gray-500 dark:text-gray-400">Phiên bản 2.4.0 • Đã kích hoạt</span>
              </div>
            </div>

            <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded-full text-[10px] font-bold">
              ACTIVE
            </span>
          </div>

          <p className="text-xs text-gray-600 dark:text-gray-300">
            Tiện ích tự động ghi đè Page Visibility API và tạo luồng AudioContext keep-alive giúp phát nhạc YouTube ngầm không bao giờ dừng.
          </p>

          <div className="space-y-2 pt-2 border-t border-gray-200 dark:border-gray-700 text-xs">
            <div className="flex items-center justify-between">
              <span>Ghi đè Page Visibility API:</span>
              <input
                type="checkbox"
                checked={visibilityOverride}
                onChange={(e) => handleToggleVisibility(e.target.checked)}
                className="accent-red-600 w-4 h-4 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <span>WebAudio Keep-Alive Loop:</span>
              <input
                type="checkbox"
                checked={audioCtxKeepAlive}
                onChange={(e) => handleToggleAudioCtx(e.target.checked)}
                className="accent-red-600 w-4 h-4 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <span>MediaSession OS Lockscreen:</span>
              <input
                type="checkbox"
                checked={mediaSessionEnabled}
                onChange={(e) => setMediaSessionEnabled(e.target.checked)}
                className="accent-red-600 w-4 h-4 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Other Simulated Extensions */}
        <div className="space-y-2 text-xs">
          <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Tiện ích khác</div>

          <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl flex items-center justify-between border border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-500" />
              <span>uBlock Origin AdBlocker</span>
            </div>
            <span className="text-[10px] text-gray-400">Đã chặn 14 quảng cáo</span>
          </div>

          <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl flex items-center justify-between border border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-2">
              <Moon className="w-4 h-4 text-purple-500" />
              <span>Dark Reader Pro</span>
            </div>
            <span className="text-[10px] text-gray-400">Tự động Chế độ tối</span>
          </div>
        </div>
      </div>
    </div>
  );
};
