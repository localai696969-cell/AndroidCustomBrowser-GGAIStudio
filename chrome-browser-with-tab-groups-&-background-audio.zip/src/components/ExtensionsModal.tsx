import React from 'react';
import { AudioTrack } from '../types';
import { YOUTUBE_TRACKS } from '../data/initialData';
import { X, Volume2, Play, Pause, Radio, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface ExtensionsModalProps {
  isPlayingAudio: boolean;
  onToggleAudio: () => void;
  currentTrack: AudioTrack;
  onSelectTrack: (track: AudioTrack) => void;
  onClose: () => void;
}

export function ExtensionsModal({
  isPlayingAudio,
  onToggleAudio,
  currentTrack,
  onSelectTrack,
  onClose,
}: ExtensionsModalProps) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242629] border border-gray-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl text-gray-100">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-blue-400" />
            <h2 className="text-base font-bold">Background Audio Extension (Manifest V3)</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-lg text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-400" />
              <div>
                <p className="font-bold text-white">Trạng Thái Tiện Ích: Đang Hoạt Động</p>
                <p className="text-[10px] text-gray-400">AudioContext Synth Loop Active (GeckoView Keep-Alive)</p>
              </div>
            </div>
            <button
              onClick={onToggleAudio}
              className="p-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold"
            >
              {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
          </div>

          <div>
            <label className="block font-semibold text-gray-400 mb-2">Đang Phát Nền:</label>
            <div className="p-3 rounded-xl bg-[#1A1C1E] border border-gray-800 flex items-center gap-3">
              <img
                src={currentTrack.coverUrl}
                alt={currentTrack.title}
                className="w-12 h-12 rounded-lg object-cover border border-gray-700"
              />
              <div className="min-w-0 flex-1">
                <p className="font-bold text-white truncate">{currentTrack.title}</p>
                <p className="text-gray-400">{currentTrack.artist}</p>
              </div>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-gray-400 mb-2">Đổi Luồng Âm Thanh Nền:</label>
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {YOUTUBE_TRACKS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => onSelectTrack(t)}
                  className={`w-full p-2 rounded-lg border text-left flex items-center justify-between gap-2 transition-all ${
                    t.id === currentTrack.id
                      ? 'bg-blue-600/20 border-blue-500/50 text-white font-semibold'
                      : 'bg-[#1A1C1E] border-gray-800 text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  <span className="truncate">{t.title}</span>
                  {t.id === currentTrack.id && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
