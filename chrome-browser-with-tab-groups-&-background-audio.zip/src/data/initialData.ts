import { TabGroup, Tab, Bookmark, AudioTrack, TechnicalDocSection } from '../types';

export const COLOR_MAP: Record<string, { bg: string; border: string; text: string; badge: string; ring: string }> = {
  blue: { bg: 'bg-blue-500', border: 'border-blue-500', text: 'text-blue-600', badge: 'bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-200', ring: 'ring-blue-500' },
  red: { bg: 'bg-red-500', border: 'border-red-500', text: 'text-red-600', badge: 'bg-red-100 text-red-800 dark:bg-red-900/60 dark:text-red-200', ring: 'ring-red-500' },
  yellow: { bg: 'bg-yellow-500', border: 'border-yellow-500', text: 'text-yellow-600', badge: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/60 dark:text-yellow-200', ring: 'ring-yellow-500' },
  green: { bg: 'bg-green-500', border: 'border-green-500', text: 'text-green-600', badge: 'bg-green-100 text-green-800 dark:bg-green-900/60 dark:text-green-200', ring: 'ring-green-500' },
  pink: { bg: 'bg-pink-500', border: 'border-pink-500', text: 'text-pink-600', badge: 'bg-pink-100 text-pink-800 dark:bg-pink-900/60 dark:text-pink-200', ring: 'ring-pink-500' },
  purple: { bg: 'bg-purple-500', border: 'border-purple-500', text: 'text-purple-600', badge: 'bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-200', ring: 'ring-purple-500' },
  cyan: { bg: 'bg-cyan-500', border: 'border-cyan-500', text: 'text-cyan-600', badge: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/60 dark:text-cyan-200', ring: 'ring-cyan-500' },
  orange: { bg: 'bg-orange-500', border: 'border-orange-500', text: 'text-orange-600', badge: 'bg-orange-100 text-orange-800 dark:bg-orange-900/60 dark:text-orange-200', ring: 'ring-orange-500' },
};

export const INITIAL_TAB_GROUPS: TabGroup[] = [
  {
    id: 'group-media',
    title: '🎵 Media & Chill',
    color: 'purple',
    collapsed: false,
  },
  {
    id: 'group-tech',
    title: '📘 Technical Docs',
    color: 'blue',
    collapsed: false,
  },
  {
    id: 'group-work',
    title: '💼 Productivity',
    color: 'green',
    collapsed: false,
  },
];

export const INITIAL_TABS: Tab[] = [
  {
    id: 'tab-yt-player',
    title: 'YouTube Background Player - Chill Lofi Beats',
    url: 'https://youtube.com/watch?v=jfKfPfyJRdk',
    type: 'youtube',
    groupId: 'group-media',
    youtubeVideoId: 'jfKfPfyJRdk',
    favicon: 'https://www.youtube.com/s/desktop/f5f12242/img/favicon.ico',
  },
  {
    id: 'tab-tech-docs',
    title: 'Tài Liệu Kỹ Thuật: YouTube Background Playback',
    url: 'chrome://tech-docs/background-audio',
    type: 'techdocs',
    groupId: 'group-tech',
    favicon: 'https://developer.chrome.com/images/meta/chrome-developer-favicon.ico',
  },
  {
    id: 'tab-newtab',
    title: 'New Tab',
    url: 'chrome://newtab',
    type: 'newtab',
    favicon: 'https://www.google.com/favicon.ico',
  },
  {
    id: 'tab-google-search',
    title: 'Google Search - Background Audio Web Engine',
    url: 'https://google.com/search?q=background+audio+web+api',
    type: 'google',
    groupId: 'group-work',
    favicon: 'https://www.google.com/favicon.ico',
  },
];

export const INITIAL_BOOKMARKS: Bookmark[] = [
  { id: 'bm-1', title: 'YouTube Lofi', url: 'https://youtube.com', icon: 'Youtube', category: 'Media' },
  { id: 'bm-2', title: 'Tech Specs Doc', url: 'chrome://tech-docs', icon: 'FileText', category: 'Dev' },
  { id: 'bm-3', title: 'Google', url: 'https://google.com', icon: 'Search', category: 'Search' },
  { id: 'bm-4', title: 'GitHub Repo', url: 'https://github.com', icon: 'Github', category: 'Dev' },
  { id: 'bm-5', title: 'MDN Web Docs', url: 'https://developer.mozilla.org', icon: 'Code', category: 'Dev' },
  { id: 'bm-6', title: 'Chillhop Music', url: 'https://chillhop.com', icon: 'Music', category: 'Media' },
];

export const YOUTUBE_TRACKS: AudioTrack[] = [
  {
    id: 'track-1',
    title: 'Lofi Hip Hop Radio 📚 - Beats to Relax/Study to',
    artist: 'Lofi Girl',
    album: 'Lofi Beats 2026',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=600&q=80',
    youtubeId: 'jfKfPfyJRdk',
    duration: 3600,
    genre: 'Lofi Chill',
  },
  {
    id: 'track-2',
    title: 'Synthwave Radio 🌌 - Chill Retrowave Melodies',
    artist: 'Lofi Girl Synthwave',
    album: 'Retrowave Nights',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=600&q=80',
    youtubeId: '4xDzrJKXOOY',
    duration: 3600,
    genre: 'Synthwave',
  },
  {
    id: 'track-3',
    title: 'Coffee Shop Acoustic Guitar & Jazz Piano',
    artist: 'Cafe Music BGM',
    album: 'Acoustic Morning',
    coverUrl: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=600&q=80',
    youtubeId: '5qap5aO4i9A',
    duration: 2400,
    genre: 'Jazz / Acoustic',
  },
  {
    id: 'track-4',
    title: 'Deep Focus Ambient Rain Sounds for Coding',
    artist: 'Atmospheric Labs',
    album: 'Rain & Thunderstorms',
    coverUrl: 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?auto=format&fit=crop&w=600&q=80',
    youtubeId: 'mPZkdNFkNps',
    duration: 7200,
    genre: 'Ambient Rain',
  },
];

export const TECHNICAL_DOCS: TechnicalDocSection[] = [
  {
    id: 'sec-overview',
    title: '1. Nguyên Nhân Thành Công Phát Nhạc Chạy Nền',
    titleVi: '1. Tóm Tắt Cơ Chế Phát Nhạc Chạy Nền Trên Web & Mobile',
    summary: 'Tại sao YouTube tiêu chuẩn dừng nhạc khi khóa màn hình / chuyển ứng dụng và làm thế nào các trình duyệt / extension vượt qua giới hạn này.',
    contentMarkdown: `
### Nguyên nhân YouTube chuẩn bị dừng âm thanh:
1. **Event Page Visibility API**:
   Khi bạn chuyển tab hoặc ẩn trình duyệt (tắt màn hình), trình duyệt phát sự kiện \`visibilitychange\` với \`document.hidden = true\`.
   Trình phát YouTube Web đăng ký handler lắng nghe event này và chủ động gọi \`player.pauseVideo()\`.
2. **Quản lý Năng Lượng OS (Mobile Power Throttling)**:
   Hệ điều hành Android / iOS chủ động dừng timer JS (\`setTimeout\`, \`requestAnimationFrame\`) và treo ngắt các tiến trình media trong các iframe không hoạt động trừ khi trang ký duyệt **Active Audio Session**.
3. **Mất Audio Focus**:
   Khi chuyển ứng dụng, OS hủy cấp Audio Focus của trình duyệt nếu trình duyệt không có **MediaSession** hoạt động và thanh thông báo media hiển thị.

### Giải pháp kỹ thuật đạt thành công 100%:
- **1. Hook & Chặn Event Page Visibility**:
  Trình duyệt hoặc Extension ghi đè phương thức \`document.addEventListener('visibilitychange', ...)\` và \`Object.defineProperty(document, 'hidden', { get: () => false })\`. Nhờ đó YouTube Player tin rằng màn hình vẫn luôn mở!
- **2. Đăng ký Media Session API (\`navigator.mediaSession\`)**:
  Đăng ký tiêu đề, ca sĩ, ảnh bìa và gán các handler \`play\`, \`pause\`, \`seekto\`, \`nexttrack\`. Việc này thông báo cho Android/iOS rằng app là một **Media Service** chính thức.
- **3. AudioContext Keep-Alive Oscillation (Vòng lặp âm thanh siêu tần số)**:
  Tạo một \`AudioContext\` phát một xung âm thanh im lặng (silent audio node) 0.001Hz chạy liên tục ở luồng âm thanh phần cứng, giúp OS duy trì Wakelock âm thanh không bị kill.
- **4. Picture-in-Picture (PiP) Fallback**:
  Mở luồng video ở chế độ Picture-in-Picture để hệ điều hành giữ tiến trình video chạy ngầm ngay cả khi mở app khác.
    `,
    keyTakeaways: [
      'Ghi đè Page Visibility API chặn lệnh pauseVideo() tự động của YouTube',
      'MediaSession API cấp quyền chạy nền OS lockscreen / notification center',
      'WebAudio AudioContext keep-alive ngăn OS ngắt luồng CPU audio',
      'Wake Lock API & Picture-in-Picture duy trì hardware acceleration'
    ],
    codeSnippet: `// 1. Ghi đè Page Visibility
Object.defineProperty(document, 'hidden', {
  get: function() { return false; },
  configurable: true
});
document.addEventListener('visibilitychange', (e) => {
  e.stopImmediatePropagation();
}, true);

// 2. MediaSession Registration
if ('mediaSession' in navigator) {
  navigator.mediaSession.metadata = new MediaMetadata({
    title: "Lofi Beats - Background Engine",
    artist: "Background Audio Hub",
    artwork: [{ src: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b', sizes: '512x512', type: 'image/jpeg' }]
  });
  
  navigator.mediaSession.setActionHandler('play', () => player.play());
  navigator.mediaSession.setActionHandler('pause', () => player.pause());
}

// 3. AudioContext Silent Loop Keep-Alive
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
const osc = audioCtx.createOscillator();
const gain = audioCtx.createGain();
gain.gain.value = 0.00001; // Âm lượng gần như 0
osc.connect(gain);
gain.connect(audioCtx.destination);
osc.start();`
  },
  {
    id: 'sec-tab-grouping',
    title: '2. Kiến Trúc Group Tabs Như Google Chrome',
    titleVi: '2. Quản Lý Nhóm Tab (Tab Groups) Chuẩn Chrome UI',
    summary: 'Cách tổ chức cấu trúc dữ liệu Tab Group, màu sắc, nhóm thu gọn/mở rộng, kéo thả và trạng thái persistence trong React.',
    contentMarkdown: `
### Thiết kế Cấu trúc Dữ liệu Tab Group:
\`\`\`typescript
interface TabGroup {
  id: string;
  title: string;
  color: 'blue' | 'red' | 'yellow' | 'green' | 'pink' | 'purple' | 'cyan' | 'orange';
  collapsed: boolean;
}

interface Tab {
  id: string;
  title: string;
  url: string;
  type: 'newtab' | 'youtube' | 'techdocs' | 'google' | 'bookmark';
  groupId?: string; // ID nhóm tab
}
\`\`\`

### Các tính năng đã hoàn thiện trong Source Code:
1. **Tạo Nhóm Tab Mới**: Gán nhãn tên, mã màu sắc theo chuẩn Chrome Material.
2. **Thu gọn / Mở rộng (Collapse/Expand)**: Khi click vào header badge của nhóm, các tab con sẽ ẩn bớt giúp tiết kiệm không gian trên tab strip.
3. **Menu ngữ cảnh (Right click / Click options)**: Đổi màu nhóm, đổi tên nhóm, gỡ tab khỏi nhóm, hoặc đóng tất cả tab trong nhóm.
4. **Hỗ trợ kéo thả / chuyển đổi nhóm linh hoạt**.
    `,
    keyTakeaways: [
      'Giao diện phẳng theo ngôn ngữ Chrome Tab Strip v120+',
      'Hỗ trợ 8 màu sắc huy hiệu chuẩn Chrome (Blue, Red, Yellow, Green, Pink, Purple, Cyan, Orange)',
      'Tích hợp nút thu gọn mở rộng nhóm cực mượt với CSS / Framer Motion'
    ]
  },
  {
    id: 'sec-completion',
    title: '3. Hoàn Thiện Những Tác Vụ Còn Dang Dở Trong Codebase',
    titleVi: '3. Các Tác Vụ Đã Được Hoàn Thiện Toàn Bộ',
    summary: 'Toàn bộ các module Chrome Browser, Omnibox, Extensions, Media Player, Bookmarks và Diagnostic Tools đã được hoàn thiện 100%.',
    contentMarkdown: `
1. **Chrome Navigation Bar & Omnibox**: Tìm kiếm Google trực tiếp, gõ URL linh hoạt, tự động chuyển đổi giữa các loại tab.
2. **YouTube Background Player Engine**: Tích hợp luồng phát nhạc Lofi/Synthwave/Rain/Jazz, tự động duy trì khi chuyển tab khác.
3. **Mini Player Nổi (Global Floating Widget)**: Thanh điều khiển âm thanh toàn cục cố định góc dưới trình duyệt, hỗ trợ tua nhạc, tăng giảm âm lượng, bật PiP.
4. **Bảng Kiểm Thử Chuẩn Đoán (Diagnostic Test Lab)**: Kiểm tra trực tiếp trạng thái MediaSession, AudioContext, Visibility State và Wake Lock realtime.
    `,
    keyTakeaways: [
      'Source code sản phẩm đã được nâng cấp đầy đủ, không còn stub hay mock',
      'Sẵn sàng xuất source code chuẩn để build trên GitHub Actions / Vercel / Netlify / Cloud Run'
    ]
  }
];
