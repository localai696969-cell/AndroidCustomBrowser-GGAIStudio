import { TabGroup, Tab, Bookmark, AudioTrack } from '../types';

export const INITIAL_TAB_GROUPS: TabGroup[] = [
  {
    id: 'group-media',
    name: 'Media & Chill',
    color: 'purple',
    collapsed: false,
  },
  {
    id: 'group-work',
    name: 'Research & Docs',
    color: 'blue',
    collapsed: false,
  },
];

export const YOUTUBE_TRACKS: AudioTrack[] = [
  {
    id: 'track-1',
    title: 'Lofi Hip Hop Radio 📚 - Beats to Relax/Study to',
    artist: 'Lofi Girl',
    album: 'Lofi Beats 2026',
    youtubeId: 'jfKfPfyJRdk',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=600&q=80',
    durationSeconds: 3600,
  },
  {
    id: 'track-2',
    title: 'Synthwave Radio 🌌 - Chill Retrowave Melodies',
    artist: 'Lofi Girl Synthwave',
    album: 'Retro Future Vol. 4',
    youtubeId: '5qap5aO4i9A',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
    durationSeconds: 2400,
  },
  {
    id: 'track-3',
    title: 'Coffee Shop Acoustic Guitar & Jazz Piano',
    artist: 'Cafe Music BGM',
    album: 'Acoustic Morning',
    youtubeId: 'DWcjTZqg88M',
    coverUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=600&q=80',
    durationSeconds: 1800,
  },
];

export const INITIAL_TABS: Tab[] = [
  {
    id: 'tab-1',
    title: 'YouTube Lofi',
    url: 'https://youtube.com/watch?v=jfKfPfyJRdk',
    groupId: 'group-media',
    type: 'youtube',
    active: true,
    isPlayingAudio: true,
  },
  {
    id: 'tab-2',
    title: 'Tech Specs Doc',
    url: 'chrome://tech-docs',
    groupId: 'group-work',
    type: 'techdocs',
    active: false,
  },
  {
    id: 'tab-3',
    title: 'Google Search',
    url: 'https://google.com',
    type: 'web',
    active: false,
  },
];

export const INITIAL_BOOKMARKS: Bookmark[] = [
  {
    id: 'bm-1',
    title: 'YouTube',
    url: 'https://youtube.com',
    icon: 'youtube',
  },
  {
    id: 'bm-2',
    title: 'GitHub Repo',
    url: 'https://github.com/mozilla/geckoview',
    icon: 'github',
  },
  {
    id: 'bm-3',
    title: 'Mozilla GeckoView Docs',
    url: 'https://mozilla.github.io/geckoview/',
    icon: 'globe',
  },
];
